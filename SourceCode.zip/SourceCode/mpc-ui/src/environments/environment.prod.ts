export const environment = {
  production: true,
  mpc_url: 'https://mpc-wma-api.onrender.com/mpc/api/v1/'
};
