import { Injectable } from '@angular/core';
import { Observable, } from 'rxjs';
import { ApiService } from './../../shared/services/api.service';

@Injectable({
  providedIn: 'root'
})
export class ReportService {

  constructor(private apiService: ApiService) { }

  getReport(queryParams): Observable<any> {
    return this.apiService.getRequest('reports', null, queryParams);
  }

  getJobDescriptions(queryParams): Observable<any> {
    return this.apiService.getRequest('reports/descriptions', null, queryParams);
  }
}
