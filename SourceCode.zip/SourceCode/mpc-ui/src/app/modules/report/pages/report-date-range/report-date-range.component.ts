import { trigger, state, style, transition, animate } from '@angular/animations';
import { HttpParams } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { SharedService } from 'src/app/modules/shared/services/shared.service';
import { departments } from 'src/app/modules/shared/services/department.model';
import { ReportService } from 'src/app/modules/report/shared/report.service';

@Component({
  selector: 'app-report-date-range',
  templateUrl: './report-date-range.component.html',
  styleUrls: ['./report-date-range.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})

export class ReportDateRangeComponent implements OnInit {
  //columnsToDisplay = ['employee', 'wage'];
  //displayedColumns: string[] = ['work', 'wage'];
  //displayedColumns: string[] = ['position', 'employeeId', 'name', 'wage'];
  //dataSource = [];
  entryTypes = ['In', 'Out'];
  jobDescriptions = [];
  displayedColumnsDefault: string[] = ['_id', 'total'];
  displayedColumnsMachinePeelingOut: string[] = ['_id', 'wholes_total', 'pieces_total', 'husk_total'];

  currentDate = new Date();
  departments = [];
  departmentValue = null;
  departmentSearchText = '';
  filterModel = { date_start: new Date(), date_end: new Date(), department: 'roasting', entry_type: '', job_description: '' };
  reportResponse = '';

  constructor(
    private reportService: ReportService,
    private sharedService: SharedService,
    private router: Router,
    private toastr: ToastrService
  ) {
    this.filterModel.date_start.setDate(this.currentDate.getDate() - 7);
    this.departments = departments

  }

  ngOnInit(): void {
    this.onFilterClick(null);
  }

  onFilterClick(filterForm) {
    this.reportResponse = '';
    let params = new HttpParams();
    params = params.append('date_start', this.sharedService.getDateOnly(this.filterModel.date_start));
    params = params.append('date_end', this.sharedService.getDateOnly(this.filterModel.date_end));
    params = params.append('department', this.filterModel.department);
    params = params.append('entry_type', this.filterModel.entry_type);
    params = params.append('job_description', this.filterModel.job_description);


    this.reportService.getReport(params).subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.reportResponse = sResponse.data;
      } else {
        this.toastr.error('Failed to Report Entries,Please Try Again');
      }
    });

  }


  onRowClick(row) {

    // let view_wage: any = {};
    // view_wage.date_start = this.sharedService.getDateOnly(this.filterModel.date_start);
    // view_wage.date_end = this.sharedService.getDateOnly(this.filterModel.date_end);
    // view_wage.employee_id = row._id;
    // view_wage.employee_name = this.getEmployeeFullName(row.employee);
    // this.router.navigate(['mpc', 'view-wage-employee'], { queryParams: view_wage });
  }

  toTitleCase(str) {
    return str.replace(/\s\s+/g, ' ').trim().split(' ')
      .map(w => w[0].toUpperCase() + w.substr(1).toLowerCase())
      .join(' ');

  }

  getEmployeeFullName(employee) {
    let fullName = employee.first_name;
    if (employee.middle_name) {
      fullName += " " + employee.middle_name;
    }
    if (employee.last_name) {
      fullName += " " + employee.last_name;
    }
    return this.toTitleCase(fullName);
  }

  onDepartmentChange() {
    this.jobDescriptions = [];
    let params = new HttpParams();
    params = params.append('department', this.filterModel.department);

    this.reportService.getJobDescriptions(params).subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.jobDescriptions = sResponse.data;
      }
    });
    this.reportResponse = '';
  }

  onEntryTypeChange() {
    this.reportResponse = '';
  }
}
