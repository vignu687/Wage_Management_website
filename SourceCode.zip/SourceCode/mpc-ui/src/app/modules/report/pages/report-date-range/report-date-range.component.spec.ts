import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportDateRangeComponent } from './report-date-range.component';

describe('ReportDateRangeComponent', () => {
  let component: ReportDateRangeComponent;
  let fixture: ComponentFixture<ReportDateRangeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportDateRangeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportDateRangeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
