import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppFullLayoutComponent } from 'src/app/layouts/app-full-layout/app-full-layout.component';
import { ReportDateRangeComponent } from './pages/report-date-range/report-date-range.component';
import { ReportComponent } from './report.component';


const routes: Routes = [{
  path: '',
  component: AppFullLayoutComponent,
  children: [
    {
      path: '', component: ReportComponent,
      data: {
        breadcrumb: 'Reporting',
        access: 'reporting'
      }
    }, {
      path: 'report-date-range',
      component: ReportDateRangeComponent,
      data: {
        breadcrumb: 'Report By Date',
        access: 'reporting'
      }
    }]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportRoutingModule { }
