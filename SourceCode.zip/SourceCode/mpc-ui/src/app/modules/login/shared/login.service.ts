import { Injectable } from '@angular/core';
import { ApiService } from '../../shared/services/api.service';
import { Observable, of, throwError } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private apiService:ApiService, private toastr: ToastrService) { }

  requestLogin(requestModel): Observable<any> {

    return this.apiService.postRequest('users/login', requestModel).pipe(map(
      sResponseModel => {
        if (sResponseModel.status  && !sResponseModel.message) {
          return sResponseModel;
        } else {
          throw throwError(sResponseModel.message);
        }
      }));
    }
}
