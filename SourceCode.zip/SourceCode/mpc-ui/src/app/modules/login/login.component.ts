import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../login/shared/login.service'
import { SharedService } from '../shared/services/shared.service';
import { ToastrService } from 'ngx-toastr';

export enum ViewModel {
  LOGIN_VIEW = 'LOGIN_VIEW',
  OTP_VIEW = 'OTP_VIEW',
  FORGOT_PASSWORD_VIEW = 'FORGOT_PASSWORD_VIEW',
  LOGIN_VIEW_ADMIN = 'LOGIN_VIEW_ADMIN'
}

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class LoginComponent implements OnInit {

  isSubmitted=false;
  isLoginError=false;
  componentModel;
  OTPLoginModel: object = new Object();
  viewModel = ViewModel;
  selectedViewModel: ViewModel = this.viewModel.LOGIN_VIEW;
  errorMessage: string;
  hide = true;
  currentDate = new Date();
  entry_date_start = new Date();
  entry_date_end = new Date();

  constructor(private router: Router,private loginService:LoginService,
     private sharedService:SharedService,
     private toastr:ToastrService) { 
    this.entry_date_start.setDate(this.currentDate.getDate() - 7);
  }

  ngOnInit(): void {
    this.resetLoginViewModel();

    // Uncomment to Enable Auto Login if Already Logged In
    // const currentUser = this.sharedService.getLoggedUser();
    // if(currentUser.employee_type=='worker'){
    //   this.router.navigate(['mpc/view-wage']);
    // } else {
    //   this.router.navigate(['mpc']);
    // }
    
  }

  resetLoginViewModel() {
    this.componentModel = {
      username: "",
      password: ""
    };
    this.selectedViewModel = this.viewModel.LOGIN_VIEW;
    this.OTPLoginModel = new Object();
  }

  onSubmitLoginForm() {
    this.isSubmitted=true;
    this.loginService.requestLogin(this.componentModel).subscribe(sresponse => {
      this.isLoginError=false;
      this.sharedService.setLoggedUser(sresponse.data);
      const currentUser = this.sharedService.getLoggedUser();

      //If Logged user is Worker
      if(currentUser.employee_type=='worker' || currentUser.employee_type=='operator'){

        // Navigate to Employee View Wage Screen
        let view_wage: any = {};
        view_wage.entry_date_start = this.sharedService.getDateOnly(this.entry_date_start);
        view_wage.entry_date_end = this.sharedService.getDateOnly(this.entry_date_end);
        view_wage.employee_id = currentUser.id;
        view_wage.employee_name = this.getEmployeeFullName(currentUser);
        this.router.navigate(['mpc', 'view-wage-employee'], { queryParams: view_wage });

      } else {
        this.router.navigate(['mpc','view-wage']);
      }
      
    },sError=>{
      if(this.selectedViewModel=='LOGIN_VIEW'){
        this.errorMessage='Incorrect Employee ID or PIN';
      } else if (this.selectedViewModel=='LOGIN_VIEW_ADMIN'){
        this.errorMessage='Incorrect Username or Password';
      }else{
        this.toastr.error('Server Error','Please try again');
      }
      this.isLoginError=true;
      
    });

  }

  toTitleCase(str) {
    return str.replace(/\s\s+/g, ' ').trim().split(' ')
      .map(w => w[0].toUpperCase() + w.substr(1).toLowerCase())
      .join(' ');

  }

  getEmployeeFullName(employee) {
    let fullName = employee.first_name;
    if (employee.middle_name) {
      fullName += " " + employee.middle_name;
    }
    return this.toTitleCase(fullName += " " + employee.last_name);
  }

  changeView(viewName:string){

    switch(viewName){

      case 'LOGIN_VIEW' : {
        this.componentModel = {
          username: "",
          password: ""
        };
        this.selectedViewModel=this.viewModel.LOGIN_VIEW;
        this.isLoginError=false;
        break;
      }

      case 'LOGIN_VIEW_ADMIN' : {
        this.componentModel = {
          username: "",
          password: ""
        };
        this.selectedViewModel=this.viewModel.LOGIN_VIEW_ADMIN;
        this.isLoginError=false;
        break;
      }

      default :{
        break;
      }

    }
  }
}
