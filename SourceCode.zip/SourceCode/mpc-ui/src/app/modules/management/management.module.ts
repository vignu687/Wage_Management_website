import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManagementRoutingModule } from './management-routing.module';
import { ManagementComponent } from './management.component';
import { AddEmployeeComponent } from './components/add-employee/add-employee.component';
import { SharedModule } from '../shared/shared.module';
import { EmployeesComponent } from './pages/employees/employees.component';
import { MasterSettingsComponent } from './pages/master-settings/master-settings.component';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { OriginComponent } from './pages/origin/origin.component';
import { MpcGridComponent } from '../mpc/components/mpc-grid/mpc-grid.component';
import { MpcModule } from '../mpc/mpc.module';
import { LotComponent } from './pages/lot/lot.component';
import { GradeComponent } from './pages/grade/grade.component';
import { MachineComponent } from './pages/machine/machine.component';
import { WeightTypeComponent } from './pages/weight-type/weight-type.component';
import { EntryTypeComponent } from './pages/entry-type/entry-type.component';
import { EmployeeLoanComponent } from './pages/employee-loan/employee-loan.component';

@NgModule({
  declarations: [ManagementComponent, EmployeesComponent, AddEmployeeComponent, MasterSettingsComponent, OriginComponent, LotComponent, GradeComponent, MachineComponent, WeightTypeComponent, EntryTypeComponent, EmployeeLoanComponent],
  imports: [
    CommonModule,
    ManagementRoutingModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class ManagementModule { }
