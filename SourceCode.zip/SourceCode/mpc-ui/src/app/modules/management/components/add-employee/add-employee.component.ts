import { Component, Input, Output, OnInit, ViewEncapsulation, EventEmitter, ViewChild } from '@angular/core';
import { FormControl, NgForm } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { EmployeeService } from './../../shared/employee.service';
import { PermissionService } from 'src/app/modules/shared/services/permissions.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AddEmployeeComponent implements OnInit {

  @ViewChild('addEmployeeForm') addEmployeeForm: NgForm;
  userModel: any = {};
  pages = new FormControl();
  hide = true;
  showUpdateButton = false;
  showPasswordOrPIN = true;
  showCancelButton = false;


  //pagesList: string[] = ['roasting', 'human_cutting', 'machine_cutting', 'oven_heating', 'cooling', 'machine_peeling', 'human_peeling', 'sorting_machine', 'machine_grading', 'human_grading', 'final_oven_entry','view_wage','view_wage_employee','management'];
  pagesList = [];
  workerPagesList: string[] = ['view_wage_employee'];


  genderOptions =
    [{ key: 'male', label: 'Male' },
    { key: 'female', label: 'Female' },
    { key: 'others', label: 'Others' }];

  employeeTypes =
    [{ key: 'admin', label: 'Admin' },
    { key: 'worker', label: 'Worker' },
    { key: 'operator', label: 'Operator' }];

  bloodGroupOptions =
    [{ key: 'a_positive', label: 'A+' },
    { key: 'a_negative', label: 'A-' },
    { key: 'b_positive', label: 'B+' },
    { key: 'b_negative', label: 'B-' },
    { key: 'o_positive', label: 'O+' },
    { key: 'o_negative', label: 'O-' },
    { key: 'ab_positive', label: 'AB+' },
    { key: 'ab_negative', label: 'AB-' },
    { key: 'others', label: 'Others' }];

  constructor(public router: Router, private route: ActivatedRoute, private toastr: ToastrService,
    public dialog: MatDialog,
    private employeeService: EmployeeService,
    private permissionService:PermissionService
  ) {

    this.pagesList=this.permissionService.pageArray;
    this.userModel.employee_type = 'admin';

  }

  ngOnInit() {
    const employeeId = this.route.snapshot.paramMap.get('id');
    if (employeeId) {
      this.getEmployeeById(employeeId);
      this.showUpdateButton = true;
      this.showPasswordOrPIN = false;
      this.showCancelButton = false;
    } else {
      this.showUpdateButton = false;
      this.showPasswordOrPIN = true;
      this.showCancelButton = false;
    }
  }

  onEmployeeTypeChange() {
    if (this.userModel.employee_type == 'worker') {
      this.userModel.bank_opt = false;
      this.userModel.pf_opt = false;
      this.userModel.esi_opt = false;
      this.userModel.base_wage_opt = false;
      delete this.userModel.pages;
    } else if (this.userModel.employee_type == 'operator') {
      this.userModel.bank_opt = false;
      this.userModel.pf_opt = false;
      this.userModel.esi_opt = false;
      this.userModel.base_wage_opt = false;
    }
    else if (this.userModel.employee_type == 'admin') {
      delete this.userModel.bank_opt;
      delete this.userModel.pf_opt;
      delete this.userModel.esi_opt;
      delete this.userModel.base_wage_opt;
      delete this.userModel.employee_id;
      delete this.userModel.address;
      delete this.userModel.city;
      delete this.userModel.pincode;
      delete this.userModel.phone;
      delete this.userModel.alternate_phone;
      delete this.userModel.aadhar_no;
      delete this.userModel.pan_no;
      delete this.userModel.bankaccount_no;
      delete this.userModel.ifsc;
      delete this.userModel.uan_no;
      delete this.userModel.esi_no;
      delete this.userModel.kernel_grading;
      delete this.userModel.peeling;
      delete this.userModel.seperating;
      delete this.userModel.piece;
      delete this.userModel.scooping;
      delete this.userModel.wholes;
      delete this.userModel.cleaners;
      delete this.userModel.machine_operator;
      delete this.userModel.hand_cutting;
      delete this.userModel.full_absent;
      delete this.userModel.pages;
    }
  }


  onSubmitAddEmployeeForm(sForm) {

    if (this.userModel.employee_type == 'operator') {
      this.userModel["pages"] = this.pages.value;
    } else if (this.userModel.employee_type == 'worker') {
      this.userModel["pages"] = this.workerPagesList;
    } else if (this.userModel.employee_type == 'admin') {
      this.userModel["pages"] = this.pagesList;
    } else {
      delete this.userModel.pages;
    }

    const postModel = JSON.parse(JSON.stringify(this.userModel));

    this.employeeService.saveEmployee(postModel).subscribe(
      sResponseModel => {
        if (sResponseModel.status && !sResponseModel.message) {
          this.toastr.success('Employee Record Saved Successfully');
          this.resetForm();
          this.router.navigate(['management/employees']);
        } else if (String(sResponseModel.trace).includes('duplicate key error')) {
          if(this.userModel.employee_type == 'admin'){
            this.toastr.error('Username already used, Please try with another Username');
          } else {
            this.toastr.error('Employee ID already used, Please try with another Employee ID');
          }
        }
        else {
          this.toastr.error('Failed to Save Employee Record, Please Try Again');
        }
      }
    );
  }

  getEmployeeById(employeeId) {
    this.employeeService.getEmployeeById(employeeId).subscribe(
      sResponseModel => {
        if (sResponseModel.status && !sResponseModel.message) {
          this.userModel = sResponseModel.data;
          if (sResponseModel.data.pages) {
            this.pages.setValue(sResponseModel.data.pages);
          }
        }
        else {
          this.toastr.error('Failed to get Employee Record, Please Try Again');
        }
      }
    );
  }

  updatePasswordOrPIN() {
    this.showPasswordOrPIN = true;
    this.showUpdateButton = false;
    this.showCancelButton = true;
  }

  cancelUpdatePasswordOrPIN() {
    this.showPasswordOrPIN = false;
    this.showUpdateButton = true;
    this.showCancelButton = false;
  }

  resetForm() {
    this.pages.reset();
    this.addEmployeeForm.resetForm();
    delete this.userModel.id;
  }
}
