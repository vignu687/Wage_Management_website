import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from './../../shared/services/api.service';

@Injectable({
  providedIn: 'root'
})
export class MasterSettingsService {

  constructor(private apiService: ApiService) { }

  getSettings(): Observable<any> {
    return this.apiService.getRequest('master-settings', null);
  }

  getPayrollSettings(): Observable<any> {
    return this.apiService.getRequest('master-settings/section/payroll', null);
  }

  saveSettings(requestModel): Observable<any> {

    if (requestModel.id) {
      return this.apiService.putRequest('master-settings', requestModel.id, requestModel);
    } else {
      return this.apiService.postRequest('master-settings', requestModel);
    }

  }

  getSettingsById(id): Observable<any> {
    return this.apiService.getRequest(`master-settings/`, id);
  }

  deleteSettingsById(id): Observable<any> {
    return this.apiService.deleteRequest(`master-settings/`, id);
  }
}
