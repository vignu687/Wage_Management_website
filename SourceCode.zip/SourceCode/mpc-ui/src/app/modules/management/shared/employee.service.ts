import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from './../../shared/services/api.service';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private apiService: ApiService) { }

  getAllEmployees(): Observable<any> {
    return this.apiService.getRequest('employees', null);
  }

  getWageEmployeesAll(): Observable<any> {
    return this.apiService.getRequest('employees/wage-employees/all', null);
  }

  saveEmployee(requestModel): Observable<any> {
    if (requestModel.id) {
      return this.apiService.putRequest('employees', requestModel.id,requestModel);
    } else {
      return this.apiService.postRequest('employees', requestModel);
    }

  }

  getEmployeeById(id): Observable<any> {
    return this.apiService.getRequest(`employees/`, id);
  }


}
