import { Component, OnInit, Input, EventEmitter, Output, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { MatDialog } from '@angular/material/dialog';
import { EmployeeService } from './../../shared/employee.service';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EmployeesComponent implements OnInit {

  employees= [];
  selectedRow = null;
  employeeControl = new FormControl();
  filteredOptions$: Observable<string[]>;
  isViewAll : boolean;

  displayedColumns = ['username', 'first_name','last_name', 'gender','employee_type','loan_balance'];

  constructor(private router: Router,private employeeService: EmployeeService, private toastr: ToastrService) { }

  ngOnInit(): void {

    this.isViewAll=true;

    this.employeeService.getAllEmployees().subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.employees = sResponse.data;
          console.log(this.employees);
        } else {
          this.toastr.error('Failed to Get Employee Records, Please Try Again');
        }
      });

    this.filteredOptions$ = this.employeeControl.valueChanges
    .pipe(
      startWith(''),
      map((name: string) => name ? this._filter(name) : this.employees.slice())
    );

  }

  _filter(value){
    if (value != null) {
      const filterValue = value.toLowerCase();
      let filteredEmployeesByName=this.employees.filter(employee => (employee.first_name+employee.middle_name+employee.last_name).toLowerCase().includes(filterValue));
      if(filteredEmployeesByName.length>0){   
        return filteredEmployeesByName;
      } else {
        return this.employees.filter(employee => employee.username.includes(filterValue));
      }
    }
  }

  toggleViewAllFlag(){
    this.isViewAll=!this.isViewAll;
    this.employeeControl.setValue('');
  }

  onRowClick(row) {
    this.selectedRow = row;
    this.router.navigate(['management/add-employee',{'id':this.selectedRow.id}]);
  }

  addEmployee() {
    this.router.navigate(['management/add-employee']);
  }
}
