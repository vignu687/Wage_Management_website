import { Component, OnInit, ViewChild, ViewEncapsulation  } from '@angular/core';
import { FormControl, NgForm } from '@angular/forms';
import { Observable, Subject } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { EmployeeLoan } from './../../../../models/employee.loan';
import { ToastrService } from 'ngx-toastr';
import { EmployeeService } from './../../../management/shared/employee.service';
import { EmployeeLoanService } from './../../../mpc/shared/employee.loan.service';
import { HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-employee-loan',
  templateUrl: './employee-loan.component.html',
  styleUrls: ['./employee-loan.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EmployeeLoanComponent implements OnInit {

  @ViewChild('employeeLoanForm') employeeLoanForm: NgForm;

  employeeLoanTranDisplayedColumns = ['updated_date','event_type','amount','comment','action'];
  employeeLoansDisplayedColumns = ['username','full_name','loan_balance']

  employeeLoanModel: EmployeeLoan = new EmployeeLoan();
  employeeControl = new FormControl();
  employeeFilterControl = new FormControl();
  filteredOptions: Observable<string[]>;
  protected _onDestroy = new Subject<void>();
  employees = [];
  entryTypes = [
    {label : 'Loan Amount Issued',value:'Loan Amount Issued' },
    {label : 'Loan Amount Collected',value:'Loan Amount Collected' },
  ];
  employeeLoanTransactions = [];
  employeeLoans =[];
  showEmployeeLoans=true;

  constructor(private toastr: ToastrService, private employeeService: EmployeeService, private employeeLoanService:EmployeeLoanService) { }

  ngOnInit(): void {
    this.filteredOptions = this.employeeFilterControl.valueChanges
    .pipe(
      startWith(''),
      map(employee => employee && typeof employee === 'object' ? this.displayFn(employee) : employee),
      map((name: string) => name ? this._filter(name) : this.employees.slice())
    );

    this.getEmployees();
    this.getEmployeeLoans();
  }

  private _filter(value: string): string[] {
    if (value != null) {
      const filterValue = value.toLowerCase();
      if (this.employees.filter(employee => (employee.first_name + employee.middle_name + employee.last_name).toLowerCase().includes(filterValue)).length > 0) {
        return this.employees.filter(employee => (employee.first_name + employee.middle_name + employee.last_name).toLowerCase().includes(filterValue));
      } else {
        return this.employees.filter(employee => employee.username.includes(filterValue));
      }
    }

  }

  displayFn = (employee) => {
    return employee ? this.getEmployeeFullName(employee) : '';
  }

  toTitleCase(str) {
    return str.replace(/\s\s+/g, ' ').trim().split(' ')
      .map(w => w[0].toUpperCase() + w.substr(1).toLowerCase())
      .join(' ');

  }

  getEmployeeFullName(employee) {
    let fullName = employee.first_name;
    if (employee.middle_name) {
      fullName += " " + employee.middle_name;
    }
    if(employee.last_name){
      fullName += " " + employee.last_name;
    }
    return this.toTitleCase(fullName);
  }

  getEmployees() {
    this.employeeService.getWageEmployeesAll().subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.employees = sResponse.data;
      } else {
        this.toastr.error('Failed to Get Employee Records, Please Try Again');
      }
    });
  }

  getEmployeeLoans() {
    this.employeeLoanService.getEmployeeLoans().subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.employeeLoans = sResponse.data;
        this.employeeLoans.forEach(employee => {
          employee.full_name=this.displayFn(employee);
        });
      } else {
        this.toastr.error('Failed to Get Employee Loan Records, Please Try Again');
      }
    });
  }


  onEmployeeLoanSubmit(){
    const postLotModel = JSON.parse(JSON.stringify(this.employeeLoanModel));

    this.employeeLoanService.saveEmployeeLoan(postLotModel).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Employee Loan Record Saved Successfully');
          this.resetForm();
        } else {
          this.toastr.error('Failed to Create Employee Loan Record, Please Try Again');
        }
        this.getLoanTransactionsAll(this.employeeLoanModel.employee_id);
      });
  }

  getLoanTransactionsAll(id) {
    this.employeeLoanModel.employee_id = id;

    let params = new HttpParams();
    params = params.append('employee_id', this.employeeLoanModel.employee_id);

    this.employeeLoanTransactions = [];

    this.employeeLoanService.getEmployeeLoanTransactions(params).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.employeeLoanTransactions = sResponse.data;
          this.showEmployeeLoans=false;
        } else {
          this.toastr.error('Failed to get Employee Loan Transactions, Please Try Again');
        }
      });

  }

  resetForm(event = null) {
    if (event) {
      this.employeeLoanForm.resetForm();
    } else {
      this.employeeLoanForm.resetForm(this.employeeLoanForm.value);
    }
    delete this.employeeLoanModel.id;
  }

  deleteLoanEntryById(loanEntry) {
    this.employeeLoanService.deleteEmployeeLoanTransactionsById(loanEntry.id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Successfully Deleted Loan Entry');
          if (loanEntry.id == this.employeeLoanModel.id) {
            this.resetForm();
          }
        } else {
          this.toastr.error('Failed to Delete Loan Entry, Please Try Again');
        }
        this.getLoanTransactionsAll(this.employeeLoanModel.employee_id);
      }
    );
  }

  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

}