import { Component, OnInit, ViewChild } from '@angular/core';
import { EntryType } from './../../../../models/entry.type';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import {EntryTypeService} from './../../../mpc/shared/entry.type.service';

@Component({
  selector: 'app-entry-type',
  templateUrl: './entry-type.component.html',
  styleUrls: ['./entry-type.component.scss']
})
export class EntryTypeComponent implements OnInit {

  @ViewChild('entryTypeForm') entryTypeForm: NgForm;

  displayedColumns = ['updated_date', 'label','action'];
  entryTypes: EntryType[] = [];
  entryTypeModel: EntryType = new EntryType();

  constructor(private entryTypeService: EntryTypeService, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.getAllEntryTypes();
  }

  getAllEntryTypes(reset=true){
    this.entryTypes = [];

    this.entryTypeService.getAllEntryTypes().subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.entryTypes = sResponse.data;
        } else {
          this.toastr.error('Failed to Get All Entry Types, Please Try Again');
        }
      });
  }

  onEntryTypeSubmit() {

    const postEntryTypeModel = JSON.parse(JSON.stringify(this.entryTypeModel));

    this.entryTypeService.saveEntryType(postEntryTypeModel).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Entry Type Saved Successfully');
          this.resetForm();
        } else {
          this.toastr.error('Failed to Save Entry Type Entry, Please Try Again');
        }
        this.getAllEntryTypes();
      }
    );
  }

  deleteEntryTypeById(grade) {
    this.entryTypeService.deleteEntryTypeById(grade.id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Successfully Deleted Entry Type');
          if (grade.id == this.entryTypeModel.id) {
            this.resetForm();
          }
        } else {
          this.toastr.error('Failed to Delete Entry Type Entry, Please Try Again');
        }
        this.getAllEntryTypes(false);
      }
    );
  }

  resetForm(event = null) {
    if (event) {
      this.entryTypeForm.resetForm(this.entryTypeForm.value);
    } else {
      this.entryTypeForm.resetForm();
    }
    delete this.entryTypeModel.id;
  }

}
