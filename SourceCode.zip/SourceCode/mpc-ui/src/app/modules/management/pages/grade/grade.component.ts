import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { Grade } from './../../../../models/grade';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import {GradeService} from './../../../mpc/shared/grade.service';


@Component({
  selector: 'app-grade',
  templateUrl: './grade.component.html',
  styleUrls: ['./grade.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class GradeComponent implements OnInit {

  @ViewChild('gradeForm') gradeForm: NgForm;

  displayedColumns = ['updated_date', 'name','action'];
  grades: Grade[] = [];
  gradeModel: Grade = new Grade();

  constructor(private gradeService: GradeService, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.getAllGrades();
  }

  getAllGrades(reset=true){
    this.grades = [];

    this.gradeService.getAllGrades().subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.grades = sResponse.data;
        } else {
          this.toastr.error('Failed to Get All Grades, Please Try Again');
        }
      });
  }

  onGradeSubmit() {

    const postGradeModel = JSON.parse(JSON.stringify(this.gradeModel));

    this.gradeService.saveGrade(postGradeModel).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Grade Saved Successfully');
          this.resetForm();
        } else {
          this.toastr.error('Failed to Save Grade Entry, Please Try Again');
        }
        this.getAllGrades();
      }
    );
  }

  deleteGradeById(grade) {
    this.gradeService.deleteGradeById(grade.id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Successfully Deleted Grade');
          if (grade.id == this.gradeModel.id) {
            this.resetForm();
          }
        } else {
          this.toastr.error('Failed to Delete Grade Entry, Please Try Again');
        }
        this.getAllGrades(false);
      }
    );
  }

  resetForm(event = null) {
    if (event) {
      this.gradeForm.resetForm();
    } else {
      this.gradeForm.resetForm(this.gradeForm.value);
    }
    delete this.gradeModel.id;
  }

}