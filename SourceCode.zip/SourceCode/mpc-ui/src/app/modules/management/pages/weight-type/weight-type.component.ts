import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { WeightType } from './../../../../models/weight.type';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import {WeightTypeService} from './../../../mpc/shared/weight.type.service';
import { departments } from 'src/app/modules/shared/services/department.model';
import { HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-weight-type',
  templateUrl: './weight-type.component.html',
  styleUrls: ['./weight-type.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class WeightTypeComponent implements OnInit {

  @ViewChild('weightTypeForm') weightTypeForm: NgForm;

  displayedColumns = ['updated_date', 'label','action'];
  weightTypes: WeightType[] = [];
  weightTypeModel: WeightType = new WeightType();
  departments = [];
  departmentValue = null;
  departmentSearchText = 'Sorting Machine';
  entryTypes = ['In', 'Out'];
  showEntryType = false;
  showWeightType = false;

  constructor(private weightTypeService: WeightTypeService, private toastr: ToastrService) { 
    this.departments = departments;
  }

  ngOnInit(): void {

  }

  onWeightTypeSubmit() {

    const postWeightTypeModel = JSON.parse(JSON.stringify(this.weightTypeModel));

    this.weightTypeService.saveWeightType(postWeightTypeModel).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Weight Type Saved Successfully');
          this.getAllWeightTypes();
          this.resetForm(true);
        } else if (String(sResponse.trace).includes('duplicate key error')) {
          this.toastr.error('This Weight Type Entry Already Exists');
        }
        else {
          this.toastr.error('Failed to Save Weight Type Entry, Please Try Again');
        }
      }
    );
  }

  deleteWeightTypeById(grade) {
    this.weightTypeService.deleteWeightTypeById(grade.id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Successfully Deleted Weight Type');
          if (grade.id == this.weightTypeModel.id) {
            this.resetForm();
          }
        } else {
          this.toastr.error('Failed to Delete Weight Type Entry, Please Try Again');
        }
        this.getAllWeightTypes();
      }
    );
  }

  resetForm(event = null) {
    if (event) {
      this.weightTypeForm.resetForm(this.weightTypeForm.value);
    } else {
      this.weightTypeForm.resetForm();
    }
    delete this.weightTypeModel.id;
    delete this.weightTypeModel.label;
  }

  onEntryTypeChange(){
    this.weightTypes = [];
    this.getAllWeightTypes();
    this.showWeightType=true;
  }

  onDepartmentChange(){
    this.showEntryType=true;
  }

  getAllWeightTypes(){

    this.weightTypes=[];

    let params = new HttpParams();
    params = params.append('department', this.weightTypeModel.department);
    params = params.append('entry_type', this.weightTypeModel.entry_type);
    
    this.weightTypeService.getAllWeightTypes(params).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.weightTypes = sResponse.data;
        } else {
          this.toastr.error('Failed to Get All Weight Types, Please Try Again');
        }
      });
  }

}
