import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { Machine } from './../../../../models/machine';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import {MachineService} from './../../../mpc/shared/machine.service';

@Component({
  selector: 'app-machine',
  templateUrl: './machine.component.html',
  styleUrls: ['./machine.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class MachineComponent implements OnInit {

  @ViewChild('machineForm') machineForm: NgForm;

  displayedColumns = ['updated_date', 'name','type','action'];
  machines: Machine[] = [];
  machineModel: Machine = new Machine();
  machineTypes = [{
    key: 'cutting',
    label: 'Cutting'
  },{
    key: 'peeling',
    label: 'Peeling'
  },{
    key: 'sorting',
    label: 'Sorting'
  },{
    key: 'grading',
    label: 'Grading'
  }];

  constructor(private machineService: MachineService, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.getAllMachines();
  }

  getAllMachines(reset=true){
    this.machines = [];

    this.machineService.getAllMachines().subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.machines = sResponse.data;
        } else {
          this.toastr.error('Failed to Get All Machines, Please Try Again');
        }
      });
  }

  onMachineSubmit() {

    const postMachineModel = JSON.parse(JSON.stringify(this.machineModel));

    this.machineService.saveMachine(postMachineModel).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Machine Saved Successfully');
          this.resetForm();
        } else {
          this.toastr.error('Failed to Save Machine Entry, Please Try Again');
        }
        this.getAllMachines();
      }
    );
  }

  deleteMachineById(machine) {
    this.machineService.deleteMachineById(machine.id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Successfully Deleted Machine');
          if (machine.id == this.machineModel.id) {
            this.resetForm();
          }
        } else {
          this.toastr.error('Failed to Delete Machine Entry, Please Try Again');
        }
        this.getAllMachines(false);
      }
    );
  }

  resetForm(event = null) {
    if (event) {
      this.machineForm.resetForm();
    } else {
      this.machineForm.resetForm(this.machineForm.value);
    }
    delete this.machineModel.id;
  }

}
