import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WeightTypeComponent } from './weight-type.component';

describe('WeightTypeComponent', () => {
  let component: WeightTypeComponent;
  let fixture: ComponentFixture<WeightTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WeightTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WeightTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
