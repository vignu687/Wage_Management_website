import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MasterSettingsService } from './../../shared/master-settings.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-master-settings',
  templateUrl: './master-settings.component.html',
  styleUrls: ['./master-settings.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class MasterSettingsComponent implements OnInit {

  settingsModel = null;
  settingsUntouchedModel = null;
  panelOpenState = true;

  conditions = [
    {
      id: '1',
      key: 'greater_equal',
      label: '>='
    },
    {
      id: '2',
      key: 'less_equal',
      label: '<='
    }, {
      id: '3',
      key: 'equal',
      label: '='
    }, {
      id: '4',
      key: 'greater',
      label: '>'
    }, {
      id: '5',
      key: 'less',
      label: '<'
    }
  ]

  constructor(private settingService: MasterSettingsService, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.getSettingsAll();
  }


  getSettingsAll() {
    this.settingService.getSettings().subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.setModelData(sResponse.data);
      } else {
        this.toastr.error('Failed to Get All Master Settings, Please Try Again');
      }
    });
  }

  onSettingsSubmit(form, key) {

    let postModel: any = {};
    postModel.id = JSON.parse(JSON.stringify(this.settingsModel.id));
    postModel[key] = JSON.parse(JSON.stringify(this.settingsModel[key]));
    console.log(postModel);
    this.settingService.saveSettings(postModel).subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.setModelData(sResponse.data);
        this.toastr.success('Master Settings Saved Successfully');
      } else {
        this.toastr.error('Failed to Save Master Settings, Please Try Again');
      }
    });

  }

  resetForm(form, key) {
    this.settingsModel[key] = JSON.parse(JSON.stringify(this.settingsUntouchedModel[key]))
  }

  setModelData(data) {
    this.settingsUntouchedModel = JSON.parse(JSON.stringify(data));
    this.settingsModel = JSON.parse(JSON.stringify(data));
  }

}
