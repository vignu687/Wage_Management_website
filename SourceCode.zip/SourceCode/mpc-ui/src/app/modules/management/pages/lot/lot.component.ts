import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { Lot } from './../../../../models/lot';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import {OriginService} from './../../../mpc/shared/origin.service';
import {LotService} from './../../../mpc/shared/lot.service';
import { Origin } from 'src/app/models/origin';
import { SharedService } from 'src/app/modules/shared/services/shared.service';

@Component({
  selector: 'app-lot',
  templateUrl: './lot.component.html',
  styleUrls: ['./lot.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class LotComponent implements OnInit {

  @ViewChild('lotForm') lotForm: NgForm;

  displayedColumns = ['updated_date', 'name'];
  lots: Lot[] = [];
  origins: Origin[] = [];
  lotModel: Lot = new Lot();
  numberOfLotsToCreate : number;
  currentDate = new Date();

  constructor(private originService: OriginService, private lotService: LotService,private sharedService: SharedService, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.getAllOrigins();
    this.lotModel.date = this.sharedService.getDateOnly(this.currentDate);
  }

  getAllOrigins(reset=true){
    this.origins = [];

    this.originService.getAllOrigins().subscribe(
      sResponse => {
        if (sResponse.status) {
          this.origins = sResponse.data;
        }
      },
      sError => { }
    );
  }

  resetForm(event = null) {
    if (event) {
      this.lotForm.resetForm();
    } else {
      this.lotForm.resetForm(this.lotForm.value);
    }
    delete this.lotModel.id;
  }

  onOriginChange(){
    this.getLotsByOriginId();
    this.getOriginName();
  }

  getLotsByOriginId() {
    this.lots=[];
    const origin_id = JSON.parse(JSON.stringify(this.lotModel.origin_id));
    this.lotService.getLotsByOriginId(origin_id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.lots = sResponse.data;
        } else {
          this.toastr.error('Failed to Get Lots for Selected Origin, Please Try Again');
        }
      });
  }

  getOriginName(){
    this.originService.getOriginById(this.lotModel.origin_id).subscribe(
      sResponse => {
        if(sResponse.status && !sResponse.message){
          this.lotModel.origin_name = sResponse.data.name;
        } else {
          this.toastr.error('Failed to Get Origin Name, Please Try Again');
        }
      });
  }

  onDateChange(event) {
    this.lotModel.date = this.sharedService.getDateOnly(this.lotModel.date);
  }

  onLotSubmit(){
    this.lotModel.count=this.numberOfLotsToCreate;
    const postLotModel = JSON.parse(JSON.stringify(this.lotModel));

    this.lotService.createLots(postLotModel).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Lot(s) Created Successfully');
          this.resetForm();
        } else {
          this.toastr.error('Failed to Create Lot(s), Please Try Again');
        }
        this.getLotsByOriginId();
      });
  }

}
