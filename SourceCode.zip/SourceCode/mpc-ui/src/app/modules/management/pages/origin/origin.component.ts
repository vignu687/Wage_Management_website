import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { Origin } from './../../../../models/origin';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import {OriginService} from './../../../mpc/shared/origin.service';


@Component({
  selector: 'app-origin',
  templateUrl: './origin.component.html',
  styleUrls: ['./origin.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class OriginComponent implements OnInit {

  @ViewChild('originForm') originForm: NgForm;

  displayedColumns = ['updated_date', 'name'];
  origins: Origin[] = [];
  originModel: Origin = new Origin();

  constructor(private originService: OriginService, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.getAllOrigins();
  }

  getAllOrigins(reset=true){
    this.origins = [];

    this.originService.getAllOrigins().subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.origins = sResponse.data;
        } else {
          this.toastr.error('Failed to Get All Origins, Please Try Again');
        }
      });
  }

  onOriginSubmit() {

    const postOriginModel = JSON.parse(JSON.stringify(this.originModel));

    this.originService.saveOrigin(postOriginModel).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Origin Saved Successfully');
          this.resetForm();
        } else  {
          this.toastr.error('Failed to Save Origin Entry, Please Try Again');
        }
        this.getAllOrigins();
      }
    );
  }

  resetForm(event = null) {
    if (event) {
      this.originForm.resetForm();
    } else {
      this.originForm.resetForm(this.originForm.value);
    }
    delete this.originModel.id;
  }

}
