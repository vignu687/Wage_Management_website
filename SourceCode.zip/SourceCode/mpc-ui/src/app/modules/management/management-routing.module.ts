import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppFullLayoutComponent } from 'src/app/layouts/app-full-layout/app-full-layout.component';
import { AddEmployeeComponent } from './components/add-employee/add-employee.component';
import { ManagementComponent } from './management.component';
import { EmployeesComponent } from './pages/employees/employees.component';
import { GradeComponent } from './pages/grade/grade.component';
import { LotComponent } from './pages/lot/lot.component';
import { MachineComponent } from './pages/machine/machine.component';
import { MasterSettingsComponent } from './pages/master-settings/master-settings.component';
import { OriginComponent } from './pages/origin/origin.component';
import { WeightTypeComponent } from './pages/weight-type/weight-type.component';
import { EntryTypeComponent } from './pages/entry-type/entry-type.component';
import { AuthGuardService } from '../shared/services/auth-guard.service';
import { EmployeeLoanComponent } from './pages/employee-loan/employee-loan.component';

const routes: Routes = [
  {
    path: '',
    component: AppFullLayoutComponent,
    children: [
      { path: '', component: ManagementComponent,
      canActivate: [AuthGuardService],
      data: {
        breadcrumb: 'Management',
        access: 'management'
        }
      },
      {
        path: 'employees', component: EmployeesComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Employee Management',
          access: 'management'
        }
      },
      {
        path: 'add-employee', component: AddEmployeeComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Add Employee',
          access: 'management'
        }
      },
      {
        path: 'master-settings', component: MasterSettingsComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Master Settings',
          access: 'management'
        }
      },
      {
        path: 'origin-settings', component: OriginComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Origin Settings',
          access: 'management'
        }
      },
      {
        path: 'lot-settings', component: LotComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Lot Settings',
          access: 'management'
        }
      },
      {
        path: 'grade-settings', component: GradeComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Grade Settings',
          access: 'management'
        }
      },
      {
        path: 'machine-settings', component: MachineComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Machine Settings',
          access: 'management'
        }
      },
      {
        path: 'weight-type-settings', component: WeightTypeComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Weight Type Settings',
          access: 'management'
        }
      },
      {
        path: 'entry-type-settings', component: EntryTypeComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Entry Type Settings',
          access: 'management'
        }
      },
      {
        path: 'employee-loan', component: EmployeeLoanComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Employee Loan',
          access: 'management'
        }
      }
    ]
  }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],

  exports: [RouterModule]
})
export class ManagementRoutingModule { }
