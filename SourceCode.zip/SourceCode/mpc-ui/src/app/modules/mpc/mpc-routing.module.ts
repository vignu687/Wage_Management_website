import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppFullLayoutComponent } from '../../layouts/app-full-layout/app-full-layout.component';
import { CoolingComponent } from './components/cooling/cooling.component';
import { FinalOvenEntryComponent } from './components/final-oven-entry/final-oven-entry.component';
import { HumanCuttingComponent } from './components/human-cutting/human-cutting.component';
import { MachineCuttingComponent } from './components/machine-cutting/machine-cutting.component';
import { MachineGradingComponent } from './components/machine-grading/machine-grading.component';
import { MachinePeelingComponent } from './components/machine-peeling/machine-peeling.component';
import { SortingMachineComponent } from './components/sorting-machine/sorting-machine.component';
import { RoastingComponent } from './components/roasting/roasting.component';
import { OvenHeatingComponent } from './components/oven-heating/oven-heating.component';
import { HumanPeelingComponent } from './components/human-peeling/human-peeling.component';
import { HumanGradingComponent } from './components/human-grading/human-grading.component';
import { ViewWageComponent } from './components/view-wage/view-wage.component';
import { MpcComponent } from './mpc.component';
import { ViewWageEmployeeComponent } from './components/view-wage-employee/view-wage-employee.component';
import { PayrollEntryComponent } from './components/payroll-entry/payroll-entry.component';
import { AuthGuardService } from '../shared/services/auth-guard.service';

const routes: Routes = [{
  path: '', component: AppFullLayoutComponent,
  children: [{
    path: '', component: MpcComponent,
    children: [
      {
        path: 'cooling', component: CoolingComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Cooling Entry',
          access: 'cooling'
        }
      }, {
        path: 'final-oven', component: FinalOvenEntryComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Final Oven Entry',
          access: 'final_oven_entry'
        }
      }, {
        path: 'human-cutting', component: HumanCuttingComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Human Cutting',
          access: 'human_cutting'
        }
      }, {
        path: 'machine-cutting', component: MachineCuttingComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Machine Cutting',
          access: 'machine_cutting'
        }
      }, {
        path: 'machine-grading', component: MachineGradingComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Machine Grading',
          access: 'machine_grading'
        }
      }, {
        path: 'machine-peeling', component: MachinePeelingComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Machine Peeling',
          access: 'machine_peeling'
        }
      }, {
        path: 'human-peeling', component: HumanPeelingComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Human Peeling',
          access: 'human_peeling'
        }
      }, {
        path: 'human-grading', component: HumanGradingComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Human Grading',
          access: 'human_grading'
        }
      }, {
        path: 'sorting-machine', component: SortingMachineComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Sorting Machine',
          access: 'sorting_machine'
        }
      }, {
        path: 'oven-heating', component: OvenHeatingComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Over Heating',
          access: 'oven_heating'
        }
      }, {
        path: 'roasting', component: RoastingComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Roasting',
          access: 'roasting'
        }
      }, {
        path: 'view-wage', component: ViewWageComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'View Wage',
          access: 'view_wage'
        }
      }, {
        path: 'view-wage-employee', component: ViewWageEmployeeComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'View Wage',
          access: 'view_wage_employee'
        }
      }, {
        path: 'payroll-entry', component: PayrollEntryComponent,
        canActivate: [AuthGuardService],
        data: {
          breadcrumb: 'Payroll Entry',
          access: 'payroll_entry'
        }
      }
    ]
  }
  ]

}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MpcRoutingModule { }
