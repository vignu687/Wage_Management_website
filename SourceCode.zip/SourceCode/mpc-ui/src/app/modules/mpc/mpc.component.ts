import { Component, OnInit } from '@angular/core';
import { MpcService } from './shared/mpc.service';

@Component({
  selector: 'app-mpc',
  templateUrl: './mpc.component.html',
  styleUrls: ['./mpc.component.scss']
})
export class MpcComponent implements OnInit {

  constructor(private mpcService: MpcService) { }

  ngOnInit(): void {
    this.getOrigins();
  }


  getOrigins() {
    
    this.mpcService.getorigins().subscribe(sResponse => {

    });
  }
}
