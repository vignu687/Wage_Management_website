import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MpcRoutingModule } from './mpc-routing.module';
import { MpcComponent } from './mpc.component';
import { RoastingComponent } from './components/roasting/roasting.component';
import { SortingMachineComponent } from './components/sorting-machine/sorting-machine.component';
import { MachinePeelingComponent } from './components/machine-peeling/machine-peeling.component';
import { MachineGradingComponent } from './components/machine-grading/machine-grading.component';
import { MachineCuttingComponent } from './components/machine-cutting/machine-cutting.component';
import { HumanCuttingComponent } from './components/human-cutting/human-cutting.component';
import { FinalOvenEntryComponent } from './components/final-oven-entry/final-oven-entry.component';
import { CoolingComponent } from './components/cooling/cooling.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AngularMaterialModule } from 'src/app/angular.material.module';
import { SharedModule } from '../shared/shared.module';
import { WageHeaderComponent } from './components/wage-header/wage-header.component';
import { OvenHeatingComponent } from './components/oven-heating/oven-heating.component';
import { HumanPeelingComponent } from './components/human-peeling/human-peeling.component';
import { HumanGradingComponent } from './components/human-grading/human-grading.component';
import { ViewWageComponent } from './components/view-wage/view-wage.component';
import { MpcGridComponent } from './components/mpc-grid/mpc-grid.component';
import { ViewWageEmployeeComponent } from './components/view-wage-employee/view-wage-employee.component';
import { PayrollEntryComponent } from './components/payroll-entry/payroll-entry.component';


@NgModule({
  declarations: [MpcComponent, RoastingComponent, SortingMachineComponent, MachinePeelingComponent, MachineGradingComponent, MachineCuttingComponent, HumanCuttingComponent, FinalOvenEntryComponent, CoolingComponent, WageHeaderComponent, OvenHeatingComponent, HumanPeelingComponent, HumanGradingComponent, ViewWageComponent, ViewWageEmployeeComponent, PayrollEntryComponent],
  imports: [
    CommonModule,
    FormsModule,
    FlexLayoutModule,
    AngularMaterialModule,
    SharedModule,
    MpcRoutingModule,
    ReactiveFormsModule
  ]
})
export class MpcModule { }
