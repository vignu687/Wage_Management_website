import { Injectable } from '@angular/core';
import { ApiService } from './../../shared/services/api.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RoastingService {

  constructor(private apiService: ApiService) { }

  getRoastings(queryParams): Observable<any> {
    return this.apiService.getRequest('roastings', null, queryParams);
  }

  saveRoastings(requestModel): Observable<any> {

    if (requestModel.id) {
      return this.apiService.putRequest('roastings', requestModel.id, requestModel);
    } else {
      return this.apiService.postRequest('roastings', requestModel);
    }

  }

  getRoastingById(id): Observable<any> {
    return this.apiService.getRequest(`roastings/`, id);
  }

  deleteRoastingById(id): Observable<any> {
    return this.apiService.deleteRequest(`roastings/`, id);
  }

}
