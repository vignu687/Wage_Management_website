import { Injectable } from '@angular/core';
import { ApiService } from './../../shared/services/api.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class WeightTypeService {

  constructor(private apiService: ApiService) { }

  getAllWeightTypes(queryParms): Observable<any> {
    return this.apiService.getRequest('weight-types', null,queryParms);
  }

  saveWeightType(requestModel): Observable<any> {

    if (requestModel.id) {
      return this.apiService.putRequest('weight-types', requestModel.id, requestModel);
    } else {
      return this.apiService.postRequest('weight-types', requestModel);
    }
  }

  deleteWeightTypeById(id): Observable<any> {
    return this.apiService.deleteRequest('weight-types/', id);
  }

}
