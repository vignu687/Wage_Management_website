import { Injectable } from '@angular/core';
import { ApiService } from './../../shared/services/api.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FinalOvenService {

  constructor(private apiService: ApiService) { }

  getFinalOvens(queryParams): Observable<any> {
    return this.apiService.getRequest('final-ovens', null, queryParams);
  }

  saveFinalOvens(requestModel): Observable<any> {
    if (requestModel.id) {
      return this.apiService.putRequest('final-ovens', requestModel.id, requestModel);
    } else {
      return this.apiService.postRequest('final-ovens', requestModel);
    }

  }

  getFinalOvenById(id): Observable<any> {
    return this.apiService.getRequest('final-ovens/', id);
  }

  deleteFinalOvenById(id): Observable<any> {
    return this.apiService.deleteRequest('final-ovens/', id);
  }

}
