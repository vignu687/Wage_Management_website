import { Injectable } from '@angular/core';
import { Observable, } from 'rxjs';
import { ApiService } from './../../shared/services/api.service';

@Injectable({
  providedIn: 'root'
})
export class ViewWageService {

  constructor(private apiService: ApiService) { }

  getViewWageAll(queryParams): Observable<any> {
    return this.apiService.getRequest('view-wages', null, queryParams);
  }
}
