import { Injectable } from '@angular/core';
import { ApiService } from './../../shared/services/api.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MachineCuttingService {

  constructor(private apiService: ApiService) { }

  getMachineCuttings(queryParams): Observable<any> {
    return this.apiService.getRequest('machine-cuttings', null, queryParams);
  }

  saveMachineCuttings(requestModel): Observable<any> {
    if (requestModel.id) {
      return this.apiService.putRequest('machine-cuttings', requestModel.id, requestModel);
    } else {
      return this.apiService.postRequest('machine-cuttings', requestModel);
    }

  }

  getMachineCuttingById(id): Observable<any> {
    return this.apiService.getRequest('machine-cuttings/', id);
  }

  deleteMachineCuttingById(id): Observable<any> {
    return this.apiService.deleteRequest('machine-cuttings/', id);
  }

}
