import { Injectable } from '@angular/core';
import { ApiService } from './../../shared/services/api.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LotService {

  constructor(private apiService: ApiService) { }

  getLotsByOriginId(origin_id): Observable<any> {
    return this.apiService.getRequest(`origins/${origin_id}/lots`);
  }

  createLots(requestModel): Observable<any> {
    return this.apiService.postRequest(`origins/${requestModel.origin_id}/lots`, requestModel);
  }

}
