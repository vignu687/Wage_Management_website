import { Injectable } from '@angular/core';
import { ApiService } from './../../shared/services/api.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MachineGradingService {

  constructor(private apiService: ApiService) { }

  getMachineGradings(queryParams): Observable<any> {
    return this.apiService.getRequest('machine-gradings', null, queryParams);
  }

  saveMachineGradings(requestModel): Observable<any> {

    if (requestModel.id) {
      return this.apiService.putRequest('machine-gradings', requestModel.id, requestModel);
    } else {
      return this.apiService.postRequest('machine-gradings', requestModel);
    }

  }

  getMachineGradingById(id): Observable<any> {
    return this.apiService.getRequest('machine-gradings/', id);
  }

  deleteMachineGradingById(id): Observable<any> {
    return this.apiService.deleteRequest('machine-gradings/', id);
  }

}