import { Injectable } from '@angular/core';
import { ApiService } from './../../shared/services/api.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HumanCuttingService {

  constructor(private apiService: ApiService) { }

  getHumanCuttingDescriptions(): Observable<any> {
    return this.apiService.getRequest('human-cuttings/descriptions', null);
  }

  getHumanCuttings(queryParams): Observable<any> {
    return this.apiService.getRequest('human-cuttings', null, queryParams);
  }

  saveHumanCutting(requestModel): Observable<any> {

    if (requestModel.id) {
      return this.apiService.putRequest('human-cuttings', requestModel.id, requestModel);
    } else {
      return this.apiService.postRequest('human-cuttings', requestModel);
    }

  }

  getHumanCuttingById(id): Observable<any> {
    return this.apiService.getRequest(`human-cuttings/`, id);
  }

  deleteHumanCuttingById(id): Observable<any> {
    return this.apiService.deleteRequest(`human-cuttings/`, id);
  }

  getQuestionsByDescription(description_key): Observable<any> {
    return this.apiService.getRequest(`human-cuttings/descriptions/${description_key}/questions`);
  }

}
