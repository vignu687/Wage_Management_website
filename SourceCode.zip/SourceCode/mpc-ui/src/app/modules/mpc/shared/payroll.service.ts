import { Injectable } from '@angular/core';
import { ApiService } from '../../shared/services/api.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PayrollService {

  constructor(private apiService: ApiService) { }

  getPayrollEntriesAll(queryParams): Observable<any> {
    return this.apiService.getRequest('payroll-entry', null, queryParams);
  }

  savePayrollEntry(requestModel): Observable<any> {

    if (requestModel.id) {
      return this.apiService.putRequest('payroll-entry', requestModel.id, requestModel);
    } else {
      return this.apiService.postRequest('payroll-entry', requestModel);
    }

  }

  getPayrollEntryById(id): Observable<any> {
    return this.apiService.getRequest(`payroll-entry/`, id);
  }

  deletePayrollEntryById(id): Observable<any> {
    return this.apiService.deleteRequest(`payroll-entry/`, id);
  }

}
