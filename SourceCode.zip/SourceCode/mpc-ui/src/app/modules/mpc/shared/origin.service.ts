import { Injectable } from '@angular/core';
import { ApiService } from './../../shared/services/api.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OriginService {

  constructor(private apiService: ApiService) { }

  getAllOrigins(): Observable<any> {
    return this.apiService.getRequest('origins', null);
  }

  saveOrigin(requestModel): Observable<any> {

    if (requestModel.id) {
      return this.apiService.putRequest('origins', requestModel.id, requestModel);
    } else {
      return this.apiService.postRequest('origins', requestModel);
    }

  }

  getOriginById(id): Observable<any> {
    return this.apiService.getRequest('origins/', id);
  }

}
