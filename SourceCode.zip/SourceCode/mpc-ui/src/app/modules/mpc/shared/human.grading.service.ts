import { Injectable } from '@angular/core';
import { ApiService } from './../../shared/services/api.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HumanGradingService {

  constructor(private apiService: ApiService) { }

  getHumanGradingDescriptions(): Observable<any> {
    return this.apiService.getRequest('human-gradings/descriptions', null);
  }

  getHumanGradings(queryParams): Observable<any> {
    return this.apiService.getRequest('human-gradings', null, queryParams);
  }

  saveHumanGrading(requestModel): Observable<any> {

    if (requestModel.id) {
      return this.apiService.putRequest('human-gradings', requestModel.id, requestModel);
    } else {
      return this.apiService.postRequest('human-gradings', requestModel);
    }

  }

  getHumanGradingById(id): Observable<any> {
    return this.apiService.getRequest(`human-gradings/`, id);
  }

  deleteHumanGradingById(id): Observable<any> {
    return this.apiService.deleteRequest(`human-gradings/`, id);
  }

  getQuestionsByDescription(description_key): Observable<any> {
    return this.apiService.getRequest(`human-gradings/descriptions/${description_key}/questions`);
  }

}