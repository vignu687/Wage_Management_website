import { Injectable } from '@angular/core';
import { ApiService } from './../../shared/services/api.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GradeService {

  constructor(private apiService: ApiService) { }

  getAllGrades(): Observable<any> {
    return this.apiService.getRequest('grades', null);
  }

  saveGrade(requestModel): Observable<any> {

    if (requestModel.id) {
      return this.apiService.putRequest('grades', requestModel.id, requestModel);
    } else {
      return this.apiService.postRequest('grades', requestModel);
    }
  }

  deleteGradeById(id): Observable<any> {
    return this.apiService.deleteRequest('grades/', id);
  }

}
