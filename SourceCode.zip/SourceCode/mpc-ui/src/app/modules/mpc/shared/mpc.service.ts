import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from './../../shared/services/api.service';
import { map } from 'rxjs/operators';
import { MpcBaseService } from './mpc-base.service';

@Injectable({
  providedIn: 'root'
})
export class MpcService extends MpcBaseService {

  constructor(private apiService: ApiService) {
    super();
  }

  getorigins(): Observable<any> {
    return this.apiService.getRequest('origins/').pipe(map(
      sResponseModel => {
        
        this.setOriginsLocal(sResponseModel.data);
        return sResponseModel.data;
      }));
  }

  getLotsByOrigin(origin_id): Observable<any> {
    return this.apiService.getRequest(`origins/${origin_id}/lots`).pipe(map(
      sResponseModel => {
        return sResponseModel.data;
      }));
  }

}
