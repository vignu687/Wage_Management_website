import { Injectable } from '@angular/core';
import { ApiService } from './../../shared/services/api.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MachineService {

  constructor(private apiService: ApiService) { }

  getAllMachines(): Observable<any> {
    return this.apiService.getRequest('machines', null);
  }

  getAllMachinesByType(type): Observable<any> {
    return this.apiService.getRequest('machines/type', type);
  }

  saveMachine(requestModel): Observable<any> {

    if (requestModel.id) {
      return this.apiService.putRequest('machines', requestModel.id, requestModel);
    } else {
      return this.apiService.postRequest('machines', requestModel);
    }
  }

  deleteMachineById(id): Observable<any> {
    return this.apiService.deleteRequest('machines/', id);
  }

}
