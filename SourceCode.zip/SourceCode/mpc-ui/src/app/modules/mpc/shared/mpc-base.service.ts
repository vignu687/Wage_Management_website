import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MpcBaseService {

  private origins = null;
  constructor() { }

  getOriginsLocal(key: any = null) {

    if (!this.origins && sessionStorage.getItem('origins')) {
      this.origins = JSON.parse(
        sessionStorage.getItem('origins')
      );
    }
    return this.origins;
  }

  setOriginsLocal(sData) {
    if (sData) {
      this.origins = sData;
      sessionStorage.setItem("origins", JSON.stringify(sData));
    } else {
      this.origins = null;
      sessionStorage.removeItem("origins");
    }
  }

}
