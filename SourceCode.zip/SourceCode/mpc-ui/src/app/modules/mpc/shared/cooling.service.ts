import { Injectable } from '@angular/core';
import { ApiService } from './../../shared/services/api.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CoolingService {

  constructor(private apiService: ApiService) { }

  getCoolings(queryParams): Observable<any> {
    return this.apiService.getRequest('coolings', null, queryParams);
  }

  saveCoolings(requestModel): Observable<any> {

    if (requestModel.id) {
      return this.apiService.putRequest('coolings', requestModel.id, requestModel);
    } else {
      return this.apiService.postRequest('coolings', requestModel);
    }
  }

  getCoolingsById(id): Observable<any> {
    return this.apiService.getRequest(`coolings/`, id);
  }

  deleteCoolingsById(id): Observable<any> {
    return this.apiService.deleteRequest(`coolings/`, id);
  }

}
