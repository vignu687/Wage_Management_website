import { Injectable } from '@angular/core';
import { ApiService } from '../../shared/services/api.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeLoanService {

  constructor(private apiService: ApiService) { }

  getEmployeeLoans(): Observable<any> {
    return this.apiService.getRequest('employee-loans/all', null);
  }

  getEmployeeLoanTransactions(queryParams): Observable<any> {
    return this.apiService.getRequest('employee-loans', null, queryParams);
  }

  saveEmployeeLoan(requestModel): Observable<any> {
    return this.apiService.postRequest('employee-loans', requestModel);
  }


  deleteEmployeeLoanTransactionsById(id): Observable<any> {
    return this.apiService.deleteRequest(`employee-loans`, id);
  }

}
