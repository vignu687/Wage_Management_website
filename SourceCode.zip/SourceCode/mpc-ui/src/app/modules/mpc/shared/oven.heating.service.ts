import { Injectable } from '@angular/core';
import { ApiService } from './../../shared/services/api.service';
import { Observable } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class OvenHeatingService {

  constructor(private apiService: ApiService, private toastr: ToastrService) { }

  getOvenHeatings(queryParams): Observable<any> {
    return this.apiService.getRequest('oven-heatings', null, queryParams);
  }

  saveOvenHeatings(requestModel): Observable<any> {

    if (requestModel.id) {
      return this.apiService.putRequest('oven-heatings', requestModel.id, requestModel);
    } else {
      return this.apiService.postRequest('oven-heatings', requestModel);
    }

  }

  getOvenHeatingById(id): Observable<any> {
    return this.apiService.getRequest(`oven-heatings/`, id);
  }

  deleteOvenHeatingById(id): Observable<any> {
    return this.apiService.deleteRequest(`oven-heatings/`, id);
  }

}
