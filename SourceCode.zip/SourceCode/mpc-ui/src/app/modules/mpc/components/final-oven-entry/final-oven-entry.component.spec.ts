import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinalOvenEntryComponent } from './final-oven-entry.component';

describe('FinalOvenEntryComponent', () => {
  let component: FinalOvenEntryComponent;
  let fixture: ComponentFixture<FinalOvenEntryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinalOvenEntryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinalOvenEntryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
