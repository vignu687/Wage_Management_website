import { Component, Input, OnInit, Output, ViewChild, EventEmitter, ViewEncapsulation } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-mpc-grid',
  templateUrl: './mpc-grid.component.html',
  styleUrls: ['./mpc-grid.component.scss'],
  encapsulation:ViewEncapsulation.None
})
export class MpcGridComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;

  @Input() displayedColumns: string[];
  @Input() gridData = [];
  @Input() key = "key";
  @Output() edit = new EventEmitter<any>();
  @Output() delete = new EventEmitter<any>();


  public perPageCount = 5;
  public totalCount: any = 0;
  public currentPage = 1;
  dataSource = new MatTableDataSource<any>(this.gridData);
  sortedData;

  constructor() { }

  ngOnInit(): void {

    /*if (this.displayedColumns.indexOf('action') == -1) {
      this.displayedColumns.push('action');
    }*/

    this.dataSource = new MatTableDataSource<any>(this.gridData);
    this.sortedData = this.gridData.slice();
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }

  sortData(sort: Sort) {


    const data = this.gridData.slice();
    if (!sort.active || sort.direction === '') {
      this.sortedData = data;
      return;
    }

    const isAsc = sort.direction === 'asc';

    this.sortedData = data.sort((a, b) => {
      return this.compare(a.entry_type, b.entry_type, isAsc);
    });
  }

  compare(a: number | string, b: number | string, isAsc: boolean) {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
  }

  onEditGrid(item) {
    
    this.edit.emit(item.id);
  }

  onDeleteGrid(item) {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You will not be able to recover this record!',
      icon: 'warning',
      confirmButtonColor: '#f27474',
      allowOutsideClick: false,
      allowEscapeKey: false,
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if(result.isConfirmed){
        this.delete.emit(item);
      }
    });
  }

}
