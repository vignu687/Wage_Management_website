import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FinalOven } from './../../../../models/final.oven';
import { FinalOvenService } from './../../shared/final.oven.service';
import { GradeWeightTray } from '../../../../models/grade.weight.tray';
import { SharedService } from './../../../shared/services/shared.service';
import { ToastrService } from 'ngx-toastr';
import { HttpParams } from '@angular/common/http';
import { Grade } from './../../../../models/grade';
import {GradeService} from './../../../mpc/shared/grade.service';
import {EntryTypeService} from './../../../mpc/shared/entry.type.service';

@Component({
  selector: 'app-final-oven-entry',
  templateUrl: './final-oven-entry.component.html',
  styleUrls: ['./final-oven-entry.component.scss'],
  encapsulation:ViewEncapsulation.None
})
export class FinalOvenEntryComponent implements OnInit {

  @ViewChild('finalOvenForm') finalOvenForm: NgForm;

  displayedColumns = ['updated_date', 'total_weight','action'];
  finalOvens: FinalOven[] = [];
  finalOvenModel: FinalOven = new FinalOven();
  finalOvenTrays: GradeWeightTray[] = [];
  entryTypes = [];
  grades: Grade[] = [];

  constructor(private finalOvenService: FinalOvenService, private gradeService:GradeService, private toastr: ToastrService,
    private sharedService: SharedService,private entryTypeService:EntryTypeService) { }

  ngOnInit(): void {
    this.addfinalOvenTray();
    this.getAllGrades();
    this.getAllEntryTypes();
  }

  addfinalOvenTray() {
    this.finalOvenTrays.push(this.getfinalOvenModel());
  }

  deletefinalOvenTray(index) {
    this.finalOvenTrays.splice(index,1);
  }

  getfinalOvenModel() {
    return new GradeWeightTray();
  }

  getAllGrades(reset=true){
    this.grades = [];

    this.gradeService.getAllGrades().subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.grades = sResponse.data;
        } else {
          this.toastr.error('Failed to Get Grades, Please Try Again');
        }
      });
  }

  getFinalOvens(reset = true) {

    let params = new HttpParams();
    params = params.append('origin_id', this.finalOvenModel.origin_id);
    params = params.append('lot_id', this.finalOvenModel.lot_id);
    params = params.append('entry_date', this.finalOvenModel.entry_date);
    params = params.append('entry_type', this.finalOvenModel.entry_type);

    this.finalOvens = [];

    this.finalOvenService.getFinalOvens(params).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.finalOvens = sResponse.data;
        } else {
          this.toastr.error('Failed to Get Final Oven Entries, Please Try Again');
        }
      });

  }

  onFinalOvenSubmit() {

    const postModel = JSON.parse(JSON.stringify(this.finalOvenModel));
    postModel.trays = JSON.parse(JSON.stringify(this.finalOvenTrays));

    this.finalOvenService.saveFinalOvens(postModel).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Final Oven Entry Saved Successfully');
          this.resetForm();
        } else  {
          this.toastr.error('Failed to Save Final Oven Entry, Please Try Again');
        }
        this.getFinalOvens();
      }
    );

  }

  onEntryTypeChange() {
    this.getFinalOvens();
  }

  getFinalOvenById(id) {
    this.finalOvenService.getFinalOvenById(id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
        this.finalOvenModel = sResponse.data;
        this.finalOvenTrays = JSON.parse(JSON.stringify(this.finalOvenModel.trays));
        this.finalOvenModel.trays = [];
        } else {
          this.toastr.error('Failed to Get Final Oven Entry, Please Try Again');
        }
      }
    );
  }

  deleteFinalOvenById(finalOven) {
    this.finalOvenService.deleteFinalOvenById(finalOven.id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
        this.toastr.success('Successfully Deleted Final Oven Entry for Date: ' + this.sharedService.getDateOnly(finalOven.updated_date, 'YYYY MMM DD'));
          if (finalOven.id == this.finalOvenModel.id) {
            this.resetForm();
          }
        } else {
          this.toastr.error('Failed to Delete Final Oven Entry, Please Try Again');
        }
        this.getFinalOvens(false);
      }
    );
  }

  resetForm(event = null) {
    this.finalOvenTrays = [];
    this.addfinalOvenTray();
    if (event) {
      this.finalOvenForm.resetForm();
    } else {
      this.finalOvenForm.resetForm(this.finalOvenForm.value);
    }
    delete this.finalOvenModel.id;
  }

  getAllEntryTypes() {
    this.entryTypeService.getAllEntryTypes().subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.entryTypes = sResponse.data;
      } else {
        this.toastr.error('Failed to Get Entry Types, Please Try Again');
      }
    });
  }

}