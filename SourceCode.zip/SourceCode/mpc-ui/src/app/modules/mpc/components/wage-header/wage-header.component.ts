import { DatePipe } from '@angular/common';
import { Output, EventEmitter } from '@angular/core';
import { Component, Input, OnInit } from '@angular/core';
import { MpcService } from './../../shared/mpc.service';
import { SharedService } from './../../../shared/services/shared.service';

@Component({
  selector: 'app-wage-header',
  templateUrl: './wage-header.component.html',
  styleUrls: ['./wage-header.component.scss']
})
export class WageHeaderComponent implements OnInit {

  @Input() model;
  @Output() onChange = new EventEmitter<any>();

  currentDate = new Date()
  origins = [];
  lots = []


  constructor(private mpcService: MpcService, private sharedService: SharedService) { }

  ngOnInit(): void {

    this.origins = this.mpcService.getOriginsLocal();
    this.model.entry_date = this.sharedService.getDateOnly(this.currentDate);
    this.model.origin_id = this.origins[0].id;
    this.getLotByOrigin();
  }


  getLotByOrigin() {

    const origin_id = JSON.parse(JSON.stringify(this.model.origin_id));
    this.mpcService.getLotsByOrigin(origin_id).subscribe(
      sResponse => {
        this.lots = sResponse;
        this.model.lot_id = this.lots[0].id;
      }
    );
  }

  onOriginChange(event) {
    this.getLotByOrigin();
    this.onFieldsChange(event);
  }

  onFieldsChange(event) {
    this.onChange.emit(event);
  }

  onDateChange(event) {
    this.model.entry_date = this.sharedService.getDateOnly(this.model.entry_date);
    this.onFieldsChange(event);
  }
}
