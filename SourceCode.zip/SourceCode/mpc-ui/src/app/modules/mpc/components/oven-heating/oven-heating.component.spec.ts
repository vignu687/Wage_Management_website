import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OvenHeatingComponent } from './oven-heating.component';

describe('OvenHeatingComponent', () => {
  let component: OvenHeatingComponent;
  let fixture: ComponentFixture<OvenHeatingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OvenHeatingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OvenHeatingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
