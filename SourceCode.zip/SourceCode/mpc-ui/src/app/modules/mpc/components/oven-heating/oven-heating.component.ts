import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { NgForm } from '@angular/forms';
import { OvenHeating } from './../../../../models/oven.heating';
import { OvenHeatingService } from './../../shared/oven.heating.service';
import { Tray } from './../../../../models/tray';
import { SharedService } from './../../../shared/services/shared.service';
import { ToastrService } from 'ngx-toastr';
import { HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-oven-heating',
  templateUrl: './oven-heating.component.html',
  styleUrls: ['./oven-heating.component.scss'],
  encapsulation:ViewEncapsulation.None
})
export class OvenHeatingComponent implements OnInit {

  @ViewChild('ovenHeatingForm') ovenHeatingForm: NgForm;

  displayedColumns = ['updated_date', 'total_weight','action'];
  ovenHeatings: OvenHeating[] = [];
  ovenHeatingModel: OvenHeating = new OvenHeating();
  ovenHeatingTrays: Tray[] = [];
  entryTypes = ['In', 'Out'];

  constructor(private ovenHeatingService: OvenHeatingService, private toastr: ToastrService,
    private sharedService: SharedService) { }

  ngOnInit(): void {
    this.addohTray();
  }

  addohTray() {
    this.ovenHeatingTrays.push(this.getohModel());
  }

  deleteohTray(index) {
    this.ovenHeatingTrays.splice(index,1);
  }

  getohModel() {
   return new Tray();
  }

  getOvenHeatings(reset = true) {

    let params = new HttpParams();
    params = params.append('origin_id', this.ovenHeatingModel.origin_id);
    params = params.append('lot_id', this.ovenHeatingModel.lot_id);
    params = params.append('entry_date', this.ovenHeatingModel.entry_date);
    params = params.append('entry_type', this.ovenHeatingModel.entry_type);

    this.ovenHeatings = [];

    this.ovenHeatingService.getOvenHeatings(params).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.ovenHeatings = sResponse.data;
        } else {
          this.toastr.error('Failed to Get Oven Heating Entries, Please Try Again');
        }
      });

  }

  onOvenHeatingSubmit() {

    const postModel = JSON.parse(JSON.stringify(this.ovenHeatingModel));
    postModel.trays = JSON.parse(JSON.stringify(this.ovenHeatingTrays));

    this.ovenHeatingService.saveOvenHeatings(postModel).subscribe(
      sResponse => {

        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Oven Heating Entry Saved Successfully');
          this.resetForm();
        } else  {
          this.toastr.error('Failed to Save Oven Heating Entry, Please Try Again');
        }
        this.getOvenHeatings();
      }
    );
  }

  onEntryTypeChange() {
    this.getOvenHeatings();
  }

  getOvenHeatingById(id) {
    this.ovenHeatingService.getOvenHeatingById(id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
        this.ovenHeatingModel = sResponse.data;
        this.ovenHeatingTrays = JSON.parse(JSON.stringify(this.ovenHeatingModel.trays));
        this.ovenHeatingModel.trays = [];
        } else {
          this.toastr.error('Failed to Get Oven Heating Entry, Please Try Again');
        }
      }
    );
  }

  deleteOvenHeatingById(ovenHeating) {
    this.ovenHeatingService.deleteOvenHeatingById(ovenHeating.id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Successfully Deleted Oven Heating for Date: ' + this.sharedService.getDateOnly(ovenHeating.updated_date, 'YYYY MMM DD'));
          if (ovenHeating.id == this.ovenHeatingModel.id) {
            this.resetForm();
          }
        } else {
          this.toastr.error('Failed to Delete Oven Heating Entry, Please Try Again');
        }
        this.getOvenHeatings(false);
      }
    );
  }

  resetForm(event = null) {
    this.ovenHeatingTrays = [];
    this.addohTray();
    if (event) {
      this.ovenHeatingForm.resetForm();
    } else {
      this.ovenHeatingForm.resetForm(this.ovenHeatingForm.value);
    }
    delete this.ovenHeatingModel.id;
  }

}
