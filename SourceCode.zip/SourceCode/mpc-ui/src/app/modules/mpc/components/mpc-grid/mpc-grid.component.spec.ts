import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MpcGridComponent } from './mpc-grid.component';

describe('MpcGridComponent', () => {
  let component: MpcGridComponent;
  let fixture: ComponentFixture<MpcGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MpcGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MpcGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
