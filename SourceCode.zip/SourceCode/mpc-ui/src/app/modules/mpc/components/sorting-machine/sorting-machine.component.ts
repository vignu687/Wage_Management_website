import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { NgForm } from '@angular/forms';
import { SortingMachine } from '../../../../models/sorting.machine';
import { SortingMachineService } from '../../shared/sorting.machine.service';
import { SharedService } from '../../../shared/services/shared.service';
import { ToastrService } from 'ngx-toastr';
import { HttpParams } from '@angular/common/http';
import { Tray } from 'src/app/models/tray';
import { WeightTypeWeightTray } from 'src/app/models/weight.type.weight.tray';
import { MachineService } from './../../../mpc/shared/machine.service';
import { Machine } from './../../../../models/machine';
import { WeightTypeService } from '../../shared/weight.type.service';

@Component({
  selector: 'app-sorting-machine',
  templateUrl: './sorting-machine.component.html',
  styleUrls: ['./sorting-machine.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class SortingMachineComponent implements OnInit {

  @ViewChild('sortingMachineForm') sortingMachineForm: NgForm;

  inDisplayedColumns = ['updated_date', 'weight_type', 'total_in_weight','action'];
  outDisplayedColumns = ['updated_date','total_out_weight', 'action'];
  sortingMachines: SortingMachine[] = [];
  sortingMachineModel: SortingMachine = new SortingMachine();
  entryTypes = ['In', 'Out'];
  inWeightTypes = [];
  machines: Machine[] = [];
  outWeightTypes = [];

  inSortingMachineTrays: Tray[] = [];

  outSortingMachineTrays: WeightTypeWeightTray[] =[]

  constructor(private sortingMachineService: SortingMachineService,private machineService: MachineService,private weightTypeService:WeightTypeService, private toastr: ToastrService,
    private sharedService: SharedService) { }

  ngOnInit(): void {
    this.addInSortingTray();
    this.addOutSortingTray();
  }

  addInSortingTray() {
    this.inSortingMachineTrays.push(this.getInSortingModel());
  }

  deletInSortingTray(index) {
    this.inSortingMachineTrays.splice(index, 1);
  }

  getInSortingModel() {
    return new Tray();
  }

  addOutSortingTray() {
    this.outSortingMachineTrays.push(this.getOutSortingModel());
  }

  deletOutSortingTray(index) {
    this.outSortingMachineTrays.splice(index, 1);
  }

  getOutSortingModel() {
    return new WeightTypeWeightTray();
  }

  onEntryTypeChange() {
    this.getAllMachines();
    this.getAllOutWeightTypes();
    this.getAllInWeightTypes();
    this.sortingMachineModel.machine_name=null;
    this.sortingMachines = [];
  }

  onMachineNameChange(){
    this.getSortingMachines();
  }

  getSortingMachines(reset = true) {

    let params = new HttpParams();
    params = params.append('origin_id', this.sortingMachineModel.origin_id);
    params = params.append('lot_id', this.sortingMachineModel.lot_id);
    params = params.append('entry_date', this.sortingMachineModel.entry_date);
    params = params.append('entry_type', this.sortingMachineModel.entry_type);
    params = params.append('machine_name', this.sortingMachineModel.machine_name);

    this.sortingMachines = [];

    this.sortingMachineService.getSortingMachines(params).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.sortingMachines = sResponse.data;
        } else {
          this.toastr.error('Failed to Get Sorting Entries, Please Try Again');
        }
      }
    );

  }

  onSortingMachineSubmit() {
    const postModel = JSON.parse(JSON.stringify(this.sortingMachineModel));
    postModel.trays = JSON.parse(JSON.stringify(this.inSortingMachineTrays));
    postModel.weight_trays = JSON.parse(JSON.stringify(this.outSortingMachineTrays));

    this.sortingMachineService.saveSortingMachines(postModel).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Sorting Machine Entry Saved Successfully');
          this.resetForm();
        }
        else {
          this.toastr.error('Failed to Save Sorting Machine Entry, Please Try Again');
        }
        this.getSortingMachines();
      });
  }

  getSortingMachineById(id) {
    this.sortingMachineService.getSortingMachineById(id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.sortingMachineModel = sResponse.data;
          this.inSortingMachineTrays = JSON.parse(JSON.stringify(this.sortingMachineModel.trays));
          this.outSortingMachineTrays = JSON.parse(JSON.stringify(this.sortingMachineModel.weight_trays));
          this.sortingMachineModel.trays = [];
          this.sortingMachineModel.weight_trays = [];
        } else {
          this.toastr.error('Failed to Get Sorting Machine Entry, Please Try Again');
        }
      });
  }

  deleteSortingMachineById(sortingMachine) {
    this.sortingMachineService.deleteSortingMachineById(sortingMachine.id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Successfully Deleted Sorting Machine Entry for Date: ' + this.sharedService.getDateOnly(sortingMachine.updated_date, 'YYYY MMM DD'));
          if (sortingMachine.id == this.sortingMachineModel.id) {
            this.resetForm();
          } 
        } else {
          this.toastr.error('Failed to Delete Sorting Machine Entry, Please Try Again');
        }
        this.getSortingMachines(false);
      }
    );
  }

  resetForm(event = null) {
    this.inSortingMachineTrays = [];
    this.outSortingMachineTrays = [];
    this.addInSortingTray();
    this.addOutSortingTray();

    if (event) {
      this.sortingMachineForm.resetForm();
    } else {
      this.sortingMachineForm.resetForm(this.sortingMachineForm.value);
    }
    delete this.sortingMachineModel.id;
    delete this.sortingMachineModel.weight_type;
  }

  getAllMachines() {
    this.machineService.getAllMachinesByType('sorting').subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.machines = sResponse.data;
      } else {
        this.toastr.error('Failed to Get Sorting Machine Entries, Please Try Again');
      }
    });
  }

  getAllOutWeightTypes() {
    let params = new HttpParams();
    params = params.append('department', 'sorting_machine');
    params = params.append('entry_type', 'Out');

    this.weightTypeService.getAllWeightTypes(params).subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.outWeightTypes = sResponse.data;
      } else {
        this.toastr.error('Failed to Get Out Weight Types, Please Try Again');
      }
    });
  }

  getAllInWeightTypes(){
    let params = new HttpParams();
    params = params.append('department', 'sorting_machine');
    params = params.append('entry_type', 'In');

    this.weightTypeService.getAllWeightTypes(params).subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.inWeightTypes = sResponse.data;
      } else {
        this.toastr.error('Failed to Get In Weight Types, Please Try Again');
      }
    });
  }

}