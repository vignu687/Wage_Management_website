import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MachineCutting } from './../../../../models/machine.cutting';
import { MachineCuttingService } from './../../shared/machine.cutting.service';
import { Tray } from './../../../../models/tray';
import { SharedService } from './../../../shared/services/shared.service';
import { ToastrService } from 'ngx-toastr';
import { HttpParams } from '@angular/common/http';
import { MachineService } from './../../../mpc/shared/machine.service';
import { Machine } from './../../../../models/machine';

@Component({
  selector: 'app-machine-cutting',
  templateUrl: './machine-cutting.component.html',
  styleUrls: ['./machine-cutting.component.scss'],
  encapsulation:ViewEncapsulation.None
})
export class MachineCuttingComponent implements OnInit {

  @ViewChild('machineCuttingForm') machineCuttingForm: NgForm;

  displayedColumns = ['updated_date', 'total_weight','action'];
  machineCuttings: MachineCutting[] = [];
  machineCuttingModel: MachineCutting = new MachineCutting();
  machineCuttingTrays: Tray[] = [];
  machines: Machine[] = [];
  entryTypes = ['In', 'Out'];

  constructor(private machineCuttingService: MachineCuttingService,private machineService: MachineService, private toastr: ToastrService,
    private sharedService: SharedService) { }

  ngOnInit(): void {
    this.addmcTray();
  }

  addmcTray() {
    this.machineCuttingTrays.push(this.getmcModel());
  }

  deletemcTray(index) {
    this.machineCuttingTrays.splice(index,1);
  }

  getmcModel() {
    return new Tray();
  }

  getMachineCuttings(reset = true) {

    let params = new HttpParams();
    params = params.append('origin_id', this.machineCuttingModel.origin_id);
    params = params.append('lot_id', this.machineCuttingModel.lot_id);
    params = params.append('entry_date', this.machineCuttingModel.entry_date);
    params = params.append('entry_type', this.machineCuttingModel.entry_type);
    params = params.append('machine_name', this.machineCuttingModel.machine_name);

    this.machineCuttings = [];

    this.machineCuttingService.getMachineCuttings(params).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.machineCuttings = sResponse.data;
        } else {
          this.toastr.error('Failed to Get Machine Cutting Entries, Please Try Again');
        }
      });

  }

  onMachineCuttingSubmit() {

    const postModel = JSON.parse(JSON.stringify(this.machineCuttingModel));
    postModel.trays = JSON.parse(JSON.stringify(this.machineCuttingTrays));

    this.machineCuttingService.saveMachineCuttings(postModel).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Machine Cutting Entry Saved Successfully');
          this.resetForm();
        } else  {
          this.toastr.error('Failed to Save Machine Cutting Entry, Please Try Again');
        }
        this.getMachineCuttings();
      }
    );
  }

  onEntryTypeChange() {
    this.getAllMachines();
    this.machineCuttingModel.machine_name=null;
    this.machineCuttings = [];
  }

  onMachineNameChange(){
    this.getMachineCuttings();
  }

  getMachineCuttingById(id) {
    this.machineCuttingService.getMachineCuttingById(id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
        this.machineCuttingModel = sResponse.data;
        this.machineCuttingTrays = JSON.parse(JSON.stringify(this.machineCuttingModel.trays));
        this.machineCuttingModel.trays = [];
        } else {
          this.toastr.error('Failed to Get Machine Cutting Entry, Please Try Again');
        }
      }
    );
  }

  deleteMachineCuttingById(machineCutting) {
    this.machineCuttingService.deleteMachineCuttingById(machineCutting.id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
        this.toastr.success('Successfully Deleted Machine Cutting Entry for Date: ' + this.sharedService.getDateOnly(machineCutting.updated_date, 'YYYY MMM DD'));
          if (machineCutting.id == this.machineCuttingModel.id) {
            this.resetForm();
          }
        } else {
          this.toastr.error('Failed to Delete Machine Cutting Entry, Please Try Again');
        }
        this.getMachineCuttings(false);
      }
    );
  }

  resetForm(event = null) {
    this.machineCuttingTrays = [];
    this.addmcTray();
    if (event) {
      this.machineCuttingForm.resetForm();
    } else {
      this.machineCuttingForm.resetForm(this.machineCuttingForm.value);
    }
    delete this.machineCuttingModel.id;
  }

  getAllMachines() {
  this.machineService.getAllMachinesByType('cutting').subscribe(sResponse => {
    if (sResponse.status && !sResponse.message) {
      this.machines = sResponse.data;
    } else {
      this.toastr.error('Failed to Get Cutting Machines, Please Try Again');
    }
  });
}

}
