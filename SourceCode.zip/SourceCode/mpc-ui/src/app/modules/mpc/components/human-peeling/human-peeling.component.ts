import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormControl, NgForm } from '@angular/forms';
import { Observable, Subject } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { HumanPeelingService } from '../../shared/human.peeling.service';
import { ToastrService } from 'ngx-toastr';
import { EmployeeService } from './../../../management/shared/employee.service';
import { HttpParams } from '@angular/common/http';
import { HumanPeeling } from './../../../../models/human.peeling';
import { SharedService } from './../../../shared/services/shared.service';

@Component({
  selector: 'app-human-peeling',
  templateUrl: './human-peeling.component.html',
  styleUrls: ['./human-peeling.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class HumanPeelingComponent implements OnInit {

  @ViewChild('peelingForm') peelingForm: NgForm;

  displayedColumns = ['updated_date','job_description','total_weight', 'action'];

  employeeControl = new FormControl();
  employeeFilterControl = new FormControl();
  filteredOptions: Observable<string[]>;
  protected _onDestroy = new Subject<void>();
  peelingModel: HumanPeeling = new HumanPeeling();
  peelings = [];
  jobDescriptions = [];
  questions = [];
  employees = [];

  attendanceValue = "";

  constructor(private humanPeelingService: HumanPeelingService,
    private toastr: ToastrService,
    private employeeService: EmployeeService,
    private sharedService: SharedService) { }

  ngOnInit() {
    this.filteredOptions = this.employeeFilterControl.valueChanges
      .pipe(
        startWith(''),
        map(employee => employee && typeof employee === 'object' ? this.displayFn(employee) : employee),
        map((name: string) => name ? this._filter(name) : this.employees.slice())
      );

    this.getEmployees();
  }

  private _filter(value: string): string[] {

    if (value != null) {
      const filterValue = value.toLowerCase();
      if(this.employees.filter(employee => (employee.first_name +employee.middle_name+employee.last_name).toLowerCase().includes(filterValue)).length>0){
        return this.employees.filter(employee => (employee.first_name +employee.middle_name+employee.last_name).toLowerCase().includes(filterValue));
      } else {
        return this.employees.filter(employee => employee.username.includes(filterValue));
      }
    }

  }

  displayFn = (employee) => {
    return employee ? this.getEmployeeFullName(employee) : '';
  }

  toTitleCase(str) {
    return str.replace(/\s\s+/g, ' ').trim().split(' ')
      .map(w => w[0].toUpperCase() + w.substr(1).toLowerCase())
      .join(' ')

  }

  getEmployeeFullName(employee) {
    let fullName = employee.first_name;
    if (employee.middle_name) {
      fullName += " " + employee.middle_name;
    }
    return this.toTitleCase(fullName += " " + employee.last_name);
  }

  getEmployees() {
    this.employeeService.getWageEmployeesAll().subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.employees = sResponse.data;
        this.getJobDescriptions();
      } else {
        this.toastr.error('Failed to Get Employee Records, Please Try Again');
      }
    });
  }

  getPeelingsAll(employee_id) {
    this.peelingModel.employee_id = employee_id;
    let params = new HttpParams();
    params = params.append('origin_id', this.peelingModel.origin_id);
    params = params.append('lot_id', this.peelingModel.lot_id);
    params = params.append('entry_date', this.peelingModel.entry_date);
    params = params.append('employee_id', this.peelingModel.employee_id);
    this.peelings = [];
    this.humanPeelingService.getHumanPeelings(params).subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.peelings = sResponse.data;
        this.peelings.map(o => o.job_description = this.toTitleCase(o.job_description.replaceAll("_", " ")));
      } else {
        this.toastr.error('Failed to Get Human Peeling Entries, Please Try Again');
      }
    })
  }

  onJobDescriptionChange(event) {
    this.humanPeelingService.getQuestionsByDescription(event.value).subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.questions = sResponse.data;
      } else {
        this.toastr.error('Failed to Get Human Peeling Fields, Please Try Again');
      }
    })

  }

  private getJobDescriptions() {
    this.humanPeelingService.getHumanPeelingDescriptions().subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.jobDescriptions = sResponse.data;
      } else {
        this.toastr.error('Failed to Get Human Peeling Job Descriptions, Please Try Again');
      }
    })
  }

  onPeelingFormSubmit(form) {
    const postPeelingModel = JSON.parse(JSON.stringify(this.peelingModel));
    postPeelingModel.value = JSON.parse(JSON.stringify(this.questions));

    this.humanPeelingService.saveHumanPeeling(postPeelingModel).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Human Peeling Entry Saved Successfully');
          this.resetForm();
        } else {
          this.toastr.error('Failed to Save Human Peeling Entry, Please Try Again');
        }
        this.getPeelingsAll(this.peelingModel.employee_id);
      }
    )
  }

  resetForm(event = null) {
    this.questions = [];
    if (event) {
      this.employeeControl.setValue(null);
      this.peelingForm.resetForm();
      this.peelings = [];
    } else {
      this.peelingForm.resetForm(this.peelingForm.value);
    }
    delete this.peelingModel.id;
    delete this.peelingModel.job_description;

  }

  getPeelingById(id) {
    this.humanPeelingService.getHumanPeelingById(id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
        this.peelingModel = sResponse.data;
        this.questions = JSON.parse(JSON.stringify(this.peelingModel.value));
        delete this.peelingModel.value;
        } else {
          this.toastr.error('Failed to Get Human Peeling Entry, Please Try Again');
        }
      }
    );
  }

  deletePeelingById(peeling) {
    this.humanPeelingService.deleteHumanPeelingById(peeling.id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Successfully Deleted Human Peeling Entry for Date: ' + this.sharedService.getDateOnly(peeling.updated_date, 'YYYY MMM DD'));
          if (peeling.id == this.peelingModel.id) {
            this.resetForm();
          }
        } else {
          this.toastr.error('Failed to Delete Human Peeling Entry, Please Try Again');
        }
        this.getPeelingsAll(this.peelingModel.employee_id);
      }
    );
  }

  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

}
