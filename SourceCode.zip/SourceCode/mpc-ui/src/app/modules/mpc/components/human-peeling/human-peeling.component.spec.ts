import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HumanPeelingComponent } from './human-peeling.component';

describe('HumanPeelingComponent', () => {
  let component: HumanPeelingComponent;
  let fixture: ComponentFixture<HumanPeelingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HumanPeelingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HumanPeelingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
