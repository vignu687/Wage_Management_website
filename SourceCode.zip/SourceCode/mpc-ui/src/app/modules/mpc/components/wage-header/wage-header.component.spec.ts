import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WageHeaderComponent } from './wage-header.component';

describe('WageHeaderComponent', () => {
  let component: WageHeaderComponent;
  let fixture: ComponentFixture<WageHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WageHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WageHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
