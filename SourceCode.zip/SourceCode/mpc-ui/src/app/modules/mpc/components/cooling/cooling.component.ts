import { HttpParams } from '@angular/common/http';
import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { Cooling } from './../../../../models/cooling';
import { CoolingService } from './../../shared/cooling.service';
import { Tray } from './../../../../models/tray';
import { SharedService } from './../../../shared/services/shared.service';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-cooling',
  templateUrl: './cooling.component.html',
  styleUrls: ['./cooling.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CoolingComponent implements OnInit {

  @ViewChild('coolingForm') coolingForm: NgForm;

  displayedColumns = ['updated_date', 'total_weight','action'];
  cooling: Cooling[] = [];
  coolingModel: Cooling = new Cooling();
  coolingTrays: Tray[] = [];
  entryTypes = ['In', 'Out'];

  constructor(private coolingService: CoolingService, private toastr: ToastrService,
    private sharedService: SharedService) { }

  ngOnInit(): void {
    this.addCoolingTray();
  }

  addCoolingTray() {
    this.coolingTrays.push(this.getCoolingTrayModel());
  }

  deleteCoolingTray(index) {
    this.coolingTrays.splice(index, 1);
  }

  getCoolingTrayModel() {
    return new Tray();
  }


  getCoolings(reset = true) {

    let params = new HttpParams();
    params = params.append('origin_id', this.coolingModel.origin_id);
    params = params.append('lot_id', this.coolingModel.lot_id);
    params = params.append('entry_date', this.coolingModel.entry_date);
    params = params.append('entry_type', this.coolingModel.entry_type);

    this.cooling = [];

    this.coolingService.getCoolings(params).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.cooling = sResponse.data;
        } else {
          this.toastr.error('Failed to Get Cooling Entries, Please Try Again');
        }
      });
  }

  onCoolingSubmit() {

    const postCoolingModel = JSON.parse(JSON.stringify(this.coolingModel));
    postCoolingModel.trays = JSON.parse(JSON.stringify(this.coolingTrays));

    this.coolingService.saveCoolings(postCoolingModel).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Cooling Entry Saved Successfully');
          this.resetForm();
        } else  {
          this.toastr.error('Failed to Save Cooling Entry, Please Try Again');
        }
        this.getCoolings();
      }
    );
  }

  onEntryTypeChange() {
    this.getCoolings();
  }

  getCoolingById(id) {
    
    this.coolingService.getCoolingsById(id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
        this.coolingModel = sResponse.data;
        this.coolingTrays = JSON.parse(JSON.stringify(this.coolingModel.trays));
        this.coolingModel.trays = [];
        } else {
          this.toastr.error('Failed to Get Cooling Entry, Please Try Again');
        }
      }
    );
  }

  deleteCoolingById(cooling) {
    this.coolingService.deleteCoolingsById(cooling.id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
        this.toastr.success('Successfully Deleted Cooling Entry for Date: ' + this.sharedService.getDateOnly(cooling.updated_date, 'YYYY MMM DD'));
          if (cooling.id == this.coolingModel.id) {
            this.resetForm();
          }
        } else {
          this.toastr.error('Failed to Delete Cooling Entry, Please Try Again');
        }
        this.getCoolings(false);
      }
    );
  }

  resetForm(event = null) {
    this.coolingTrays = [];
    this.addCoolingTray();
    if (event) {
      this.coolingForm.resetForm();
    } else {
      this.coolingForm.resetForm(this.coolingForm.value);
    }
    delete this.coolingModel.id;
  }

}