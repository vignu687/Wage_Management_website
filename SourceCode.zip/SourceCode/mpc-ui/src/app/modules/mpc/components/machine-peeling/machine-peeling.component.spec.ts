import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MachinePeelingComponent } from './machine-peeling.component';

describe('MachinePeelingComponent', () => {
  let component: MachinePeelingComponent;
  let fixture: ComponentFixture<MachinePeelingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MachinePeelingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MachinePeelingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
