import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormControl, NgForm } from '@angular/forms';
import { Subject, ReplaySubject } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';
import { EmployeeService } from './../../../management/shared/employee.service';
import { PayrollService} from './../../shared/payroll.service';
import { MasterSettingsService } from './../../../management/shared/master-settings.service';
import { HttpParams } from '@angular/common/http';
import { PayrollEntry } from './../../../../models/payroll.entry';
import { MatSelect } from '@angular/material/select';
import { Employee } from './../../../../models/employee';
import { SharedService } from './../../../shared/services/shared.service';

@Component({
  selector: 'app-payroll-entry',
  templateUrl: './payroll-entry.component.html',
  styleUrls: ['./payroll-entry.component.scss']
})
export class PayrollEntryComponent implements OnInit {

  @ViewChild('payrollEntryForm') payrollEntryForm: NgForm;

  payrollEntryModel: PayrollEntry = new PayrollEntry();
  protected _onDestroy = new Subject<void>();
  currentDate = new Date();
  employeesList = [];
  payrollSettings  = {};
  selectedEmployeeList = [];
  isAmountVisible=false;
  isAmountDisabled=true;
  isEmployees=true;
  payrollEntries= [];
  displayedColumns = ['updated_date','entry_date', 'entry_type','entry_category','amount','action'];

  entryTypes = [
    { label: 'Attendance', value: 'AT' },
    { label: 'Allowances', value: 'A' },
    { label: 'Deductions', value: 'D' }
  ];

 allowances = [
    { label: 'Dearness Allowance', value: 'DA' },
    { label: 'Adjustment', value: 'AJ' }
  ];

  attendanceTypes = [
    {label: 'Full Day', value: 'FD' },
    {label: 'Half Day', value: 'HD' },
    {label: 'Absent', value: 'AB' }
  ]

  deductions = [
    { label: 'Canteen Charges', value: 'CC' },
    { label: 'Bus Charges', value: 'BC' }
  ];

  // List of Employees */
  protected employees: Employee[] = [];

  // Control for the selected Employee */
  public employeeCtrl: FormControl = new FormControl();

  // control for the MatSelect filter keyword */
  public employeeFilterCtrl: FormControl = new FormControl();

  // list of Employees filtered by search keyword */
  public filteredEmployees: ReplaySubject<Employee[]> = new ReplaySubject<Employee[]>(1);


  @ViewChild('multiSelect', { static: true })
  multiSelect!: MatSelect;

  // flags to set the toggle all checkbox state */
  isIndeterminate = false;
  isChecked = false;

  constructor(private toastr: ToastrService, private employeeService: EmployeeService,
    private settingService: MasterSettingsService, private payrollService: PayrollService,private sharedService: SharedService) {
    this.getEmployees();
    this.getPayrollSettings();
  }

  ngOnInit(): void {

    // Select all Employees by Default
    //this.employeeCtrl.setValue(this.employees);

    this.payrollEntryModel.entry_date = this.sharedService.getDateOnly(this.currentDate);

    // load the initial employee list
    this.filteredEmployees.next(this.employees.slice());

    // listen for search field value changes
    this.employeeFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterCars();
      });

  }

  // Filter Employees
  protected filterCars() {
    if (!this.employees) {
      return;
    }
    // get the search keyword
    let search = this.employeeFilterCtrl.value;
    if (!search) {
      this.filteredEmployees.next(this.employees.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the employees based on Name & Employee ID
    this.filteredEmployees.next(
      this.employees.filter((employee) => (employee.first_name + employee.middle_name + employee.last_name).toLowerCase().includes(search) || employee.username.includes(search))
    );
  }

  // Toggle Select All
  toggleSelectAll(selectAllValue: boolean) {
    this.filteredEmployees
      .pipe(take(1), takeUntil(this._onDestroy))
      .subscribe((val) => {
        if (selectAllValue) {
          this.employeeCtrl.patchValue(val);
        } else {
          this.employeeCtrl.patchValue([]);
        }
      });
  }

  protected setValues() {
    this.filteredEmployees
      //.pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(() => {
          this.multiSelect.compareWith = (a: Employee, b: Employee) => a && b && a.id === b.id;
      });
  }

  getEmployees() {
    this.employeeService.getWageEmployeesAll().subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.employeesList = sResponse.data;
        this.employeesList.forEach((employeeJson) => this.employees.push(Object.assign(new Employee(), employeeJson)));
      } else {
        this.toastr.error('Failed to Get Employee Records, Please Try Again');
      }
    });
  }

  getPayrollSettings(){
    this.settingService.getPayrollSettings().subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.payrollSettings= sResponse.data[0].payroll;
      } else {
        this.toastr.error('Failed to Get Payroll Settings from Master Settings, Please Try Again');
      }
    });
  }

  onPayrollEntrySubmit() {

    if (this.payrollEntryModel.entry_category=="AJ"){
      this.payrollEntryModel.employee_id=this.employeeCtrl.value.id;
      const postLotModel = JSON.parse(JSON.stringify(this.payrollEntryModel));
    } else {
      this.payrollEntryModel.employees=this.employeeCtrl.value;
      const postLotModel = JSON.parse(JSON.stringify(this.payrollEntryModel));
      this.payrollService.savePayrollEntry(postLotModel).subscribe(
        sResponse => {
          if (sResponse.status && !sResponse.message) {
            this.toastr.success('Payroll Record Saved Successfully');
            this.resetForm();
          } else if (String(sResponse.trace).includes('duplicate key error')) {
            this.toastr.error('Payroll Payroll Record Already Saved for Selected Date and Type!');
          } else {
            this.toastr.error('Failed to Create Payroll Record, Please Try Again');
          }
        });
    }

  }

  getPayrollEntriesAll() {

    let params = new HttpParams();
    params = params.append('entry_date', this.payrollEntryModel.entry_date);
    params = params.append('entry_category', this.payrollEntryModel.entry_category);
    params = params.append('entry_type', this.payrollEntryModel.entry_type);

    this.payrollEntries = [];

    this.payrollService.getPayrollEntriesAll(params).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.payrollEntries = sResponse.data;
          this.employeeCtrl.setValue( this.payrollEntries);
          console.log(this.payrollEntries);
        } else {
          this.toastr.error('Failed to Get Payroll Entries, Please Try Again');
        }
      });
  }

  getPayrollEntryById(id) {
    this.payrollService.getPayrollEntryById(id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
        this.payrollEntryModel = sResponse.data;
        this.employeeCtrl.patchValue(this.payrollEntryModel.employees);
        this.setValues();
        } else {
          this.toastr.error('Failed to Payroll Entry, Please Try Again');
        }
      }
    );
  }

  deletePayrollEntryById(payrollEntry) {
    this.payrollService.deletePayrollEntryById(payrollEntry.id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Successfully Deleted Payroll Entry for Date: ' + this.sharedService.getDateOnly(payrollEntry.updated_date, 'YYYY MMM DD'));
          if (payrollEntry.id == this.payrollEntryModel.id) {
            this.resetForm();
          }
        } else {
          this.toastr.error('Failed to Delete Payroll Entry Entry, Please Try Again');
        }
        this.getPayrollEntriesAll();
      }
    );
  }


  onEntryTypeChange(){
    this.isAmountVisible=false;
  }

  onCategoryChange(){

    switch(this.payrollEntryModel.entry_category){
      case "BC" : {
        this.payrollEntryModel.amount=this.payrollSettings['bus_charge'];
        this.isAmountDisabled=true;
        this.isAmountVisible=true;
        this.isEmployees=true;
        break;
      }

      case "CC" : {
        this.payrollEntryModel.amount=this.payrollSettings['canteen_charge'];
        this.isAmountDisabled=true;
        this.isAmountVisible=true;
        this.isEmployees=true;
        break;
      }

      case "DA" : {
        this.payrollEntryModel.amount=this.payrollSettings['dearness_allowance'];
        this.isAmountDisabled=true;
        this.isAmountVisible=true;
        this.isEmployees=true;
        break;
      }

      case "AJ" : {
        delete  this.payrollEntryModel.amount
        this.isAmountDisabled=false;
        this.isAmountVisible=true;
        this.isEmployees=false;
        break;
      }

      case "FD" : {
        this.payrollEntryModel.amount=1;
        this.isAmountDisabled=true;
        this.isAmountVisible=true;
        this.isEmployees=true;
        break;
      }

      case "HD" : {
        this.payrollEntryModel.amount=0.5;
        this.isAmountDisabled=true;
        this.isAmountVisible=true;
        this.isEmployees=true;
        break;
      }

      case "AB" : {
        this.payrollEntryModel.amount=0;
        this.isAmountDisabled=true;
        this.isAmountVisible=true;
        this.isEmployees=true;
        break;
      }

      default : {
        this.isAmountVisible=false;
        break;
      }
    }
    
    this.getPayrollEntriesAll();

  }

  onDateChange(event) {
    this.payrollEntryModel.entry_date = this.sharedService.getDateOnly(this.payrollEntryModel.entry_date);
    if(this.payrollEntryModel.entry_category){
      this.getPayrollEntriesAll();
    }
  }

  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  resetForm(event = null) {
    if (event) {
      this.payrollEntryForm.resetForm();
    } else {
      this.payrollEntryForm.resetForm(this.payrollEntryForm.value);
    }
    delete this.payrollEntryModel.id;
    delete this.payrollEntryModel.entry_category;
    delete this.payrollEntryModel.entry_type;
    this.isAmountVisible=false;
    this.isEmployees=true;
    this.payrollEntryModel.entry_date = this.sharedService.getDateOnly(this.payrollEntryModel.entry_date);
    this.employeeCtrl.patchValue([]);
  }

}