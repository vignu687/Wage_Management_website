import { HttpParams } from '@angular/common/http';
import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MachineGrading } from './../../../../models/machine.grading';
import { MachineGradingService } from './../../shared/machine.grading.service';
import { GradeWeightTray } from '../../../../models/grade.weight.tray';
import { SharedService } from './../../../shared/services/shared.service';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Grade } from './../../../../models/grade';
import {GradeService} from './../../../mpc/shared/grade.service';
import { MachineService } from './../../../mpc/shared/machine.service';
import { Machine } from './../../../../models/machine';

@Component({
  selector: 'app-machine-grading',
  templateUrl: './machine-grading.component.html',
  styleUrls: ['./machine-grading.component.scss'],
  encapsulation:ViewEncapsulation.None
})
export class MachineGradingComponent implements OnInit {

  @ViewChild('machineGradingForm') machineGradingForm: NgForm;

  displayedColumns = ['updated_date', 'total_weight','action'];
  machineGradings: MachineGrading[] = [];
  machineGradingModel: MachineGrading = new MachineGrading();
  machineGradingTrays: GradeWeightTray[] = [];
  grades: Grade[] = [];
  machines: Machine[] = [];
  

  constructor(private machineGradingService: MachineGradingService, private gradeService:GradeService,private machineService: MachineService, private toastr: ToastrService,
    private sharedService: SharedService) { }

  ngOnInit(): void {
    this.addMachineGradingTray();
  }

  ngAfterViewInit() : void {
    this.getAllGrades();
    this.getAllMachines();
  }

  addMachineGradingTray() {
    this.machineGradingTrays.push(this.getMachineGradingModel());
  }

  deleteMachineGradingTray(index) {
    this.machineGradingTrays.splice(index,1);
  }

  getMachineGradingModel() {
    return new GradeWeightTray();
  }

  getAllGrades(reset=true){
    this.grades = [];

    this.gradeService.getAllGrades().subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.grades = sResponse.data;
        } else {
          this.toastr.error('Failed to Get Grades, Please Try Again');
        }
      });
  }

  getMachineGradings(reset = true) {

    let params = new HttpParams();
    params = params.append('origin_id', this.machineGradingModel.origin_id);
    params = params.append('lot_id', this.machineGradingModel.lot_id);
    params = params.append('entry_date', this.machineGradingModel.entry_date);
    params = params.append('machine_name', this.machineGradingModel.machine_name);

    this.machineGradings = [];

    this.machineGradingService.getMachineGradings(params).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.machineGradings = sResponse.data;
        } else {
          this.toastr.error('Failed to Get Machine Grading Entries, Please Try Again');
        }
      });

  }

  onMachineGradingSubmit() {
    const postModel = JSON.parse(JSON.stringify(this.machineGradingModel));
    postModel.trays = JSON.parse(JSON.stringify(this.machineGradingTrays));

    this.machineGradingService.saveMachineGradings(postModel).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Machine Grading Entry Saved Successfully');
          this.resetForm();
        } else  {
          this.toastr.error('Failed to Save Machine Grading Entry, Please Try Again');
        }
        this.getMachineGradings();
      }
    );
  }

  getMachineGradingById(id) {
    
    this.machineGradingService.getMachineGradingById(id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
        this.machineGradingModel = sResponse.data;
        this.machineGradingTrays = JSON.parse(JSON.stringify(this.machineGradingModel.trays));
        this.machineGradingModel.trays = [];
        } else {
          this.toastr.error('Failed to Get Machine Grading Entry, Please Try Again');
        }
      }
    );
  }

  deleteMachineGradingById(machineGrading) {
    this.machineGradingService.deleteMachineGradingById(machineGrading.id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Successfully Deleted Machine Grading Entry for Date: ' + this.sharedService.getDateOnly(machineGrading.updated_date, 'YYYY MMM DD'));
          if (machineGrading.id == this.machineGradingModel.id) {
            this.resetForm();
          }
        } else {
          this.toastr.error('Failed to Delete Machine Grading Entry, Please Try Again');
        }
        this.getMachineGradings(false);
      }
    );
  }

  resetForm(event = null) {
    this.machineGradingTrays = [];
    this.addMachineGradingTray();
    if (event) {
      this.machineGradingForm.resetForm();
    } else {
      this.machineGradingForm.resetForm(this.machineGradingForm.value);
    }
    delete this.machineGradingModel.id;
  }

  onMachineNameChange(){
    this.getMachineGradings();
  }

  getAllMachines() {
    this.machineService.getAllMachinesByType('grading').subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.machines = sResponse.data;
      } else {
        this.toastr.error('Failed to Get Grading Machines, Please Try Again');
      }
    });
  }

}
