import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MachineCuttingComponent } from './machine-cutting.component';

describe('MachineCuttingComponent', () => {
  let component: MachineCuttingComponent;
  let fixture: ComponentFixture<MachineCuttingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MachineCuttingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MachineCuttingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
