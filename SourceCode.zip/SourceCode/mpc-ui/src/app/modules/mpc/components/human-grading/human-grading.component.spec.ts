import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HumanGradingComponent } from './human-grading.component';

describe('HumanGradingComponent', () => {
  let component: HumanGradingComponent;
  let fixture: ComponentFixture<HumanGradingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HumanGradingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HumanGradingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
