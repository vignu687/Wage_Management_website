import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewWageComponent } from './view-wage.component';

describe('ViewWageComponent', () => {
  let component: ViewWageComponent;
  let fixture: ComponentFixture<ViewWageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewWageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewWageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
