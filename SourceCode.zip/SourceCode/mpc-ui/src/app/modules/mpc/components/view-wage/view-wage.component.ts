import { Component, OnInit } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { ViewWageService } from './../../shared/view-wage.service';
import { HttpParams } from '@angular/common/http';
import { SharedService } from './../../../shared/services/shared.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-view-wage',
  templateUrl: './view-wage.component.html',
  styleUrls: ['./view-wage.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})

export class ViewWageComponent implements OnInit {

  columnsToDisplay = ['employee', 'wage'];
  //displayedColumns: string[] = ['work', 'wage'];

  displayedColumns: string[] = ['position','employeeId' ,'name', 'wage'];
  dataSource = [];

  currentDate = new Date();
  entry_date_start = new Date();
  entry_date_end = new Date();


  constructor(
    private viewWageService: ViewWageService,
    private sharedService: SharedService,
    private router: Router,
    private toastr: ToastrService
    ) {
    this.entry_date_start.setDate(this.currentDate.getDate() - 7);

  }

  ngOnInit(): void {
    this.onFilterClick(null);
  }

  onFilterClick(filterForm) {

    let params = new HttpParams();
    params = params.append('entry_date_start', this.sharedService.getDateOnly(this.entry_date_start));
    params = params.append('entry_date_end', this.sharedService.getDateOnly(this.entry_date_end));

    this.viewWageService.getViewWageAll(params).subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.dataSource = sResponse.data;
        for (let e in sResponse.data){
          sResponse.data[e].employee.full_name=this.getEmployeeFullName(sResponse.data[e].employee);
        }
      } else {
        this.toastr.error('Failed to Get Wages Entries,Please Try Again');
      }

    });
  }


  onRowClick(row) {
    
    let view_wage: any = {};
    view_wage.entry_date_start = this.sharedService.getDateOnly(this.entry_date_start);
    view_wage.entry_date_end = this.sharedService.getDateOnly(this.entry_date_end);
    view_wage.employee_id = row._id;
    view_wage.employee_name = this.getEmployeeFullName(row.employee);
    this.router.navigate(['mpc', 'view-wage-employee'], { queryParams: view_wage });
  }

  toTitleCase(str) {
    return str.replace(/\s\s+/g, ' ').trim().split(' ')
      .map(w => w[0].toUpperCase() + w.substr(1).toLowerCase())
      .join(' ');

  }

  getEmployeeFullName(employee) {
    let fullName = employee.first_name;
    if (employee.middle_name) {
      fullName += " " + employee.middle_name;
    }
    if(employee.last_name){
      fullName += " " + employee.last_name;
    }
    return this.toTitleCase(fullName);
  }
}
