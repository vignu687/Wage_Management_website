import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Roasting } from './../../../../models/roasting';
import { Tray } from './../../../../models/tray';
import { RoastingService } from './../../shared/roasting.service';
import { SharedService } from './../../../shared/services/shared.service';
import { ToastrService } from 'ngx-toastr';
import { HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-roasting',
  templateUrl: './roasting.component.html',
  styleUrls: ['./roasting.component.scss'],
  encapsulation:ViewEncapsulation.None
})
export class RoastingComponent implements OnInit {

  @ViewChild('roastingForm') roastingForm: NgForm;

  displayedColumns = ['updated_date', 'total_weight','action'];
  roasting: Roasting[] = [];
  roastingModel: Roasting = new Roasting();
  roastingTrays: Tray[] = [];
  entryTypes = ['In', 'Out'];
  
  constructor(private roastingService: RoastingService, private toastr: ToastrService,
    private sharedService: SharedService) { }

  ngOnInit(): void {
    this.addRoastingTray();
  }

  addRoastingTray() {
    this.roastingTrays.push(this.getRoastingTrayModel());
  }

  deleteRoastingTray(index) {
    this.roastingTrays.splice(index,1);
  }

  getRoastingTrayModel() {
    return new Tray();
  }

  getRoastings(reset = true) {

    let params = new HttpParams();
    params = params.append('origin_id', this.roastingModel.origin_id);
    params = params.append('lot_id', this.roastingModel.lot_id);
    params = params.append('entry_date', this.roastingModel.entry_date);
    params = params.append('entry_type', this.roastingModel.entry_type);

    this.roasting = [];

    this.roastingService.getRoastings(params).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.roasting = sResponse.data;
        } else {
          this.toastr.error('Failed to Get Roasting Entries, Please Try Again');
        }
      });
  }

  onRoastingSubmit() {
    const postRoastingModel = JSON.parse(JSON.stringify(this.roastingModel));
    postRoastingModel.trays = JSON.parse(JSON.stringify(this.roastingTrays));

    this.roastingService.saveRoastings(postRoastingModel).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Roasting Entry Saved Successfully');
          this.resetForm();
        }
        else {
          this.toastr.error('Failed to Save Roasting Entry, Please Try Again');
        }   
        this.getRoastings();
      }
    );
  }

  onEntryTypeChange() {
    this.getRoastings();
  }

  getRoastingById(id) {
    this.roastingService.getRoastingById(id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.roastingModel = sResponse.data;
          this.roastingTrays = JSON.parse(JSON.stringify(this.roastingModel.trays));
          this.roastingModel.trays = [];
        } else {
          this.toastr.error('Failed to Get Roasting Entry, Please Try Again');
        }

      }
    );
  }

  deleteRoastingById(roasting) {
    this.roastingService.deleteRoastingById(roasting.id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Successfully Deleted Roasting Entry for Date: ' + this.sharedService.getDateOnly(roasting.updated_date, 'YYYY MMM DD'));
          if (roasting.id == this.roastingModel.id) {
            this.resetForm();
          } 
        } else {
          this.toastr.error('Failed to Delete Roasting Entry, Please Try Again');
        }
        this.getRoastings(false);
      }
    );
  }

  resetForm(event = null) {
    this.roastingTrays = [];
    this.addRoastingTray();
    if (event) {
      this.roastingForm.resetForm();
    } else {
      this.roastingForm.resetForm(this.roastingForm.value);
    }
    delete this.roastingModel.id;
  }

}
