import { trigger, state, style, transition, animate } from '@angular/animations';
import { HttpParams } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SharedService } from './../../../shared/services/shared.service';
import { ViewWageService } from './../../shared/view-wage.service';

@Component({
  selector: 'app-view-wage-employee',
  templateUrl: './view-wage-employee.component.html',
  styleUrls: ['./view-wage-employee.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class ViewWageEmployeeComponent implements OnInit {


  wageDetailsDataSource = [];
  columnsToDisplay = ['date', 'wage'];
  expandedElement = null;
  displayedColumns: string[] = ['work', 'wage'];

  currentDate = new Date();
  entry_date_start = new Date();
  entry_date_end = new Date();
  employee_id;
  employee_name;

  workDetailsDataSource = [];

  /** Gets the total wage of all transactions. */


  getTotalWage() {
    return this.wageDetailsDataSource.map(d => d.wage).reduce((acc, value) => acc + value, 0);
  }

  /** Gets the total work wage of all transactions. */
  getTotalWorkWage() {
    return this.workDetailsDataSource.map(d => d.wage).reduce((acc, value) => acc + value, 0);
  }

  constructor(private rout: ActivatedRoute,
    private sharedService: SharedService,
    private viewWageService: ViewWageService) {

    let entryDateStart = this.rout.snapshot.queryParams['entry_date_start'];
    let entryDateEnd = this.rout.snapshot.queryParams['entry_date_end'];
    let employeeId = this.rout.snapshot.queryParams['employee_id'];
    this.employee_name = this.rout.snapshot.queryParams['employee_name'];

    this.entry_date_start = entryDateStart ? entryDateStart : this.entry_date_start.setDate(this.entry_date_start.getDate() - 7);
    this.entry_date_end = entryDateEnd ? entryDateEnd : this.entry_date_end;
    this.employee_id = employeeId ? employeeId : null;


  }

  ngOnInit(): void {
    this.onFilterClick(null);
  }

  onFilterClick(filterForm) {

    let params = new HttpParams();
    params = params.append('entry_date_start', this.sharedService.getDateOnly(this.entry_date_start));
    params = params.append('entry_date_end', this.sharedService.getDateOnly(this.entry_date_end));
    params = params.append('employee_id', this.employee_id);

    this.viewWageService.getViewWageAll(params).subscribe(sResponse => {

      this.wageDetailsDataSource = sResponse.data;

      this.wageDetailsDataSource.map(o => {o.wage = ((o.human_cutting? o.human_cutting:o.human_cutting=0)  + (o.human_grading?o.human_grading:o.human_grading=0)  + (o.human_peeling?o.human_peeling:o.human_peeling=0))})
    })
  }


  onRowClick(row) {

    this.expandedElement = this.expandedElement === row ? null : row;
    this.workDetailsDataSource = [];

    this.workDetailsDataSource.push({ work: 'Cutting', wage: row.human_cutting });
    this.workDetailsDataSource.push({ work: 'Grading', wage: row.human_grading });
    this.workDetailsDataSource.push({ work: 'Peeling', wage: row.human_peeling });

  }

}
