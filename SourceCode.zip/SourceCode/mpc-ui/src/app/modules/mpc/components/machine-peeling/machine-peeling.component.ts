import { HttpParams } from '@angular/common/http';
import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MachinePeeling } from './../../../../models/machine.peeling';
import { MachinePeelingService } from '../../shared/machine.peeling.service';
import { Tray } from './../../../../models/tray';
import { SharedService } from './../../../shared/services/shared.service';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { MachineService } from './../../../mpc/shared/machine.service';
import { Machine } from './../../../../models/machine';

@Component({
  selector: 'app-machine-peeling',
  templateUrl: './machine-peeling.component.html',
  styleUrls: ['./machine-peeling.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class MachinePeelingComponent implements OnInit {

  @ViewChild('machinePeelingForm') machinePeelingForm: NgForm;

  displayedColumnsForIn = ['updated_date', 'total_tray_weight','action'];
  displayedColumnsForOut = ['updated_date', 'wholes_weight','pieces_weight','husk_weight','action'];
  machinePeelings: MachinePeeling[] = [];
  machinePeelingModel: MachinePeeling = new MachinePeeling();
  machinePeelingTrays: Tray[] = [];
  machines: Machine[] = [];
  entryTypes = ['In', 'Out'];

  constructor(private machinePeelingService: MachinePeelingService,private machineService: MachineService, private toastr: ToastrService,
    private sharedService: SharedService) { }


  ngOnInit(): void {
    this.addpeelingTray();
  }

  addpeelingTray() {
    this.machinePeelingTrays.push(this.getpeelingModel());
  }

  deletepeelingTray(index) {
    this.machinePeelingTrays.splice(index, 1);
  }

  getpeelingModel() {
    return new Tray();
  }

  getMachinePeelings(reset = true) {

    let params = new HttpParams();
    params = params.append('origin_id', this.machinePeelingModel.origin_id);
    params = params.append('lot_id', this.machinePeelingModel.lot_id);
    params = params.append('entry_date', this.machinePeelingModel.entry_date);
    params = params.append('entry_type', this.machinePeelingModel.entry_type);
    params = params.append('machine_name', this.machinePeelingModel.machine_name);

    this.machinePeelings = [];

    this.machinePeelingService.getMachinePeelings(params).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.machinePeelings = sResponse.data;
        } else {
          this.toastr.error('Failed to Get Machine Peeling Entries, Please Try Again');
        }
      });

  }

  onMachinePeelingSubmit() {

    const postModel = JSON.parse(JSON.stringify(this.machinePeelingModel));
    postModel.trays = JSON.parse(JSON.stringify(this.machinePeelingTrays));

    this.machinePeelingService.saveMachinePeelings(postModel).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Machine Peeling Saved Successfully');
          this.resetForm();
        } else  {
          this.toastr.error('Failed to Save Machine Peeling Entry, Please Try Again');
        }

        this.getMachinePeelings();
      }
    );
  }

  onEntryTypeChange() {
    this.getAllMachines();
    this.machinePeelingModel.machine_name=null;
    this.machinePeelings = [];
  }

  onMachineNameChange(){
    this.getMachinePeelings();
  }

  getMachinePeelingById(id) {
    this.machinePeelingService.getMachinePeelingsById(id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
        this.machinePeelingModel = sResponse.data;  
        this.machinePeelingTrays = JSON.parse(JSON.stringify(this.machinePeelingModel.trays));
        this.machinePeelingModel.trays = [];
        } else {
          this.toastr.error('Failed to Get Machine Peeling Entry, Please Try Again');
        }
      }
    );
  }

  deleteMachinePeelingById(machinePeeling) {
    this.machinePeelingService.deleteMachinePeelingsById(machinePeeling.id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Successfully Deleted Machine Peeling Entry for Date: ' + this.sharedService.getDateOnly(machinePeeling.updated_date, 'YYYY MMM DD'));
          if (machinePeeling.id == this.machinePeelingModel.id) {
            this.resetForm();
          }
        } else {
          this.toastr.error('Failed to Delete Machine Peeling Entry, Please Try Again');
        }
        this.getMachinePeelings(false);
      }
    );
  }

  resetForm(event = null) {
    this.machinePeelingTrays = [];
    this.addpeelingTray();
    if (event) {
      this.machinePeelingForm.resetForm();
    } else {
      this.machinePeelingForm.resetForm(this.machinePeelingForm.value);
    }
    delete this.machinePeelingModel.id;
    delete this.machinePeelingModel.wholes_weight;
    delete this.machinePeelingModel.pieces_weight;
    delete this.machinePeelingModel.husk_weight;
  }

  getAllMachines() {
    this.machineService.getAllMachinesByType('peeling').subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.machines = sResponse.data;
      } else {
        this.toastr.error('Failed to Get Peeling Machines, Please Try Again');
      }
    });
  }
}
