import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormControl, NgForm } from '@angular/forms';
import { Observable, Subject } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { HumanCuttingService } from '../../shared/human.cutting.service';
import { ToastrService } from 'ngx-toastr';
import { EmployeeService } from './../../../management/shared/employee.service';
import { HttpParams } from '@angular/common/http';
import { SharedService } from './../../../shared/services/shared.service';
import { HumanCutting } from 'src/app/models/human.cutting';

@Component({
  selector: 'app-human-cutting',
  templateUrl: './human-cutting.component.html',
  styleUrls: ['./human-cutting.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class HumanCuttingComponent implements OnInit {

  @ViewChild('cuttingForm') cuttingForm: NgForm;

  displayedColumns = ['updated_date','job_description','total_weight', 'action'];

  employeeControl = new FormControl();
  employeeFilterControl = new FormControl();
  filteredOptions: Observable<string[]>;
  protected _onDestroy = new Subject<void>();

  cuttingModel: HumanCutting = new HumanCutting();
  cuttings = [];
  jobDescriptions = [];
  questions = [];
  employees = [];
  trayValue = "";

  constructor(private humanCuttingService: HumanCuttingService,
    private toastr: ToastrService,
    private employeeService: EmployeeService,
    private sharedService: SharedService) { }

  ngOnInit(): void {
    this.filteredOptions = this.employeeFilterControl.valueChanges
      .pipe(
        startWith(''),
        map(employee => employee && typeof employee === 'object' ? this.displayFn(employee) : employee),
        map((name: string) => name ? this._filter(name) : this.employees.slice())
      );

    this.getEmployees();
  }

  private _filter(value: string): string[] {
    if (value != null) {
      const filterValue = value.toLowerCase();
      if (this.employees.filter(employee => (employee.first_name + employee.middle_name + employee.last_name).toLowerCase().includes(filterValue)).length > 0) {
        return this.employees.filter(employee => (employee.first_name + employee.middle_name + employee.last_name).toLowerCase().includes(filterValue));
      } else {
        return this.employees.filter(employee => employee.username.includes(filterValue));
      }
    }

  }

  displayFn = (employee) => {
    return employee ? this.getEmployeeFullName(employee) : '';
  }

  toTitleCase(str) {
    return str.replace(/\s\s+/g, ' ').trim().split(' ')
      .map(w => w[0].toUpperCase() + w.substr(1).toLowerCase())
      .join(' ');

  }

  getEmployeeFullName(employee) {
    let fullName = employee.first_name;
    if (employee.middle_name) {
      fullName += " " + employee.middle_name;
    }
    return this.toTitleCase(fullName += " " + employee.last_name);
  }

  getEmployees() {
    this.employeeService.getWageEmployeesAll().subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.employees = sResponse.data;
        this.getJobDescriptions();
      } else {
        this.toastr.error('Failed to Get Employee Records, Please Try Again');
      }
    });
  }

  onJobDescriptionChange(event) {
    this.humanCuttingService.getQuestionsByDescription(event.value).subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.questions = sResponse.data;
      } else {
        this.toastr.error('Failed to Get Human Cutting Fields, Please Try Again');
      }
    });
  }

  private getJobDescriptions() {
    this.humanCuttingService.getHumanCuttingDescriptions().subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.jobDescriptions = sResponse.data;
      } else {
        this.toastr.error('Failed to Get Human Cutting Job Descriptions, Please Try Again');
      }
    });
  }

  getCuttingsAll(employee_id) {  
    this.cuttingModel.employee_id = employee_id;
    let params = new HttpParams();
    params = params.append('origin_id', this.cuttingModel.origin_id);
    params = params.append('lot_id', this.cuttingModel.lot_id);
    params = params.append('entry_date', this.cuttingModel.entry_date);
    params = params.append('employee_id', this.cuttingModel.employee_id);
    this.cuttings = [];
    this.humanCuttingService.getHumanCuttings(params).subscribe(sResponse => {
      if (sResponse.status && !sResponse.message) {
        this.cuttings = sResponse.data;
        this.cuttings.map(o => o.job_description = this.toTitleCase(o.job_description.replaceAll("_", " ")));
      } else {
        this.toastr.error('Failed to Get Human Cutting Entries, Please Try Again');
      }
    });
  }

  onCuttingFormSubmit(form) {
    const postCuttingModel = JSON.parse(JSON.stringify(this.cuttingModel));
    postCuttingModel.value = JSON.parse(JSON.stringify(this.questions));

    this.humanCuttingService.saveHumanCutting(postCuttingModel).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.toastr.success('Human Cutting Entry Saved Successfully');
          this.resetForm();
        } else {
          this.toastr.error('Failed to Save Human Cutting Entry, Please Try Again');
        }
        this.getCuttingsAll(this.cuttingModel.employee_id);
      }
    );
  }

  resetForm(event = null) {
    this.questions = [];
    if (event) {
      this.employeeControl.setValue(null);
      this.cuttingForm.resetForm();
      this.cuttings = [];
    } else {
      this.cuttingForm.resetForm(this.cuttingForm.value);
    }
    delete this.cuttingModel.id;
    delete this.cuttingModel.job_description;
  }

  getCuttingById(id) {
    this.humanCuttingService.getHumanCuttingById(id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
        this.cuttingModel = sResponse.data;
        this.questions = JSON.parse(JSON.stringify(this.cuttingModel.value));
        delete this.cuttingModel.value;
        } else {
          this.toastr.error('Failed to Get Human Cutting Entry, Please Try Again');
        }
      }
    );
  }

  deleteCuttingById(cutting) {
    this.humanCuttingService.deleteHumanCuttingById(cutting.id).subscribe(
      sResponse => {
        if (sResponse.status && !sResponse.message) {
        this.toastr.success('Successfully Deleted Human Cutting Entry for Date: ' + this.sharedService.getDateOnly(cutting.updated_date, 'YYYY MMM DD'));
          if (cutting.id == this.cuttingModel.id) {
            this.resetForm();
          }
      } else {
        this.toastr.error('Failed to Delete Human Cutting Entry, Please Try Again');
      }
        this.getCuttingsAll(this.cuttingModel.employee_id);
      }
    );
  }

  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

}
