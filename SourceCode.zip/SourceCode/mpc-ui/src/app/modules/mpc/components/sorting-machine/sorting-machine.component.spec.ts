import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SortingMachineComponent } from './sorting-machine.component';

describe('SortingMachineComponent', () => {
  let component: SortingMachineComponent;
  let fixture: ComponentFixture<SortingMachineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SortingMachineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SortingMachineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
