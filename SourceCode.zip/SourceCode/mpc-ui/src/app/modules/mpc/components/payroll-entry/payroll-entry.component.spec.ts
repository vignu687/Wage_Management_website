import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PayrollEntryComponent } from './payroll-entry.component';

describe('PayrollEntryComponent', () => {
  let component: PayrollEntryComponent;
  let fixture: ComponentFixture<PayrollEntryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PayrollEntryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayrollEntryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
