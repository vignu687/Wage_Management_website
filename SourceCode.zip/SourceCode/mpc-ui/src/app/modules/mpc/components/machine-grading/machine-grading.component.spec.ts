import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MachineGradingComponent } from './machine-grading.component';

describe('MachineGradingComponent', () => {
  let component: MachineGradingComponent;
  let fixture: ComponentFixture<MachineGradingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MachineGradingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MachineGradingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
