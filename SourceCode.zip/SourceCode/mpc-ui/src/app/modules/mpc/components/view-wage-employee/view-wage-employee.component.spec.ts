import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewWageEmployeeComponent } from './view-wage-employee.component';

describe('ViewWageEmployeeComponent', () => {
  let component: ViewWageEmployeeComponent;
  let fixture: ComponentFixture<ViewWageEmployeeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewWageEmployeeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewWageEmployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
