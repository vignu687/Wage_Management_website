import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HumanCuttingComponent } from './human-cutting.component';

describe('HumanCuttingComponent', () => {
  let component: HumanCuttingComponent;
  let fixture: ComponentFixture<HumanCuttingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HumanCuttingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HumanCuttingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
