import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormControl, NgForm } from '@angular/forms';
import { Observable, Subject } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { HumanGradingService } from '../../shared/human.grading.service';
import { ToastrService } from 'ngx-toastr';
import { EmployeeService } from './../../../management/shared/employee.service';
import { HttpParams } from '@angular/common/http';
import { HumanGrading } from './../../../../models/human.grading';
import { SharedService } from './../../../shared/services/shared.service';

@Component({
  selector: 'app-human-grading',
  templateUrl: './human-grading.component.html',
  styleUrls: ['./human-grading.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class HumanGradingComponent implements OnInit {

  @ViewChild('gradingForm') gradingForm: NgForm;

  displayedColumns = ['updated_date','job_description','total_weight', 'action'];

  employeeControl = new FormControl();
  employeeFilterControl = new FormControl();
  filteredOptions: Observable<string[]>;
  protected _onDestroy = new Subject<void>();
  gradingModel: HumanGrading = new HumanGrading();
  gradings = [];
  jobDescriptions = [];
  questions = [];
  employees = [];

  constructor(private humanGradingService: HumanGradingService,
    private toastr: ToastrService,
    private employeeService: EmployeeService,
    private sharedService: SharedService) { }

    ngOnInit() {
      this.filteredOptions = this.employeeFilterControl.valueChanges
        .pipe(
          startWith(''),
          map(employee => employee && typeof employee === 'object' ? this.displayFn(employee) : employee),
          map((name: string) => name ? this._filter(name) : this.employees.slice())
        );
  
      this.getEmployees();
    }

    private _filter(value: string): string[] {
      if (value != null) {
        const filterValue = value.toLowerCase();
        if(this.employees.filter(employee => (employee.first_name +employee.middle_name+employee.last_name).toLowerCase().includes(filterValue)).length>0){
          return this.employees.filter(employee => (employee.first_name +employee.middle_name+employee.last_name).toLowerCase().includes(filterValue));
        } else {
          return this.employees.filter(employee => employee.username.includes(filterValue));
        }
      }
  
    }
  
    displayFn = (employee) => {
      return employee ? this.getEmployeeFullName(employee) : '';
    }
  
    toTitleCase(str) {
      return str.replace(/\s\s+/g, ' ').trim().split(' ')
        .map(w => w[0].toUpperCase() + w.substr(1).toLowerCase())
        .join(' ');
  
    }
  
    getEmployeeFullName(employee) {
      let fullName = employee.first_name;
      if (employee.middle_name) {
        fullName += " " + employee.middle_name;
      }
      if(employee.last_name){
        fullName += " " + employee.last_name;
      }
      return this.toTitleCase(fullName);
    }
  
    getEmployees() {
      this.employeeService.getWageEmployeesAll().subscribe(sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.employees = sResponse.data;
          this.getJobDescriptions();
        } else {
          this.toastr.error('Failed to Get Employee Records, Please Try Again');
        }
      });
    }

    getGradingsAll(employee_id) {
      this.gradingModel.employee_id = employee_id;
      let params = new HttpParams();
      params = params.append('origin_id', this.gradingModel.origin_id);
      params = params.append('lot_id', this.gradingModel.lot_id);
      params = params.append('entry_date', this.gradingModel.entry_date);
      params = params.append('employee_id', this.gradingModel.employee_id);
      this.gradings = [];
      this.humanGradingService.getHumanGradings(params).subscribe(sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.gradings = sResponse.data;
          this.gradings.map(o => o.job_description = this.toTitleCase(o.job_description.replaceAll("_", " ")));
        } else {
          this.toastr.error('Failed to Get Human Grading Entries, Please Try Again');
        }
      });
    }
  
    onJobDescriptionChange(event) {
      this.humanGradingService.getQuestionsByDescription(event.value).subscribe(sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.questions = sResponse.data;
        } else {
          this.toastr.error('Failed to Get Human Grading Fields, Please Try Again');
        }
      });
  
    }
  
    private getJobDescriptions() {
      this.humanGradingService.getHumanGradingDescriptions().subscribe(sResponse => {
        if (sResponse.status && !sResponse.message) {
          this.jobDescriptions = sResponse.data;
        } else {
          this.toastr.error('Failed to Get Human Grading Job Descriptions, Please Try Again');
        }
      });
    }
  
    onGradingFormSubmit(form) {
      const postGradingModel = JSON.parse(JSON.stringify(this.gradingModel));
      postGradingModel.value = JSON.parse(JSON.stringify(this.questions));
  
      this.humanGradingService.saveHumanGrading(postGradingModel).subscribe(
        sResponse => {
          if (sResponse.status && !sResponse.message) {
            this.toastr.success('Human Grading Entry Saved Successfully');
            this.resetForm();
          } else {
            this.toastr.error('Failed to Save Human Grading Entry, Please Try Again');
          }
          this.getGradingsAll(this.gradingModel.employee_id);
        }
      );
    }
  
    resetForm(event = null) {
      this.questions = [];
      if (event) {
        this.employeeControl.setValue(null);
        this.gradingForm.resetForm();
        this.gradings = [];
      } else {
        this.gradingForm.resetForm(this.gradingForm.value);
      }
      delete this.gradingModel.id;
      delete this.gradingModel.job_description;
  
    }
  
    getGradingById(id) {
      this.humanGradingService.getHumanGradingById(id).subscribe(
        sResponse => {
          if (sResponse.status && !sResponse.message) {
          this.gradingModel = sResponse.data;
          this.questions = JSON.parse(JSON.stringify(this.gradingModel.value));
          delete this.gradingModel.value;
          } else {
            this.toastr.error('Failed to Get Human Grading Entry, Please Try Again');
          }
        }
      );
    }
  
    deleteGradingById(grading) {
      this.humanGradingService.deleteHumanGradingById(grading.id).subscribe(
        sResponse => {
          if (sResponse.status && !sResponse.message) {
          this.toastr.success('Successfully Deleted Human Grading Entry for Date: ' + this.sharedService.getDateOnly(grading.updated_date, 'YYYY MMM DD'));
            if (grading.id == this.gradingModel.id) {
              this.resetForm();
            }
          } else {
            this.toastr.error('Failed to Delete Human Grading Entry, Please Try Again');
          }
          this.getGradingsAll(this.gradingModel.employee_id);
        }
      );
    }

    ngOnDestroy() {
      this._onDestroy.next();
      this._onDestroy.complete();
    }
  
}
