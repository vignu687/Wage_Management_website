import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

@Pipe({
  name: 'extractUrl'
})
export class ExtractUrlPipe implements PipeTransform {

  constructor(private sanitizer: DomSanitizer) { }
  transform(url) {
    let splitURL = url.split(".");
    if (splitURL[splitURL.lemgth - 1] != 'pdf') {
      url = 'https://view.officeapps.live.com/op/embed.aspx?src=' + url;
    } else {
      url
    }
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
}
