import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpconfigInterceptor } from './services/httpconfig.interceptor';
import { AngularMaterialModule } from '../../angular.material.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ListFilterPipe } from './pipes/list-filter.pipe';
import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_LOCALE, MAT_DATE_FORMATS } from '@angular/material/core';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material/bottom-sheet';
import { FormsModule } from '@angular/forms';
import { InputUpperDirective } from './directives/input-upper.directive';
import { TextareaUpperDirective } from './directives/textarea-upper.directive';
import { EqualValidatorDirective } from './directives/equal-validator.directive';
import { ExtractUrlPipe } from './pipes/extract-url.pipe';
import { WeightValidatorDirective } from './directives/weight-validator.directive';
import { SubtractDirective } from './directives/subtract.directive';
import { OnlynumberDirective } from './directives/onlynumber.directive';
import { MpcGridComponent } from '../mpc/components/mpc-grid/mpc-grid.component';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { AccessPermissionDirective } from './directives/access-permission.directive';


export const APP_DATE_FORMATS = {
  parse: {
    dateInput: 'dd MMM yyyy',
  },
  display: {
    dateInput: 'DD MMM YYYY',
    monthYearLabel: 'MMMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY'
  },
};

@NgModule({
  declarations: [ListFilterPipe, InputUpperDirective, TextareaUpperDirective, EqualValidatorDirective, ExtractUrlPipe, WeightValidatorDirective, SubtractDirective, OnlynumberDirective, MpcGridComponent, AccessPermissionDirective],
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    AngularMaterialModule,
    FlexLayoutModule,
    NgxMatSelectSearchModule
  ],
  exports: [AngularMaterialModule, FlexLayoutModule, ListFilterPipe, FormsModule, InputUpperDirective, TextareaUpperDirective, EqualValidatorDirective, ExtractUrlPipe, WeightValidatorDirective, SubtractDirective, OnlynumberDirective, MpcGridComponent, NgxMatSelectSearchModule, AccessPermissionDirective],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: HttpconfigInterceptor, multi: true },
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },

    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS },
    { provide: MatBottomSheetRef, useValue: {} },
    { provide: MAT_BOTTOM_SHEET_DATA, useValue: {} }
  ],
  entryComponents: []

})
export class SharedModule { }