import { Directive, ElementRef, Input, Renderer2, OnInit, AfterViewInit, } from '@angular/core';
import { AccessManagementService } from "../services/accessmanagement.service"

@Directive({
    selector: '[checkAccess]'
})

export class AccessPermissionDirective implements AfterViewInit {
    @Input() checkAccess: any
    messageEle: any;
    accessType: any;
    permission: any;
    constructor(private elementRef: ElementRef, private accessManagementService: AccessManagementService, private renderer2: Renderer2) {

        //this.checkAccessPermission();

    }


    ngAfterViewInit() {
        
        let accessRule = this.checkAccess.split(',')
      //  this.accessType = accessRule[0]
        this.permission = accessRule[0]
        // if (accessRule.length > 2) {
        //     this.messageEle = accessRule[2]
        // }
        this.checkAccessPermission();
    }

    checkAccessPermission() {

        let hasaccess = this.accessManagementService.canAccess(this.permission)
        if (!hasaccess) {
            this.elementRef.nativeElement.style.setProperty('display', 'none', 'important');

            if (this.messageEle) {
                this.renderer2.setStyle(this.elementRef.nativeElement.previousElementSibling, 'display', 'block')
            }
        }
        return;
    }
}