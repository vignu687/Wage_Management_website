import { Directive, ElementRef, forwardRef, HostListener, Renderer2 } from '@angular/core';
import { NG_VALUE_ACCESSOR, DefaultValueAccessor } from '@angular/forms';

const SUBTRACT_INPUT_CONTROL_VALUE_ACCESSOR = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => SubtractDirective),
  multi: true,
};

@Directive({
  selector: '[subtract]',
  host: {
    // When the user updates the input
    '(blur)': 'onBlur($event.target.value)',
  },
  providers: [
    SUBTRACT_INPUT_CONTROL_VALUE_ACCESSOR,
  ]
})
export class SubtractDirective extends DefaultValueAccessor {

  // regexStr = "[-()0-9]+";
  inputElement: HTMLElement;

  constructor(renderer: Renderer2, elementRef: ElementRef) {
    super(renderer, elementRef, false);
  }

  onBlur(value: any) {
    
    const transformed = this.trim(value);
    const numbers = transformed.split('-');
    let subtract = this.trim(numbers[0]);
    if (numbers.length > 1 && numbers[1]) {
      subtract = parseFloat(numbers[0]) - parseFloat(numbers[1]);
      if(subtract && subtract>=0){
        subtract=Math.round(subtract * 100) / 100
        super.writeValue(subtract);
        this.onChange(subtract);
      } else {
        super.writeValue('');
        this.onChange('');
      }
    }
  }

  trim(value) {
    const result = value && typeof value === 'string'
      ? value.trim()
      : value;
    return result;
  }

  // @HostListener("keypress", ["$event"]) onKeyPress(event) {
  //   return new RegExp(this.regexStr).test(event.key);
  // }

  private navigationKeys = [
    'Backspace',
    'Delete',
    'Tab',
    'Escape',
    'Enter',
    'Home',
    'End',
    'ArrowLeft',
    'ArrowRight',
    'Clear',
    'Copy',
    'Paste'
  ];


  @HostListener("keydown", ["$event"]) onKeyDown(e: KeyboardEvent) {
    if (
      this.navigationKeys.indexOf(e.key) > -1 || // Allow: navigation keys: backspace, delete, arrows etc.
      (e.key === 'a' && e.ctrlKey === true) || // Allow: Ctrl+A
      (e.key === 'c' && e.ctrlKey === true) || // Allow: Ctrl+C
      (e.key === 'v' && e.ctrlKey === true) || // Allow: Ctrl+V
      (e.key === 'x' && e.ctrlKey === true) || // Allow: Ctrl+X
      (e.key === 'a' && e.metaKey === true) || // Allow: Cmd+A (Mac)
      (e.key === 'c' && e.metaKey === true) || // Allow: Cmd+C (Mac)
      (e.key === 'v' && e.metaKey === true) || // Allow: Cmd+V (Mac)
      (e.key === 'x' && e.metaKey === true) // Allow: Cmd+X (Mac)
    ) {
      // let it happen, don't do anything
      return;
    }
    // Ensure that it is a number and stop the keypress
    const pattern = new RegExp(/^[-.0-9]*$/);
    const result = pattern.test(e.key);
    if (!result) {
      e.preventDefault();
    }
  }

  @HostListener('paste', ['$event'])
  onPaste(event: ClipboardEvent) {
    event.preventDefault();
    const pastedInput: string = event.clipboardData
      .getData('text/plain')
      .replace(/\D/g, ''); // get a digit-only string
    document.execCommand('insertText', false, pastedInput);
  }

  @HostListener('drop', ['$event'])
  onDrop(event: DragEvent) {
    event.preventDefault();
    const textData = event.dataTransfer.getData('text').replace(/\D/g, '');
    this.inputElement.focus();
    document.execCommand('insertText', false, textData);
  }

}
