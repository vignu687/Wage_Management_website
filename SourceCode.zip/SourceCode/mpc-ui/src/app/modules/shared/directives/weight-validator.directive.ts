import { Directive, forwardRef } from "@angular/core";
import { AbstractControl, NG_VALIDATORS, Validator } from "@angular/forms";

@Directive({
    selector:'[validateWeight][formControlName],[validateWeight][formControl],[validateWeight][ngModel]',
    providers: [{
        provide: NG_VALIDATORS,
        useExisting:forwardRef(() => WeightValidatorDirective),
        multi:true
    }]
})
export class WeightValidatorDirective implements Validator{

    validate(control:AbstractControl): { [key: string]: any } {
        const value = control.value;

        if(!value){
           return null;
        }

        let splitValues:string[];

        splitValues=(value as string).split("-");

        const containsOneHyphen = splitValues.length==2 ? true : false;

        const firstPartDecimal = /^[0-9]+(\.[0-9]*){0,2}$/g.test(splitValues[0]);

        const secondPartDecimal = /^[0-9]+(\.[0-9]*){0,2}$/g.test(splitValues[1]);

        const validWeight = containsOneHyphen && firstPartDecimal && secondPartDecimal;

        return validWeight ? null : {weightValid:true} ;
    }
}