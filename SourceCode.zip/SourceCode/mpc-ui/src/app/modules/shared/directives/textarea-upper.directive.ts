import { Directive, ElementRef, forwardRef, Renderer2, HostListener } from '@angular/core';
import { NG_VALUE_ACCESSOR, DefaultValueAccessor } from '@angular/forms';

const UPPERCASE_TEXTAREA_CONTROL_VALUE_ACCESSOR = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => TextareaUpperDirective),
  multi: true,
};

@Directive({
  selector: 'textarea',
  providers: [
    UPPERCASE_TEXTAREA_CONTROL_VALUE_ACCESSOR,
  ]
})
export class TextareaUpperDirective extends DefaultValueAccessor {

  @HostListener('copy', ['$event']) blockCopy(e: KeyboardEvent) {
    e.preventDefault();
  }

  @HostListener('cut', ['$event']) blockCut(e: KeyboardEvent) {
    e.preventDefault();
  }

  constructor(renderer: Renderer2, private elementRef: ElementRef) {
    super(renderer, elementRef, false);
  }

  writeValue(value: any): void {

    const transformed = this.transformValue(value);
    super.writeValue(transformed);
  }

  @HostListener('blur', ['$event'])
  onBlur(): void {

    const transformed = this.transformValue(this.elementRef.nativeElement.value);
    super.writeValue(transformed);
    this.onChange(transformed);
  }

  private transformValue(value: any): any {
    const result = value && typeof value === 'string'
      ? value.toUpperCase()
      : value;

    return result;
  }

}
