import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from "@angular/router";
import { AccessManagementService } from "./accessmanagement.service";
import { SharedService } from "./shared.service";
import { environment } from "../../../../environments/environment";
import { Observable } from "rxjs";
import { map } from "rxjs/operators";
import { HttpParams } from '@angular/common/http';

@Injectable({ providedIn: "root" })
export class PermissionService implements CanActivate {

    private appPages = {
        roasting: 'roasting',
        human_cutting: 'human_cutting',
        machine_cutting: 'machine_cutting',
        oven_heating: 'oven_heating',
        cooling: 'cooling',
        machine_peeling: 'machine_peeling',
        human_peeling: 'human_peeling',
        sorting_machine: 'sorting_machine',
        machine_grading: 'machine_grading',
        human_grading: 'human_grading',
        final_oven_entry: 'final_oven_entry',
        view_wage: 'view_wage',
        view_wage_employee: 'view_wage_employee',
        payroll_entry: 'payroll_entry',
        management: 'management',
        reporting: 'reporting'
    }

    get AppPages() {
        return this.appPages;
    }

    get pageArray() {
        return Object.values(this.appPages);
    }

    constructor(
        private sharedService: SharedService,
        private accessManagementService: AccessManagementService
    ) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {

        let user = this.sharedService.getLoggedUser()
        if (user) {
            
            let params = new HttpParams();
            params = params.append('_id', user.id);

            return this.accessManagementService.getPermissionsByUser(params).pipe(
                map(sRepsonse => {

                    if (!sRepsonse) {
                        this.sharedService.accessForbidden()
                        return false;
                    }
                    return true

                }))
        }
        return false
    }
}
