import { Injectable } from "@angular/core";
import {
  ActivatedRouteSnapshot,
  CanActivate,
  Router,
  RouterStateSnapshot,
} from "@angular/router";
import Swal from "sweetalert2";
import { SharedService } from "./shared.service";
import { AccessManagementService } from './accessmanagement.service';
import { Observable } from "rxjs";


@Injectable({ providedIn: "root" })
export class AuthGuardService implements CanActivate {
  constructor(
    private router: Router,
    private sharedService: SharedService,
    private accessManagementService: AccessManagementService
  ) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    
    if (route.data.access) {

      let accessName = route.data.access

      if (this.accessManagementService.canAccess(accessName)) {
        return true;
      }
      else {
        Swal.fire({
          title: 'Unauthorized Access',
          text: 'You do not have permission to access this page.',
          icon: 'error',
          confirmButtonText: 'OK',
          confirmButtonColor: '#f27474',
          allowOutsideClick: false,
          allowEscapeKey: false
        }).then(
          data => {
            this.sharedService.logout();
            return false;
          }
        )
      }
    }
    else {
      return false;
    }
  }
}
