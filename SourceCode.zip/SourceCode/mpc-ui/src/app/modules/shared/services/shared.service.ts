import { Injectable } from '@angular/core';
import { Subject, BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';
import * as _moment from 'moment';
import Swal from 'sweetalert2';


const moment = (_moment as any).default ? (_moment as any).default : _moment;

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  private loggedUser: any;
  private eid: any;
  private headerTitle = new BehaviorSubject<string>("Clinical Command Center");
  public headerTitleObservable = this.headerTitle.asObservable();
  private header_key = "xco9,829i,ibbb,d80x,1h6l";

  public sideNavState$: Subject<boolean> = new Subject();
  private searchText: Subject<string> = new Subject<string>();
  currentSearchText = this.searchText.asObservable();
  private menuAccess: any;


  public executeBeforeUnload: boolean;

  constructor(public router: Router) {
    this.loggedUser = null;

    this.executeBeforeUnload = true;
    this.getLoggedUser();
  }

  changeSearchText(text: string) {
    this.searchText.next(text);
  }

  setLoggedUser(sData) {
    if (sData) {
      sessionStorage.setItem("loggedUser", JSON.stringify(sData));
      this.setEID(sData.id);
    } else {
      this.loggedUser = null;
      sessionStorage.removeItem("loggedUser");
    }
  }

  getLoggedUser(key?) {

    if (!this.loggedUser && sessionStorage.getItem('loggedUser')) {
      this.loggedUser = JSON.parse(sessionStorage.getItem('loggedUser'));
    }

    if (key) {
      return this.loggedUser ? this.loggedUser[key] : null;
    }
    return this.loggedUser;
  }

  changeHeaderTitle(title: string) {
    this.headerTitle.next(title);
  }

  logout(sRefresh: boolean = true): any {
    this.loggedUser = null;
    sessionStorage.clear();

    return this.router.navigate(['login'], { replaceUrl: true });
  }

  getDateOnly(sDateString, format = 'YYYY-MM-DD') {
    return sDateString ? moment(sDateString).format(format) : sDateString;
  }

  getSessionUserlogObject(actionType) {
    return {
      "user_id": this.getLoggedUser()['id'].toString(),
      "url": window.location.href,
      "action": actionType
    }
  }

  reload() {

    this.executeBeforeUnload = false;
    window.location.reload();
    this.executeBeforeUnload = true;
  }


  getEID() {

    return this.eid;
  }

  setEID(eid) {

    this.eid = eid;
  }

  getHeaderEncryptionKey() {
    return this.header_key;
  }

  setMenuAccessConfig(sData) {

    if (sData) {
      sessionStorage.setItem("menu_access_config", JSON.stringify(sData));
    } else {
      sessionStorage.removeItem("menu_access_config");
    }
  }

  getMenuAccessConfig() {
    if (!this.menuAccess && sessionStorage.getItem("menu_access_config")) {
      this.menuAccess = JSON.parse(
        sessionStorage.getItem("menu_access_config")
      );
    }

    return this.menuAccess;
  }

  accessForbidden() {
    Swal.fire({
      html:
        '<p class="swal2-main-text">Access forbidden</p>' +
        '<p class="swal2-sub-text">Please contact admin</p>',
      confirmButtonText: 'OK',
      confirmButtonColor: '#f27474',
      allowOutsideClick: false,
      allowEscapeKey: false,
      icon: 'error',
    }).then((result) => {
      this.logout(true);
    });
  }

}
