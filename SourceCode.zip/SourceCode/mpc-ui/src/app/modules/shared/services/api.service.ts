import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  private ROOT_URL = JSON.parse(JSON.stringify(environment.mpc_url));;
  constructor(
    private http: HttpClient,
  ) { }

  getRequest(path: string, id = null, params: HttpParams = new HttpParams()): Observable<any> {
    path = id ? `${path}${'/'}${id}` : path;
    return this.http.get(`${this.ROOT_URL}${path}`, { params })
  }

  putRequest(path: string, id = null, body: Object = {}): Observable<any> {
    path = id ? `${path}${'/'}${id}` : path;
    return this.http.put(`${this.ROOT_URL}${path}`, body);
  }

  postRequest(path: string, body: Object = {}): Observable<any> {
    return this.http.post(`${this.ROOT_URL}${path}`, body);
  }

  deleteRequest(path,id): Observable<any> {
    path = id ? `${path}${'/'}${id}` : path;
    return this.http.delete(`${this.ROOT_URL}${path}`);
  }

}
