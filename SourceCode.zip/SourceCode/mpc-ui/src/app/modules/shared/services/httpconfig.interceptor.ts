import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse,
  HttpHeaders
} from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { tap, catchError, finalize } from 'rxjs/operators';
import { NgxSpinnerService } from 'ngx-spinner';
import { SharedService } from './shared.service';
import { ToastrService } from 'ngx-toastr';

@Injectable()
export class HttpconfigInterceptor implements HttpInterceptor {

  constructor(private spinner: NgxSpinnerService,
    private sharedService: SharedService,
    private toaster: ToastrService) { }

  getHeaders(request) {

    let httpReq = request.clone();

    const oAuth = this.sharedService.getLoggedUser();

    if (oAuth) {
      httpReq = request.clone({
        headers: new HttpHeaders().set('Authorization', `${oAuth.token}`)
      });
    }

    return httpReq;
  }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {

    this.spinner.show();
    const httpsReq = this.getHeaders(request);
    return next.handle(httpsReq)
      .pipe(
        catchError(err => {

          if (err instanceof HttpErrorResponse && err.status === 401) {
            console.log(err);
          }
          let error = err.error;
          error.message = error.message || error.error_description;
          if (!err.error.message && err instanceof HttpErrorResponse) {
            error.message = "Server Error. Please try later";
          }
          return throwError(error);
        }), finalize(() => {
          this.spinner.hide();
        })
      );
  }
}
