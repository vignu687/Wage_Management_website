export const departments = [
    {
        id: 1,
        label: 'Roasting',
        key: 'roasting'
    }, {
        id: 2,
        label: 'Human Cutting',
        key: 'human_cutting'
    }, {
        id: 3,
        label: 'Machine Cutting',
        key: 'machine_cutting'
    }, {
        id: 4,
        label: 'Oven Heating',
        key: 'oven_heating'
    }, {
        id: 5,
        label: 'Cooling',
        key: 'cooling'
    }, {
        id: 6,
        label: 'Machine Peeling',
        key: 'machine_peeling'
    }, {
        id: 7,
        label: 'Human Peeling',
        key: 'human_peeling'
    }, {
        id: 8,
        label: 'Sorting Machine',
        key: 'sorting_machine'
    }, {
        id: 9,
        label: 'Machine Grading',
        key: 'machine_grading'
    }, {
        id: 10,
        label: 'Human Grading',
        key: 'human_grading'
    }, {
        id: 11,
        label: 'Final Oven Entry',
        key: 'final_oven_entry'
    }
]
