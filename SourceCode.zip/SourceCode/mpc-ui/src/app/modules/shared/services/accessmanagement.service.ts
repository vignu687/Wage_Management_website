import { Injectable } from '@angular/core';
import { ApiService } from '../../shared/services/api.service';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { SharedService } from './shared.service';

@Injectable({ providedIn: "root" })
export class AccessManagementService {

    public accessPermissions: any;
    constructor(public apiService: ApiService, public sharedService: SharedService) {
    }


    getPermissionsByUser(params): Observable<any> {

        return this.apiService.getRequest('users/permission', null, params).pipe(
            map(
                sResponseData => {
                    
                    let user = sResponseData.data;
                    this.accessPermissions = user.pages;

                    let loggedinUser = JSON.parse(JSON.stringify(this.sharedService.getLoggedUser()))
                    loggedinUser.pages = user.pages;
                    this.sharedService.setLoggedUser(null)
                    this.sharedService.setLoggedUser(loggedinUser)
                    return this.accessPermissions;

                }
            ), catchError((err) => {
                return err;
            })
        );

    }


    canAccess(perm): boolean {
        
        return this.accessPermissions.findIndex(o => o.toLowerCase() == perm.toLowerCase()) != -1;
    }

}

