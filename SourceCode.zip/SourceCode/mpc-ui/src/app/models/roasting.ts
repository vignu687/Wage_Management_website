export class Roasting {
    id: string;
    origin_id: string;
    lot_id: string;
    entry_date: string;
    entry_type: string;
    trays: [];

    constructor() {

    }
}
