export class Employee {
    id: string;
    first_name: string;
    middle_name: string;
    last_name : string;
    username: string;
    loan_balance : number;

    constructor() {

    }
}
