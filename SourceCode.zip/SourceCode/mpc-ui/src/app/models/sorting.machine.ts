export class SortingMachine {
    id: string;
    origin_id: string;
    lot_id: string;
    entry_date: string;
    entry_type : string;
    weight_type: string;
    machine_name : string;
    trays : [];
    weight_trays : [];

    constructor() {

    }
}
