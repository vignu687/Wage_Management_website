export class MachineGrading {
    id: string;
    origin_id: string;
    lot_id: string;
    entry_date: string;
    machine_name : string;
    trays : [];

    constructor() {

    }
}
