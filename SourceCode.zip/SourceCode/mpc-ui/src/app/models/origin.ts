export class Origin {
    id: string;
    name: string;
    updated_date :string;
    updated_by: string;

    constructor() {

    }
}
