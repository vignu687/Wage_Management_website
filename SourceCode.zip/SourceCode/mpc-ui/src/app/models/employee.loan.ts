export class EmployeeLoan {
    id: string;
    employee_id: string;
    event_type: string;
    amount : number;
    comment: string;
    updated_date :string;
    updated_by: string;

    constructor() {

    }
}
