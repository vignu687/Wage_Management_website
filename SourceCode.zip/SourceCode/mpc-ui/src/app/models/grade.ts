export class Grade {
    id: string;
    name: string;
    updated_date :string;
    updated_by: string;

    constructor() {

    }
}
