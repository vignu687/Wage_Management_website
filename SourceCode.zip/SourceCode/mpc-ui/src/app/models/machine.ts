export class Machine {
    id: string;
    name: string;
    type: String;
    purchase_date : String;
    updated_date :string;
    updated_by: string;

    constructor() {

    }
}
