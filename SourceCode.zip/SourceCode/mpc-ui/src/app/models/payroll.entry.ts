export class PayrollEntry {
    id: string;
    employees: [];
    employee_id: string;
    entry_type: string;
    entry_date : string;
    entry_category : string;
    amount : number;
    updated_date :string;
    updated_by: string;

    constructor() {

    }
}
