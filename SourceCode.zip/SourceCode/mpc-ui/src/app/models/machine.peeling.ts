export class MachinePeeling {
    id: string;
    origin_id: string;
    lot_id: string;
    entry_date: string;
    entry_type: string;
    trays: [];
    machine_name : string;
    wholes_weight : number;
    pieces_weight : number;
    husk_weight : number;

    constructor() {

    }
}
