export class MachineCutting {
    id: string;
    origin_id: string;
    lot_id: string;
    entry_date: string;
    entry_type: string;
    machine_name : string;
    trays: [];

    constructor() {

    }
}
