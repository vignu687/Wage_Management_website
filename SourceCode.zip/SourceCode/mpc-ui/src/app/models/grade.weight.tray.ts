export class GradeWeightTray {
    grade : string;
    weight : number;

    constructor() {

    }
}
