export class WeightType {
    id: string;
    type: string;
    label: string;
    department: string;
    entry_type: string;
    updated_date :string;
    updated_by: string;

    constructor() {

    }
}
