export class Tray {
    tray: number;
    constructor() {

    }
}
