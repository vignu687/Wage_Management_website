export class EntryType {
    id: string;
    type: string;
    label: string;
    updated_date :string;
    updated_by: string;

    constructor() {

    }
}
