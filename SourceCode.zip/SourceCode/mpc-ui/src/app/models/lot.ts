export class Lot {
    id: string;
    origin_id: string;
    origin_name : string;
    name: string;
    date : string;
    count : number;
    updated_date :string;
    updated_by: string;

    constructor() {

    }
}
