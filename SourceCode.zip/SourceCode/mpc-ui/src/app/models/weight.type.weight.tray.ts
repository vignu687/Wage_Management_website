export class WeightTypeWeightTray {
    weight_type : string;
    weight : number;

    constructor() {

    }
}
