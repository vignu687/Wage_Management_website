export class HumanGrading {
    id: string;
    origin_id: string;
    lot_id: string;
    entry_date: string;
    entry_type: string;
    employee_id: string;
    job_description: string;
    value: any;

    constructor() {

    }
}
