import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AppSimpleLayoutComponent } from './layouts/app-simple-layout/app-simple-layout.component';
import { AppFullLayoutComponent } from './layouts/app-full-layout/app-full-layout.component';
import { AppSideNavComponent } from './layouts/app-side-nav/app-side-nav.component';
import { AppHeaderComponent } from './layouts/app-header/app-header.component';
import { AppFooterComponent } from './layouts/app-footer/app-footer.component';
import { AppBreadcrumbComponent } from './layouts/app-breadcrumb/app-breadcrumb.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SharedModule } from './modules/shared/shared.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { NgxSpinnerModule } from 'ngx-spinner';
import { ToastrModule } from 'ngx-toastr';
import { AngularMaterialModule } from './angular.material.module';

@NgModule({
  declarations: [
    AppComponent,
    AppSimpleLayoutComponent,
    AppFullLayoutComponent,
    AppSideNavComponent,
    AppHeaderComponent,
    AppFooterComponent,
    AppBreadcrumbComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AngularMaterialModule,
    FlexLayoutModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({
      maxOpened: 1,
      preventDuplicates: true,
      positionClass: 'toast-top-full-width',
      tapToDismiss: true,
      countDuplicates: true,
      resetTimeoutOnDuplicate: true
    }),
    NgxSpinnerModule,
    SharedModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
