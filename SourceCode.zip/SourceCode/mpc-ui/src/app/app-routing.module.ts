import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PermissionService } from './modules/shared/services/permissions.service';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  { path: 'login', loadChildren: () => import('./modules/login/login.module').then(m => m.LoginModule) },
  {
    path: 'mpc',
    loadChildren: () => import('./modules/mpc/mpc.module').then(m => m.MpcModule),
    canActivate: [PermissionService]
  },
  {
    path: 'form', loadChildren: () => import('./modules/form/form.module').then(m => m.FormModule),
    canActivate: [PermissionService]
  },
  {
    path: 'management',
    loadChildren: () => import('./modules/management/management.module').then(m => m.ManagementModule),
    canActivate: [PermissionService]
  },
  { path: 'report', loadChildren: () => import('./modules/report/report.module').then(m => m.ReportModule) },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
