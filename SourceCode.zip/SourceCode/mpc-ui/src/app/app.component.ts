import { Component } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { svgIcons } from '../assets/icons/_icons';


const iconUrl = "assets/icons"

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'mpc';

  constructor(private matIconRegistry: MatIconRegistry,
    private domSanitizer: DomSanitizer

  ) {
    svgIcons.forEach(o => {
      this.matIconRegistry.addSvgIcon(o, this.domSanitizer.bypassSecurityTrustResourceUrl(`${iconUrl}/${o}.svg`))
    })
  }


}
