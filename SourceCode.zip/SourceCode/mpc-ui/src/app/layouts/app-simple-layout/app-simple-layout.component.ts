import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-simple-layout',
  templateUrl: './app-simple-layout.component.html',
  styleUrls: ['./app-simple-layout.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AppSimpleLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
