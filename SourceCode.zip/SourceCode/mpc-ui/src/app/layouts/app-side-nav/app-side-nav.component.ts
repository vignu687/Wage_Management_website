import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { SharedService } from './../../modules/shared/services/shared.service';
import { onSideNavChange, animateText } from './animations';
import { ToastrService } from 'ngx-toastr';
import { PermissionService } from './../../modules/shared/services/permissions.service';

@Component({
  selector: 'app-side-nav',
  templateUrl: './app-side-nav.component.html',
  styleUrls: ['./app-side-nav.component.scss'],
  animations: [onSideNavChange, animateText],
  encapsulation: ViewEncapsulation.None
})
export class AppSideNavComponent implements OnInit {
  public sideNavState: boolean = false;
  public linkText: boolean = false;
  patientSearchText: string;
  loggedUser: any;
  sRoleType: any;
  constructor(private sharedService: SharedService, private toastr: ToastrService,
    private permissionService: PermissionService) { }

  ngOnInit(): void {
    this.patientSearchText = "";
    //this.loggedUser = this.sharedService.getLoggedUser();
  }

  onSinenavToggle() {
    this.sideNavState = !this.sideNavState

    setTimeout(() => {
      this.linkText = this.sideNavState;
    }, 200)
    this.sharedService.sideNavState$.next(this.sideNavState)
  }

  get pages() {
    return this.permissionService.AppPages;
  }
}
