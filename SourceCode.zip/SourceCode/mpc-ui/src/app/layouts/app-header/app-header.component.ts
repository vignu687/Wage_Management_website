import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { SharedService } from '../../modules/shared/services/shared.service';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-header',
  templateUrl: './app-header.component.html',
  styleUrls: ['./app-header.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AppHeaderComponent implements OnInit {
  
  loggedUser: any;
  cureentDate: Date = new Date();
  userName : string;
  userType :string;


  constructor(private sharedService: SharedService, public dialog: MatDialog, private router: Router, public toastr: ToastrService) {
    this.userName="";
    this.userType="";
    this.loggedUser = this.sharedService.getLoggedUser()
    this.userName= this.loggedUser.first_name.toUpperCase();
    this.userType=this.loggedUser.employee_type.toUpperCase();

  }

  ngOnInit(): void {

  }

  showHospitalList() {
   
  }

  changePassword() {
    // const dialogRef = this.dialog.open(ChangePasswordComponent, {
    //   width: "50vw"
    // });

    // dialogRef.afterClosed().subscribe(sResult => { });
  }

  logout() {
    this.sharedService.logout();
  }

}
