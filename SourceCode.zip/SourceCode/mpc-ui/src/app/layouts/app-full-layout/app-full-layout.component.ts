import { Component, OnInit, ViewEncapsulation, HostListener } from '@angular/core';
import { onMainContentChange } from '../app-side-nav/animations';
// import { LoginService } from '../../modules/login/shared/login.service';
import { SharedService } from '../../modules/shared/services/shared.service';

@Component({
  selector: 'app-full-layout',
  templateUrl: './app-full-layout.component.html',
  styleUrls: ['./app-full-layout.component.scss'],
  animations: [onMainContentChange]
})
export class AppFullLayoutComponent implements OnInit {
  @HostListener('window:beforeunload', ['$event'])
  beforeunload(event: any) {

  }


  loginUser: any;
  isOpen = false;
  constructor(
    // private loginService: LoginService,
    private sharedService: SharedService
  ) {

    this.loginUser = this.sharedService.getLoggedUser();
  }
  ngOnInit(): void {
  }

  isOpenChange($event: boolean) {
    this.isOpen = $event;
    this.setScreenShotBtn();
  }

  openScreenShot() {
    this.isOpen = !this.isOpen;
    this.setScreenShotBtn();
  }

  setScreenShotBtn() {

    setTimeout(() => {

      const element: HTMLElement = document.getElementById('screenShotBtn');
      element.style.zIndex = this.isOpen ? '1000001' : 'unset';
    }, 0);
  }
}
