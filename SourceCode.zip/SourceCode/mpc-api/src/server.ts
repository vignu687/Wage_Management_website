import "app-module-path/register";
import * as dotenv from "dotenv";
import mongoose from 'mongoose';
import databaseConfig from "utils/database";

console.log(process.env.NODE_ENV);

dotenv.config({ path: "./env/" + process.env.NODE_ENV + ".env" });

import app from "./app";

mongoose
    .connect(process.env.API_DB_URL, databaseConfig.mongo.options)
    .then((result) => {
        console.log('DB CONNECTED');
    })
    .catch((error) => {
        console.log(error);
        // logging.error(NAMESPACE, error.message, error);
    });

app.listen(process.env.API_PORT, () => {
    console.log("Express server listening on port " + process.env.API_PORT);
});