import express from "express";
import { securityUtility } from "utils/security";
import { baseRouter } from "routers";

class appClass {

  public app: express.Application;

  constructor() {
    this.app = express();
    this.config();
  }

  private config(): void {

    //suppport application/json
    this.app.use(express.json({ limit: '50mb' }));

    //support application/x-www-form-urlencoded post data
    this.app.use(express.urlencoded({ extended: false, limit: '50mb' }));

    //enabled cors middleware
    this.app.use(securityUtility.cors);

    //enabled authorization token
    this.app.use(securityUtility.validateToken);

    //enabled base router
    this.app.use("/mpc/api/v1", baseRouter);

    this.app.all('*', (req, res) => {
      let error = new Error(`Requested URL ${req.url} not found!`);
      res.status(404).json({
        message: error.message,
        status: false,
        data: [],
        trace: error.stack
      })
    })
  }
}

export default new appClass().app;