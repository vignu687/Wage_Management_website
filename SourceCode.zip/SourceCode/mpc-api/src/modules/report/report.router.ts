import express = require("express");
import { httpUtility } from "utils/http";
import { reportController } from "./controller/report.controller";

export class reportRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {

        this.router.get('/', (req, res, next) => { httpUtility.action(req, res, next, reportController.getReportByDate) });
        this.router.get('/descriptions', (req, res, next) => { httpUtility.action(req, res, next, reportController.getJobDescription) });
     
    }
}

export const reportRouter = new reportRouterClass().router;