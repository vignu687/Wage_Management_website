import { dateFilter } from 'utils/date.filter';

class reportRepositoryClass {

    
}

export const reportRepository = new reportRepositoryClass();