import { roastingRepository } from "modules/roasting/repository/roasting.repository";
import { coolingRepository } from "modules/cooling/repository/cooling.repository";
import { machineCuttingRepository } from "modules/machine-cutting/repository/machine.cutting.repository";
import { ovenHeatingRepository } from "modules/oven-heating/repository/oven.heating.repository";
import { machinePeelingRepository } from "modules/machine-peeling/repository/machine.peeling.repository";
import { sortingMachineRepository } from "modules/sorting-machine/repository/sorting.machine.repository";
import { machineGradingRepository } from "modules/machine-grading/repository/machine.grading.repository";
import { finalOvenRepository } from "modules/final-oven-entry/repository/final.oven.repository";
import { humanCuttingDescriptions } from "master-data/human.cutting.description";
import { humanCuttingRepository } from "modules/human-cutting/repository/human.cutting.repository";
import { humanPeelingDescriptions } from "master-data/human.peeling.description";
import { humanPeelingRepository } from "modules/human-peeling/repository/human.peeling.repository";
import { humanGradingDescriptions } from "master-data/human.grading.description";
import { humanGradingRepository } from "modules/human-grading/repository/human.grading.repository";

class reportHelperClass {

    public getJobDescription(httpStack: any, requestJSON: any) {
        let descriptions = [];

        switch (requestJSON.report.department) {
            case 'human_cutting':
                descriptions = humanCuttingDescriptions;
                break;
            case 'human_peeling':
                descriptions = humanPeelingDescriptions;
                break;
             case 'human_grading':
                descriptions = humanGradingDescriptions;
                break;           
        }
        return descriptions;
    }

    public async getReportByDate(httpStack: any, requestJSON: any): Promise<any> {

        try {
            let report = [];
            switch (requestJSON.report.department) {

                case 'roasting':
                    let roasting = await roastingRepository.getRoastingByDate(requestJSON);
                    report = roasting;
                    break;
                case 'machine_cutting':
                    let machineCutting = await machineCuttingRepository.getMachineCuttingByDate(requestJSON);
                    report = machineCutting;
                    break;
                case 'oven_heating':
                    let ovenHeating = await ovenHeatingRepository.getOvenHeatingByDate(requestJSON);
                    report = ovenHeating;
                    break;
                case 'cooling':
                    let cooling = await coolingRepository.getCoolingByDate(requestJSON);
                    report = cooling;
                    break;
                case 'machine_peeling':
                    let machinePeeling = await machinePeelingRepository.getMachinePeelingByDate(requestJSON);
                    report = machinePeeling;
                    break;
                case 'sorting_machine':
                    let sortingMachine = await sortingMachineRepository.getSortingMachineByDate(requestJSON);
                    report = sortingMachine;
                    break;
                case 'machine_grading':
                    let machineGrading = await machineGradingRepository.getMachineGradingByDate(requestJSON);
                    report = machineGrading;
                    break;
                case 'final_oven_entry':
                    let finalOvenEntry = await finalOvenRepository.getFinalOvenByDate(requestJSON);
                    report = finalOvenEntry;
                    break;
                case 'human_cutting':
                    requestJSON.job_description = requestJSON.report.job_description;
                    let humanCutting = await humanCuttingRepository.getHumanCuttingByDate(requestJSON);
                    humanCutting = reportHelper.groupSumByDescription(humanCutting);
                    report = humanCutting;
                    break;
                case 'human_peeling':
                    requestJSON.job_description = requestJSON.report.job_description;
                    let humanPeeling = await humanPeelingRepository.getHumanPeelingByDate(requestJSON);
                    humanPeeling = reportHelper.groupSumByDescription(humanPeeling);
                    report = humanPeeling;
                    break;
                case 'human_grading':
                    requestJSON.job_description = requestJSON.report.job_description;
                    let humanGrading = await humanGradingRepository.getHumanGradingByDate(requestJSON);
                    humanGrading = reportHelper.groupSumByDescription(humanGrading);
                    report = humanGrading;
                    break;
            }
            return report;
        } catch (eror) {
            throw (eror)
        }
    }


    getTableObject(report) {
        // let tableObject = { key: '', total: 0 };
        let reports: any = {};
        report.forEach((element, i) => {
            reports['key' + '_' + i] = element._id;
            reports['total' + '_' + i] = element.total;
        });

        return reports;
    }
    getReport(report) {
        return report.reduce((acc, cur) => cur.trays.reduce((subAcc, subCur) => (subCur.tray + subAcc), 0) + acc, 0);
    }

    groupSumByDescription(list) {

        let reports = [];

        list.forEach(item => {
            item.value.forEach(value => {
                let index = reports.findIndex(o => o._id == value.label);
                if (index != -1) {
                    reports[index].total += value.value ? parseFloat(value.value) : 0
                } else {
                    let report = { _id: value.label, total: 0 };
                    report.total = parseFloat(value.value);
                    reports.push(report);
                }
            })
        })
        return reports;
    }

}

export const reportHelper = new reportHelperClass();