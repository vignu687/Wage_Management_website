import { httpUtility } from "utils/http";
import { reportHelper } from "./report.helper";


class reportControllerClass {

    public async getReportByDate(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.report = JSON.parse(JSON.stringify(httpStack.req.query));
            let report = await reportHelper.getReportByDate(httpStack, requestJSON);
            httpUtility.sendSuccess(httpStack, report);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getJobDescription(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.report = JSON.parse(JSON.stringify(httpStack.req.query));
            let description = reportHelper.getJobDescription(httpStack, requestJSON);
            httpUtility.sendSuccess(httpStack, description  );

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const reportController = new reportControllerClass();