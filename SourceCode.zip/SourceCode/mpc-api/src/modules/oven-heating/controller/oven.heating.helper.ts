
class ovenHeatingHelperClass {
}

export const ovenHeatingHelper = new ovenHeatingHelperClass();