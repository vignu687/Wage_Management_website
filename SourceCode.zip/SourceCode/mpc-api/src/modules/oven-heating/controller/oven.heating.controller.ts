import { httpUtility } from "utils/http";
import { ovenHeatingRepository } from "../repository/oven.heating.repository";


class ovenHeatingControllerClass {

    public async addOvenHeating(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.ovenHeating = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.ovenHeating.created_by=requestJSON.configSQL.userid;
            requestJSON.ovenHeating.updated_by=requestJSON.configSQL.userid;
            const ovenHeating = await ovenHeatingRepository.addOvenHeating(requestJSON);

            httpUtility.sendSuccess(httpStack, ovenHeating);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async addOvenHeatingMany(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.ovenHeating = JSON.parse(JSON.stringify(httpStack.req.body));
            for (let i in requestJSON.ovenHeating){
                requestJSON.ovenHeating[i].created_by=requestJSON.configSQL.userid;
                requestJSON.ovenHeating[i].updated_by=requestJSON.configSQL.userid;
            }
            const ovenHeating = await ovenHeatingRepository.addOvenHeatingMany(requestJSON);

            httpUtility.sendSuccess(httpStack, ovenHeating);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }



    public async updateOvenHeatingById(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.ovenHeating = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.id = httpStack.req.params.oh_id;
            requestJSON.ovenHeating.updated_by=requestJSON.configSQL.userid;
            const ovenHeating = await ovenHeatingRepository.updateOvenHeatingById(requestJSON);

            httpUtility.sendSuccess(httpStack, ovenHeating);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getOvenHeatingAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.ovenHeating = JSON.parse(JSON.stringify(httpStack.req.query));

            const ovenHeatings = await ovenHeatingRepository.getOvenHeatingAll(requestJSON);

            httpUtility.sendSuccess(httpStack, ovenHeatings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getOvenHeatingById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.oh_id;
            const ovenHeatings = await ovenHeatingRepository.getOvenHeatingById(requestJSON);

            httpUtility.sendSuccess(httpStack, ovenHeatings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async deleteOvenHeatingById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.oh_id;
            const ovenHeatings = await ovenHeatingRepository.deleteOvenHeatingById(requestJSON);

            httpUtility.sendSuccess(httpStack, ovenHeatings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const ovenHeatingController = new ovenHeatingControllerClass();