import express = require("express");
import { httpUtility } from "utils/http";
import { ovenHeatingController } from "./controller/oven.heating.controller";

export class ovenHeatingRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {

        this.router.post('/', (req, res, next) => { httpUtility.action(req, res, next, ovenHeatingController.addOvenHeating) });
        this.router.put('/:oh_id', (req, res, next) => { httpUtility.action(req, res, next, ovenHeatingController.updateOvenHeatingById) });
        this.router.get('/', (req, res, next) => { httpUtility.action(req, res, next, ovenHeatingController.getOvenHeatingAll) });
        this.router.get('/:oh_id', (req, res, next) => { httpUtility.action(req, res, next, ovenHeatingController.getOvenHeatingById) });
        this.router.delete('/:oh_id', (req, res, next) => { httpUtility.action(req, res, next, ovenHeatingController.deleteOvenHeatingById) });

    }
}

export const ovenHeatingRouter = new ovenHeatingRouterClass().router;