import { dateFilter } from 'utils/date.filter';
import OvenHeating from '../../../model/oven.heating.model';

class ovenHeatingRepositoryClass {

    public async addOvenHeating(requestJSON: any): Promise<any> {

        try {
            const ovenHeating = new OvenHeating(requestJSON.ovenHeating)
            return await ovenHeating.save();

        } catch (e) {
            throw new Error(e);
        }

    }

    public async addOvenHeatingMany(requestJSON: any): Promise<any> {

        try {
            OvenHeating.insertMany(requestJSON.ovenHeating);
            requestJSON.ovenHeating = requestJSON.ovenHeating[0];
            return await this.getOvenHeatingAll(requestJSON)
        } catch (e) {
            throw new Error(e);
        }
    }

    public async updateOvenHeatingById(requestJSON: any): Promise<any> {

        try {

            return await OvenHeating.findByIdAndUpdate(requestJSON.id, requestJSON.ovenHeating, { new: true });

        } catch (e) {
            throw new Error(e);
        }

    }

    public async deleteOvenHeatingById(requestJSON: any): Promise<any> {

        try {

            return await OvenHeating.findByIdAndRemove(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getOvenHeatingAll(requestJSON: any): Promise<any> {

        try {
            const conditions = {
                origin_id: requestJSON.ovenHeating.origin_id,
                lot_id: requestJSON.ovenHeating.lot_id,
                entry_date: dateFilter.getDateFilter(requestJSON.ovenHeating.entry_date),
                entry_type: requestJSON.ovenHeating.entry_type,
                status: true
            };
            return await OvenHeating.find(conditions);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getOvenHeatingById(requestJSON: any): Promise<any> {

        try {

            return await OvenHeating.findById(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getOvenHeatingByDate(requestJSON: any): Promise<any> {

        try {

            return await OvenHeating.aggregate([

                {
                    $match: {
                        updated_date: dateFilter.getDateFilter(requestJSON.report.date_start, requestJSON.report.date_end),
                    },
                },
                {
                    $unwind: "$trays"
                },
                {
                    $group: {
                        _id: "$entry_type",
                        total: {
                            $sum: "$trays.tray"
                        },
                        count: { $sum: 1 }
                    }
                },
                {
                    $sort: {
                        _id: 1
                    }
                }
            ]);

        } catch (e) {
            throw new Error(e);
        }

    }

}

export const ovenHeatingRepository = new ovenHeatingRepositoryClass();