import express = require("express");
import { httpUtility } from "utils/http";
import { machinePeelingController } from "./controller/machine.peeling.controller";

export class machinePeelingRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {

        this.router.post('/', (req, res, next) => { httpUtility.action(req, res, next, machinePeelingController.addMachinePeeling) });
        this.router.put('/:mpid', (req, res, next) => { httpUtility.action(req, res, next, machinePeelingController.updateMachinePeelingById) });
        this.router.get('/', (req, res, next) => { httpUtility.action(req, res, next, machinePeelingController.getMachinePeelingAll) });
        this.router.get('/:mpid', (req, res, next) => { httpUtility.action(req, res, next, machinePeelingController.getMachinePeelingById) });
        this.router.delete('/:mpid', (req, res, next) => { httpUtility.action(req, res, next, machinePeelingController.deleteMachinePeelingById) });

    }
}

export const machinePeelingRouter = new machinePeelingRouterClass().router;