import { httpUtility } from "utils/http";
import { machinePeelingRepository } from "../repository/machine.peeling.repository";


class machinePeelingControllerClass {

    public async addMachinePeeling(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.machinePeeling = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.machinePeeling.created_by=requestJSON.configSQL.userid;
            requestJSON.machinePeeling.updated_by=requestJSON.configSQL.userid;
            const machinePeeling = await machinePeelingRepository.addMachinePeeling(requestJSON);

            httpUtility.sendSuccess(httpStack, machinePeeling);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async addMachinePeelingMany(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.machinePeeling = JSON.parse(JSON.stringify(httpStack.req.body));
            for (let i in requestJSON.machinePeeling){
                requestJSON.machinePeeling[i].created_by=requestJSON.configSQL.userid;
                requestJSON.machinePeeling[i].updated_by=requestJSON.configSQL.userid;
            }
            const machinePeeling = await machinePeelingRepository.addMachinePeelingMany(requestJSON);

            httpUtility.sendSuccess(httpStack, machinePeeling);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }



    public async updateMachinePeelingById(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.machinePeeling = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.id = httpStack.req.params.mpid;
            requestJSON.machinePeeling.updated_by=requestJSON.configSQL.userid;
            const machinePeeling = await machinePeelingRepository.updateMachinePeelingById(requestJSON);

            httpUtility.sendSuccess(httpStack, machinePeeling);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getMachinePeelingAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.machinePeeling = JSON.parse(JSON.stringify(httpStack.req.query));

            const machinePeelings = await machinePeelingRepository.getMachinePeelingAll(requestJSON);

            httpUtility.sendSuccess(httpStack, machinePeelings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getMachinePeelingById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.mpid;
            const machinePeelings = await machinePeelingRepository.getMachinePeelingById(requestJSON);

            httpUtility.sendSuccess(httpStack, machinePeelings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async deleteMachinePeelingById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.mpid;
            const machinePeelings = await machinePeelingRepository.deleteMachinePeelingById(requestJSON);

            httpUtility.sendSuccess(httpStack, machinePeelings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const machinePeelingController = new machinePeelingControllerClass();