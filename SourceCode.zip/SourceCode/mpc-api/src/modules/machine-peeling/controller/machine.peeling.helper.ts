
class machinePeelingHelperClass {
}

export const machinePeelingHelper = new machinePeelingHelperClass();