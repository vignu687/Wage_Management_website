import { dateFilter } from 'utils/date.filter';
import MachinePeeling from '../../../model/machine.peeling.model';

class machinePeelingRepositoryClass {

    public addMachinePeeling(requestJSON: any): Promise<any> {

        try {
            const machinePeeling = new MachinePeeling(requestJSON.machinePeeling);
            return machinePeeling.save();

        } catch (e) {
            throw new Error(e);
        }

    }

    public addMachinePeelingMany(requestJSON: any): any {

        try {
            MachinePeeling.insertMany(requestJSON.machinePeeling);
            requestJSON.machinePeeling = requestJSON.machinePeeling[0];
            return this.getMachinePeelingAll(requestJSON)
        } catch (e) {
            throw new Error(e);
        }
    }

    public updateMachinePeelingById(requestJSON: any): any {

        try {

            return MachinePeeling.findByIdAndUpdate(requestJSON.id, requestJSON.machinePeeling, { new: true });

        } catch (e) {
            throw new Error(e);
        }

    }

    public deleteMachinePeelingById(requestJSON: any): any {

        try {

            return MachinePeeling.findByIdAndRemove(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public getMachinePeelingAll(requestJSON: any): any {

        try {
            const conditions = {
                origin_id: requestJSON.machinePeeling.origin_id,
                lot_id: requestJSON.machinePeeling.lot_id,
                entry_date: dateFilter.getDateFilter(requestJSON.machinePeeling.entry_date),
                entry_type: requestJSON.machinePeeling.entry_type,
                machine_name : requestJSON.machinePeeling.machine_name,
                status: true
            };
            return MachinePeeling.find(conditions);

        } catch (e) {
            throw new Error(e);
        }

    }

    public getMachinePeelingById(requestJSON: any): any {

        try {

            return MachinePeeling.findById(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public getMachinePeelingDb(requestJSON: any): any {

        try {


            return MachinePeeling.aggregate([
                {
                    $project:
                    {
                        origin_id: 1,
                        lot_id: 1,
                        entry_date: 1
                    }
                },
                {
                    $match: {
                        origin_id: requestJSON.machinePeeling.origin_id,
                        lot_id: requestJSON.machinePeeling.lot_id,
                        entry_date: dateFilter.getDateFilter(requestJSON.machinePeeling.entry_date)
                    },
                }, {
                    $group: {
                        _id: {
                            origin_id: "$origin_id",
                            lot_id: "$lot_id",
                            entry_date: "$entry_date"
                        },
                        count: { $sum: 1 }
                    }
                }
            ]);

        } catch (e) {
            throw new Error(e);
        }


    }

    public async getMachinePeelingByDate(requestJSON: any): Promise<any> {

        try {

            if (requestJSON.report.entry_type=='In'){
                return await MachinePeeling.aggregate([
                    {
                        $match: {
                            updated_date: dateFilter.getDateFilter(requestJSON.report.date_start, requestJSON.report.date_end),
                            entry_type : 'In'
                        },
                    },
                    {
                        $unwind: "$trays"
                    },
                    {
                        $group: {
                            _id: "$entry_type",
                            total: {
                                $sum: "$trays.tray"
                            },
                            count: { $sum: 1 }
                        }
                    }
                ]);
            } else {
                return await MachinePeeling.aggregate([

                    {
                        $match: {
                            updated_date: dateFilter.getDateFilter(requestJSON.report.date_start, requestJSON.report.date_end),
                            entry_type : 'Out'
                        },
                    },
                     {
                        $group: {
                            _id: "$entry_type",
                            wholes_total : {$sum:"$wholes_weight"},
                            pieces_total : {$sum:"$pieces_weight"},
                            husk_total : {$sum:"$husk_weight"},
                            count: { $sum: 1 }
                        }
                    }
                ]);
            }


        } catch (e) {
            throw new Error(e);
        }

    }
}

export const machinePeelingRepository = new machinePeelingRepositoryClass();