import { dateFilter } from 'utils/date.filter';
import HumanCutting from '../../../model/human.cutting.model';

class humanCuttingRepositoryClass {

    public addHumanCutting(requestJSON: any): Promise<any> {

        try {
            const humanCutting = new HumanCutting(requestJSON.humanCutting)
            return humanCutting.save(requestJSON);

        } catch (e) {
            throw new Error(e);
        }

    }

    public addHumanCuttingMany(requestJSON: any): Promise<any> {

        try {
            HumanCutting.insertMany(requestJSON.humanCutting);
            requestJSON.humanCutting = requestJSON.humanCutting[0];
            return this.getHumanCuttingAll(requestJSON)
        } catch (e) {
            throw new Error(e);
        }
    }

    public async updateHumanCuttingById(requestJSON: any): Promise<any> {

        try {

            return await HumanCutting.findByIdAndUpdate(requestJSON.id, requestJSON.humanCutting, { new: true });

        } catch (e) {
            throw new Error(e);
        }

    }

    public async deleteHumanCuttingById(requestJSON: any): Promise<any> {

        try {

            return await HumanCutting.findByIdAndRemove(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getHumanCuttingAll(requestJSON: any): Promise<any> {

        try {
            const conditions = {
                origin_id: requestJSON.humanCutting.origin_id,
                lot_id: requestJSON.humanCutting.lot_id,
                entry_date: dateFilter.getDateFilter(requestJSON.humanCutting.entry_date),
                employee_id: requestJSON.humanCutting.employee_id,
                // job_description: requestJSON.humanCutting.job_description,
                status: true
            };
            return await HumanCutting.find(conditions);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getHumanCuttingById(requestJSON: any): Promise<any> {

        try {

            return await HumanCutting.findById(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getHumanCuttingDb(requestJSON: any): Promise<any> {

        try {


            return await HumanCutting.aggregate([
                {
                    $project:
                    {
                        origin_id: 1,
                        lot_id: 1,
                        entry_date: 1
                    }
                },
                {
                    $match: {
                        origin_id: requestJSON.humanCutting.origin_id,
                        lot_id: requestJSON.humanCutting.lot_id,
                        entry_date: dateFilter.getDateFilter(requestJSON.humanCutting.entry_date)
                    },
                }, {
                    $group: {
                        _id: {
                            origin_id: "$origin_id",
                            lot_id: "$lot_id",
                            entry_date: "$entry_date"
                        },
                        count: { $sum: 1 }
                    }
                }
            ]);

        } catch (e) {
            throw new Error(e);
        }


    }

    public async getHumanCuttingByDate(requestJSON: any): Promise<any> {

        try {
            return await HumanCutting.aggregate([
                {
                    $match: {
                        updated_date: dateFilter.getDateFilter(requestJSON.report.date_start, requestJSON.report.date_end),
                        job_description: requestJSON.job_description
                    },
                },
                {
                    $sort: {
                        _id: 1
                    }
                }
            ]);

        } catch (e) {
            throw new Error(e);
        }

    }
}

export const humanCuttingRepository = new humanCuttingRepositoryClass();