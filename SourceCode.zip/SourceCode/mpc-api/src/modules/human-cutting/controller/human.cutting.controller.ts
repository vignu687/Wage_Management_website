import { httpUtility } from "utils/http";
import { humanCuttingRepository } from "../repository/human.cutting.repository";
import { humanCuttingDescriptions, humanCuttingQuestions } from "master-data/human.cutting.description";
import { humanCuttingHelper } from './human.cutting.helper';


class humanCuttingControllerClass {

    public async addHumanCutting(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.humanCutting = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.humanCutting = await humanCuttingHelper.getHumanCuttingWage(requestJSON);
            requestJSON.humanCutting.created_by=requestJSON.configSQL.userid;
            requestJSON.humanCutting.updated_by=requestJSON.configSQL.userid;
            const humanCutting = await humanCuttingRepository.addHumanCutting(requestJSON);

            httpUtility.sendSuccess(httpStack, humanCutting);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async addHumanCuttingMany(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.humanCutting = JSON.parse(JSON.stringify(httpStack.req.body));
            for (let i in requestJSON.humanCutting){
                requestJSON.humanCutting[i].created_by=requestJSON.configSQL.userid;
                requestJSON.humanCutting[i].updated_by=requestJSON.configSQL.userid;
            }
            const humanCutting = await humanCuttingRepository.addHumanCuttingMany(requestJSON);

            httpUtility.sendSuccess(httpStack, humanCutting);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async updateHumanCuttingById(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.humanCutting = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.id = httpStack.req.params.hc_id;
            requestJSON.humanCutting = await humanCuttingHelper.getHumanCuttingWage(requestJSON);
            requestJSON.humanCutting.updated_by=requestJSON.configSQL.userid;

            const humanCutting = await humanCuttingRepository.updateHumanCuttingById(requestJSON);
            if (!humanCutting) {
                httpStack.message = "Failed to Save,Please try again.";
                httpUtility.sendSuccess(httpStack, []);
                return;
            }
            httpUtility.sendSuccess(httpStack, humanCutting);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getHumanCuttingAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.humanCutting = JSON.parse(JSON.stringify(httpStack.req.query));

            let humanCuttings = await humanCuttingRepository.getHumanCuttingAll(requestJSON);

            // if (humanCuttings.length == 0) {
            //     let humanCutting: any = {};
            //     humanCutting.origin_id = requestJSON.humanCutting.origin_id;
            //     humanCutting.lot_id = requestJSON.humanCutting.lot_id;
            //     humanCutting.entry_date = requestJSON.humanCutting.entry_date;
            //     humanCutting.employee_id = requestJSON.humanCutting.employee_id;
            //     humanCutting.job_descrption = requestJSON.humanCutting.job_descrption;
            //     humanCutting.value = humanCuttingQuestions[humanCutting.job_descrption];
            //     humanCuttings.push(humanCutting);
            // }
            httpUtility.sendSuccess(httpStack, humanCuttings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getHumanCuttingById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.hc_id;
            const humanCuttings = await humanCuttingRepository.getHumanCuttingById(requestJSON);

            httpUtility.sendSuccess(httpStack, humanCuttings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async deleteHumanCuttingById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.hc_id;
            const humanCuttings = await humanCuttingRepository.deleteHumanCuttingById(requestJSON);

            httpUtility.sendSuccess(httpStack, humanCuttings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public getHumanCuttingDescriptions(httpStack: any, requestJSON: any): any {

        try {

            const descriptions = humanCuttingDescriptions;
            httpUtility.sendSuccess(httpStack, descriptions);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public getHumanCuttingQuestionsByDescription(httpStack: any, requestJSON: any): any {

        try {
            requestJSON.key = httpStack.req.params.key;

            const questions = humanCuttingQuestions[requestJSON.key];
            httpUtility.sendSuccess(httpStack, questions);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const humanCuttingController = new humanCuttingControllerClass();