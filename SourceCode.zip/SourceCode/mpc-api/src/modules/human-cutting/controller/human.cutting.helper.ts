import { settingRepository } from "modules/management/master-setting/repository/setting.repository";
import { employeeRepository } from "modules/management/employee/repository/employee.repository";

class humanCuttingHelperClass {

    public async getHumanCuttingWage(requestJSON: any) {

        try {
            let settings = await settingRepository.getSettingAll(requestJSON);
            settings = settings[0];
            let cutting = JSON.parse(JSON.stringify(requestJSON.humanCutting));
            let employee = await employeeRepository.getEmployeeById(JSON.parse('{"id":"'+cutting.employee_id+'"}'));
            requestJSON.humanCutting.wage={};
            switch (cutting.job_description) {
                case 'fixed_wages':
                    let attendance = cutting.value.find(o => o.key == 'attendance');
                    let work_type = cutting.value.find(o => o.key == 'work_type');
                    let wage_type = cutting.value.find(o => o.key == 'wage_type');

                    if(wage_type.value == 'base_wage'){
                        requestJSON.humanCutting.wage.wage = employee[work_type.value] ? parseFloat(employee[work_type.value]) : 0;
                    } else {
                        requestJSON.humanCutting.wage.wage = settings.fixed_wages[work_type.value] ? parseFloat(settings.fixed_wages[work_type.value]) : 0;
                    }
                    
                    if (attendance.value == 'half_day') {
                        requestJSON.humanCutting.wage.wage = (requestJSON.humanCutting.wage.wage * 0.5);
                    }
                    break;
                case 'uncut':
                    let issue = cutting.value.find(o => o.key == 'issue_weight');
                    let cuttingWeight = cutting.value.filter(o => o.key != 'issue_weight');

                    cuttingWeight.forEach(weight => {
                        weight.rate = humanCuttingHelper.getRate(settings, weight, 'uncut_wage');
                    });

                    requestJSON.humanCutting.wage.wage = humanCuttingHelper.getWage(cuttingWeight).toFixed(2);
                    requestJSON.humanCutting.wage.actual_recieved = cuttingWeight.reduce((acc, wage) => acc + parseFloat(wage.value), 0);
                    requestJSON.humanCutting.wage.return = parseFloat(issue.value) - requestJSON.humanCutting.wage.actual_recieved;
                    break;
                case 'mixed_cut':       
                    let wholesWeight = cutting.value.find(o => o.key == 'wholes_weight');
                    let pieceWeight = cutting.value.find(o => o.key == 'pieces_weight');
                    let mixedCutissue = parseFloat(wholesWeight.value)+parseFloat(pieceWeight.value);

                    let wholesRate = humanCuttingHelper.getMixedUncutRate(settings, wholesWeight, 'mixed_uncut_wage', mixedCutissue, false);
                    let pieceRate = humanCuttingHelper.getMixedUncutRate(settings, pieceWeight, 'mixed_uncut_wage', mixedCutissue, true);
                    requestJSON.humanCutting.wage.issued_weight=mixedCutissue;
                    requestJSON.humanCutting.wage.wage = ((wholesRate * parseFloat(wholesWeight.value)) + (pieceRate * parseFloat(pieceWeight.value))).toFixed(2);
                    break;
            }
            return requestJSON.humanCutting;
        } catch (error) {
            throw (error);
        }

    }


    getRate(settings, weight, desc_type) {
        let rate = 0;
        let condition;
        switch (settings[desc_type][weight.key + '_condition']) {
            case '>=':
                condition = parseFloat(weight.value) >= parseFloat(settings[desc_type][weight.key + '_limit']);
                break;
            case '<=':
                condition = parseFloat(weight.value) <= parseFloat(settings[desc_type][weight.key + '_limit']);
                break;
            case '=':
                condition = parseFloat(weight.value) == parseFloat(settings[desc_type][weight.key + '_limit']);
                break;
            case '>':
                condition = parseFloat(weight.value) > parseFloat(settings[desc_type][weight.key + '_limit']);
                break;
            case '<':
                condition = parseFloat(weight.value) < parseFloat(settings[desc_type][weight.key + '_limit']);
                break;
        }
        rate = condition ? settings[desc_type][weight.key + '_limit_true'] : settings[desc_type][weight.key + '_limit_false'];
        return rate;
    }

    getWage(cutting) {

        return cutting.reduce((acc, weight) => {
            let wage = 0.0;
            if (weight.key.includes('wholes_weight')) {
                let piece = cutting.find(o => o.key == weight.key.replace('wholes_weight', 'pieces_weight'));
                wage = (parseFloat(weight.value) + parseFloat(piece.value)) * (weight.rate + piece.rate);
            }
            return wage + acc;
        }, 0);
    }

    getMixedUncutRate(settings, weight, desc_type, issued, isPiece) {
        let rate = 0;
        let condition;
        let limit;
        if (isPiece) {
            limit = (parseFloat(issued.value) * (parseFloat(settings[desc_type][weight.key + '_limit_percentage']) / 100));
        } else {
            limit = parseFloat(settings[desc_type][weight.key + '_limit']);
        }

        switch (settings[desc_type][weight.key + '_condition']) {
            case '>=':
                condition = parseFloat(weight.value) >= limit;
                break;
            case '<=':
                condition = parseFloat(weight.value) <= limit;
                break;
            case '=':
                condition = parseFloat(weight.value) == limit;
                break;
            case '>':
                condition = parseFloat(weight.value) > limit;
                break;
            case '<':
                condition = parseFloat(weight.value) < limit;
                break;
        }
        rate = condition ? settings[desc_type][weight.key + '_limit_true'] : settings[desc_type][weight.key + '_limit_false'];
        return rate;
    }
}

export const humanCuttingHelper = new humanCuttingHelperClass();