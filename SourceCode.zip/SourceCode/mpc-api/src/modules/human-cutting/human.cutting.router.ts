import express = require("express");
import { httpUtility } from "utils/http";
import { humanCuttingController } from "./controller/human.cutting.controller";

export class humanCuttingRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {

        this.router.post('/', (req, res, next) => { httpUtility.action(req, res, next, humanCuttingController.addHumanCutting) });
        this.router.put('/:hc_id', (req, res, next) => { httpUtility.action(req, res, next, humanCuttingController.updateHumanCuttingById) });
        this.router.get('/descriptions', (req, res, next) => { httpUtility.action(req, res, next, humanCuttingController.getHumanCuttingDescriptions) });
        this.router.get('/', (req, res, next) => { httpUtility.action(req, res, next, humanCuttingController.getHumanCuttingAll) });
        this.router.get('/:hc_id', (req, res, next) => { httpUtility.action(req, res, next, humanCuttingController.getHumanCuttingById) });
        this.router.delete('/:hc_id', (req, res, next) => { httpUtility.action(req, res, next, humanCuttingController.deleteHumanCuttingById) });
        this.router.get('/descriptions/:key/questions', (req, res, next) => { httpUtility.action(req, res, next, humanCuttingController.getHumanCuttingQuestionsByDescription) });
        
    }
}

export const humanCuttingRouter = new humanCuttingRouterClass().router;