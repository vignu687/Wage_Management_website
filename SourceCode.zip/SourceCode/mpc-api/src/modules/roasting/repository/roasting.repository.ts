import { dateFilter } from 'utils/date.filter';
import Roasting from '../../../model/roasting.model';

class roastingRepositoryClass {

    public async addRoasting(requestJSON: any): Promise<any> {

        try {
            const roasting = new Roasting(requestJSON.roasting)
            return await roasting.save();

        } catch (e) {
            throw new Error(e);
        }

    }

    public async addRoastingMany(requestJSON: any): Promise<any> {

        try {
            Roasting.insertMany(requestJSON.roasting);
            requestJSON.roasting = requestJSON.roasting[0];
            return await this.getRoastingAll(requestJSON)
        } catch (e) {
            throw new Error(e);
        }
    }

    public async updateRoastingById(requestJSON: any): Promise<any> {

        try {

            return await Roasting.findByIdAndUpdate(requestJSON.id, requestJSON.roasting, { new: true });

        } catch (e) {
            throw new Error(e);
        }

    }

    public async deleteRoastingById(requestJSON: any): Promise<any> {

        try {

            return await Roasting.findByIdAndRemove(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getRoastingAll(requestJSON: any): Promise<any> {

        try {
            const conditions = {
                origin_id: requestJSON.roasting.origin_id,
                lot_id: requestJSON.roasting.lot_id,
                entry_date: dateFilter.getDateFilter(requestJSON.roasting.entry_date),
                entry_type: requestJSON.roasting.entry_type,
                status: true
            };
            return await Roasting.find(conditions);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getRoastingById(requestJSON: any): Promise<any> {

        try {

            return await Roasting.findById(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getRoastingByDate(requestJSON: any): Promise<any> {

        try {
            const conditions = {
                updated_date: dateFilter.getDateFilter(requestJSON.report.date_start, requestJSON.report.date_end),
                status: true
            };


            return await Roasting.aggregate([

                {
                    $match: {
                        updated_date: dateFilter.getDateFilter(requestJSON.report.date_start, requestJSON.report.date_end),
                    },
                }, 
                {
                    $unwind: "$trays"
                }, 
                {
                    $group: {
                        _id: "$entry_type",
                        total: {
                            $sum: "$trays.tray"
                        },
                        count: { $sum: 1 }
                    }
                },
                {
                    $sort: {
                        _id: 1
                    }
                }
            ]);

        } catch (e) {
            throw new Error(e);
        }

    }

}

export const roastingRepository = new roastingRepositoryClass();