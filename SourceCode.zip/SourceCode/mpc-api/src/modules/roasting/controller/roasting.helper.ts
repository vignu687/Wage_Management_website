
class roastingHelperClass {
}

export const roastingHelper = new roastingHelperClass();