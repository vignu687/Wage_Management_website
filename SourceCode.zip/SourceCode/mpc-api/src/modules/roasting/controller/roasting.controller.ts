import { httpUtility } from "utils/http";
import { roastingRepository } from "../repository/roasting.repository";


class roastingControllerClass {

    public async addRoasting(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.roasting = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.roasting.created_by=requestJSON.configSQL.userid;
            requestJSON.roasting.updated_by=requestJSON.configSQL.userid;
            const roasting = await roastingRepository.addRoasting(requestJSON);

            httpUtility.sendSuccess(httpStack, roasting);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async addRoastingMany(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.roasting = JSON.parse(JSON.stringify(httpStack.req.body));
            for (let i in requestJSON.roasting){
                requestJSON.roasting[i].created_by=requestJSON.configSQL.userid;
                requestJSON.roasting[i].updated_by=requestJSON.configSQL.userid;
            }
            const roasting = await roastingRepository.addRoastingMany(requestJSON);

            httpUtility.sendSuccess(httpStack, roasting);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }



    public async updateRoastingById(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.roasting = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.id = httpStack.req.params.rid;
            requestJSON.roasting.updated_by=requestJSON.configSQL.userid;
            const roasting = await roastingRepository.updateRoastingById(requestJSON);

            httpUtility.sendSuccess(httpStack, roasting);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getRoastingAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.roasting = JSON.parse(JSON.stringify(httpStack.req.query));

            const roastings = await roastingRepository.getRoastingAll(requestJSON);

            httpUtility.sendSuccess(httpStack, roastings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getRoastingById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.rid;
            const roasting = await roastingRepository.getRoastingById(requestJSON);

            httpUtility.sendSuccess(httpStack, roasting);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async deleteRoastingById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.rid;
            const roasting = await roastingRepository.deleteRoastingById(requestJSON);

            httpUtility.sendSuccess(httpStack, roasting);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const roastingController = new roastingControllerClass();