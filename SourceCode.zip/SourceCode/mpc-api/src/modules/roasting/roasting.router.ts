import express = require("express");
import { httpUtility } from "utils/http";
import { roastingController } from "./controller/roasting.controller";

export class roastingRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {

        this.router.post('/', (req, res, next) => { httpUtility.action(req, res, next, roastingController.addRoasting) });
        this.router.put('/:rid', (req, res, next) => { httpUtility.action(req, res, next, roastingController.updateRoastingById) });
        this.router.get('/', (req, res, next) => { httpUtility.action(req, res, next, roastingController.getRoastingAll) });
        this.router.get('/:rid', (req, res, next) => { httpUtility.action(req, res, next, roastingController.getRoastingById) });
        this.router.delete('/:rid', (req, res, next) => { httpUtility.action(req, res, next, roastingController.deleteRoastingById) });

    }
}

export const roastingRouter = new roastingRouterClass().router;