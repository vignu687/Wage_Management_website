import express = require("express");
import { httpUtility } from "utils/http";
import { weightTypeController } from './controller/weight.type.controller';

export class weightTypeRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {
        this.router.post('/',(req, res, next) => { httpUtility.action(req, res, next, weightTypeController.addWeightType)});
        this.router.get('/',(req, res, next) => { httpUtility.action(req, res, next, weightTypeController.getWeightTypeAll)});
        this.router.get('/:weightType_id',(req, res, next) => { httpUtility.action(req, res, next, weightTypeController.getWeightTypeById)});
        this.router.delete('/:weightType_id', (req, res, next) => { httpUtility.action(req, res, next, weightTypeController.deleteWeightTypeById) });
    }
}

export const weightTypeRouter = new weightTypeRouterClass().router;