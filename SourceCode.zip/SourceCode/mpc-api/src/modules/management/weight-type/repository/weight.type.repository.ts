import weightTypeSchema from 'model/weight.type.model';

class weightTypeRepositoryClass {

    public addWeightType(requestJSON: any): any {

        try {
            const weightType = new weightTypeSchema(requestJSON.weightType)
            return weightType.save()

        } catch (e) {
            throw new Error(e);
        }
    }

    public deleteWeightTypeById(requestJSON: any): any {

        try {
            return weightTypeSchema.findByIdAndRemove(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public getWeightTypeById(requestJSON): any {
        try {
            return weightTypeSchema.findById(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }
    }

    public async getWeightTypeAll(requestJSON): Promise<any> {
        try {
            const conditions = {
                department: requestJSON.weightType.department,
                entry_type: requestJSON.weightType.entry_type
            };
            return await weightTypeSchema.find(conditions);

        } catch (e) {
            throw new Error(e);
        }
    }

}

export const weightTypeRepository = new weightTypeRepositoryClass();