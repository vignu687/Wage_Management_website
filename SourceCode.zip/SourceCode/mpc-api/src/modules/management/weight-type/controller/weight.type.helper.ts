class weightTypeHelperClass {
    public async getWeightTypeWithLabel(requestJSON: any) {
        try {
            requestJSON.weightType.type= requestJSON.weightType.label.toLowerCase().split(' ').join('_');
            return requestJSON.weightType;
        }
         catch (error) {
            throw (error);
        }
    }
}

export const weightTypeHelper = new weightTypeHelperClass();