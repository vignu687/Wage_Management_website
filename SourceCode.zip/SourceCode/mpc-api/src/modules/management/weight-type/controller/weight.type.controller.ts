import { httpUtility } from "utils/http";
import { weightTypeRepository } from "../repository/weight.type.repository";
import { weightTypeHelper } from './weight.type.helper';

class weightTypeControllerClass {

    public async addWeightType(httpStack: any, requestJSON: any): Promise<any> {

        requestJSON.weightType = JSON.parse(JSON.stringify(httpStack.req.body));
        requestJSON.weightType.created_by=requestJSON.configSQL.userid;
        requestJSON.weightType.updated_by=requestJSON.configSQL.userid;
        requestJSON.weightType = await weightTypeHelper.getWeightTypeWithLabel(requestJSON);

        try {
            const weightType = await weightTypeRepository.addWeightType(requestJSON);

            httpUtility.sendSuccess(httpStack, weightType);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getWeightTypeAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.weightType = JSON.parse(JSON.stringify(httpStack.req.query));
            const weightTypes = await weightTypeRepository.getWeightTypeAll(requestJSON);

            httpUtility.sendSuccess(httpStack, weightTypes);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getWeightTypeById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.weightType_id;
            const weightTypes = await weightTypeRepository.getWeightTypeById(requestJSON);

            httpUtility.sendSuccess(httpStack, weightTypes);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async deleteWeightTypeById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.weightType_id;
            const weightTypes = await weightTypeRepository.deleteWeightTypeById(requestJSON);

            httpUtility.sendSuccess(httpStack, weightTypes);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const weightTypeController = new weightTypeControllerClass();