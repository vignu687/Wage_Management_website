class userHelperClass {
}

export const userHelper = new userHelperClass();