import { userRepository } from "../repository/user.repository";
import { httpUtility } from './../../../../utils/http';
import bcryptjs from 'bcryptjs';
import { securityUtility } from "utils/security";

class userControllerClass {

    public async performLogin(httpStack: any, requestJSON: any): Promise<any> {

        try {

            let { username, password } = httpStack.req.body;
            requestJSON.user = { username: username };

            let users = await userRepository.loginUser(requestJSON);

            if (users.length == 0) {
                httpStack.statusCode = 401;
                httpStack.message = 'Password is incorrect';
                throw ([]);
            }
            let user = JSON.parse(JSON.stringify(users[0]));

            let result = await bcryptjs.compare(password, user.password);

            delete user.password;

            if (result) {

                user.token = securityUtility.generateToken(user);
                httpUtility.sendSuccess(httpStack, user);

            } else {
                httpStack.statusCode = 401;
                httpStack.message = 'Password is incorrect';
                httpUtility.sendError(httpStack, []);
            }

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getPermission(httpStack: any, requestJSON: any): Promise<any> {

        try {

            requestJSON.user = JSON.parse(JSON.stringify(httpStack.req.query));
            let user = await userRepository.getUser(requestJSON);
            user = user[0];
            // user.password;
            httpUtility.sendSuccess(httpStack, user);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const userController = new userControllerClass();