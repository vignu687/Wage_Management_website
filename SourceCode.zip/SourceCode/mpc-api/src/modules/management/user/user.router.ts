import express = require("express");
import { httpUtility } from "utils/http";
import { userController } from "./controller/user.controller";

export class userRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {

        this.router.post('/login',(req, res, next) => { httpUtility.action(req, res, next, userController.performLogin)});
        this.router.get('/permission',(req, res, next) => { httpUtility.action(req, res, next, userController.getPermission)});

    }
}

export const userRouter = new userRouterClass().router;