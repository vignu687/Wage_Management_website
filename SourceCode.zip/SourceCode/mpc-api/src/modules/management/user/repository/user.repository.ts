import Employee from '../../../../model/employee.model';

class userRepositoryClass {

    public loginUser(requestJSON): any {

        try {

            return Employee.find(requestJSON.user).select("username first_name middle_name last_name employee_type password pages");

        } catch (e) {
            throw new Error(e);
        }

    }

    public getUser(requestJSON): any {

        try {

            return Employee.find(requestJSON.user).select("username first_name middle_name last_name employee_type pages");

        } catch (e) {
            throw new Error(e);
        }

    }

}

export const userRepository = new userRepositoryClass();