import express = require("express");
import { httpUtility } from "utils/http";
import { employeeLoanController } from "./controller/employee.loan.controller";

export class employeeLoanRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {
    
        this.router.post('/',(req, res, next) => { httpUtility.action(req, res, next, employeeLoanController.updateEmployeeLoanBalance)});
        this.router.get('/',(req, res, next) => { httpUtility.action(req, res, next, employeeLoanController.getLoanTransactionsAll)});
        this.router.get('/all',(req, res, next) => { httpUtility.action(req, res, next, employeeLoanController.getEmployeeLoanAll)});
        this.router.delete('/:id', (req, res, next) => { httpUtility.action(req, res, next, employeeLoanController.deleteLoanTransactionsById) });

    }
}

export const employeeLoanRouter = new employeeLoanRouterClass().router;