import { employeeLoanRepository } from '../repository/employee.loan.repository'
import { httpUtility } from '../../../../utils/http';

class employeeLoanControllerClass {

    public async updateEmployeeLoanBalance(httpStack: any, requestJSON: any): Promise<any> {

        requestJSON.loanTransaction = JSON.parse(JSON.stringify(httpStack.req.body));
        requestJSON.loanTransaction.created_by=requestJSON.configSQL.userid;
        requestJSON.loanTransaction.updated_by=requestJSON.configSQL.userid;

        try {

            let employeeLoanBalance = await employeeLoanRepository.getEmployeeLoanbyId(requestJSON);

            let loanBalance = employeeLoanBalance.loan_balance;
            
            if(requestJSON.loanTransaction.event_type=='Loan Amount Issued'){
                loanBalance = loanBalance + parseFloat(requestJSON.loanTransaction.amount);
            } else if (requestJSON.loanTransaction.event_type=='Loan Amount Collected'){
                loanBalance = loanBalance - parseFloat(requestJSON.loanTransaction.amount);
            }

            requestJSON.loanTransaction.loan_balance = loanBalance;
            
            const employee = await employeeLoanRepository.updateLoanAmountOnEmployeeById(requestJSON);

            employeeLoanRepository.addLoanTransaction(requestJSON);

            httpUtility.sendSuccess(httpStack, employee);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getEmployeeLoanAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            const employeeLoans = await employeeLoanRepository.getEmployeeLoanAll(requestJSON);

            httpUtility.sendSuccess(httpStack, employeeLoans);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getLoanTransactionsAll(httpStack: any, requestJSON: any): Promise<any> {

        try {

            requestJSON.loanTransaction = JSON.parse(JSON.stringify(httpStack.req.query));
            const employeeLoanTransactions = await employeeLoanRepository.getLoanTransactionsAll(requestJSON);
            httpUtility.sendSuccess(httpStack, employeeLoanTransactions);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async deleteLoanTransactionsById(httpStack: any, requestJSON: any): Promise<any> {

        try {

            requestJSON.loanTransaction = {};

            requestJSON.loanTransaction.id = httpStack.req.params.id;

            let loanTransaction = await employeeLoanRepository.getLoanTransactionById(requestJSON);

            requestJSON.loanTransaction.employee_id=loanTransaction.employee_id;

            requestJSON.loanTransaction.amount = loanTransaction.amount;

            requestJSON.loanTransaction.event_type = loanTransaction.event_type;

            let employeeLoanBalance = await employeeLoanRepository.getEmployeeLoanbyId(requestJSON);

            let loanBalance = employeeLoanBalance.loan_balance;
            
            if(requestJSON.loanTransaction.event_type=='Loan Amount Issued'){
                loanBalance = loanBalance - parseFloat(requestJSON.loanTransaction.amount);
            } else if (requestJSON.loanTransaction.event_type=='Loan Amount Collected'){
                loanBalance = loanBalance + parseFloat(requestJSON.loanTransaction.amount);
            }

            requestJSON.loanTransaction.loan_balance = loanBalance;
            
            const employee = await employeeLoanRepository.updateLoanAmountOnEmployeeById(requestJSON);

            await employeeLoanRepository.deleteLoanTransactionById(requestJSON);

            httpUtility.sendSuccess(httpStack, employee);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const employeeLoanController = new employeeLoanControllerClass();