import LoanTransaction from 'model/loan.transaction.model';
import EmployeeSchema from 'model/employee.model';

class employeeLoanRepositoryClass {

    public addLoanTransaction(requestJSON: any): any {

        try {
            const loanTransaction = new LoanTransaction(requestJSON.loanTransaction)
            return loanTransaction.save()

        } catch (e) {
            throw new Error(e);
        }
    }

    public updateLoanAmountOnEmployeeById(requestJSON: any): any{

        try {

            return EmployeeSchema.updateOne({_id: requestJSON.loanTransaction.employee_id},{$set: {loan_balance: requestJSON.loanTransaction.loan_balance}})

        } catch (e){
            throw new Error(e);
        }

    }

    
    public getEmployeeLoanAll(requestJSON: any): any {

        try {

            const conditions = {
                loan_balance : {$gt : 0},
                employee_type : {$in : ['operator','worker']}               
            };

            return EmployeeSchema.find(conditions).select('username first_name middle_name last_name loan_balance');

        } catch (e) {
            throw new Error(e);
        }

    }

    public getEmployeeLoanbyId(requestJSON: any): any {
        
        try {
            return EmployeeSchema.findById(requestJSON.loanTransaction.employee_id).select('loan_balance');
        } catch (e) {
            throw new Error(e);
        }
    }

    public getLoanTransactionById(requestJSON: any): any {
        try {
            return LoanTransaction.findById(requestJSON.loanTransaction.id);

        } catch (e) {
            throw new Error(e);
        }
    }

    public deleteLoanTransactionById(requestJSON: any): any {

        try {
            return LoanTransaction.findByIdAndRemove(requestJSON.loanTransaction.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getLoanTransactionsAll(requestJSON : any): Promise<any> {
        try {
            const conditions = {
                employee_id: requestJSON.loanTransaction.employee_id
            };
            return await LoanTransaction.find(conditions);

        } catch (e) {
            throw new Error(e);
        }
    }

}

export const employeeLoanRepository = new employeeLoanRepositoryClass();