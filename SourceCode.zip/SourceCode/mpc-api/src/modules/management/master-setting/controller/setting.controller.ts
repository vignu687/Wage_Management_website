import { httpUtility } from "utils/http";
import { settingRepository } from "../repository/setting.repository";


class settingControllerClass {

    public async addSetting(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.setting = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.setting.created_by=requestJSON.configSQL.userid;
            requestJSON.setting.updated_by=requestJSON.configSQL.userid;
            const setting = await settingRepository.addSetting(requestJSON);

            httpUtility.sendSuccess(httpStack, setting);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async addSettingMany(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.setting = JSON.parse(JSON.stringify(httpStack.req.body));
            for (let i in requestJSON.setting){
                requestJSON.setting[i].created_by=requestJSON.configSQL.userid;
                requestJSON.setting[i].updated_by=requestJSON.configSQL.userid;
            }
            const setting = await settingRepository.addSettingMany(requestJSON);

            httpUtility.sendSuccess(httpStack, setting);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }



    public async updateSettingById(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.setting = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.id = httpStack.req.params.sid;
            requestJSON.setting.updated_by=requestJSON.configSQL.userid;
            const setting = await settingRepository.updateSettingById(requestJSON);

            httpUtility.sendSuccess(httpStack, setting);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getSettingAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.setting = JSON.parse(JSON.stringify(httpStack.req.query));

            const settings = await settingRepository.getSettingAll(requestJSON);

            httpUtility.sendSuccess(httpStack, settings[0]);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getSettingById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.sid;
            const settings = await settingRepository.getSettingById(requestJSON);

            httpUtility.sendSuccess(httpStack, settings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    
    public async getPayrollSettings(httpStack: any, requestJSON: any): Promise<any> {

        try {
            const settings = await settingRepository.getPayrollSettings();
            httpUtility.sendSuccess(httpStack, settings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async deleteSettingById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.sid;
            const settings = await settingRepository.deleteSettingById(requestJSON);

            httpUtility.sendSuccess(httpStack, settings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const settingController = new settingControllerClass();