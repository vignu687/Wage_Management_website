
class settingHelperClass {
}

export const settingHelper = new settingHelperClass();