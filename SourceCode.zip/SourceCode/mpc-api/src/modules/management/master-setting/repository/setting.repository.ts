import { dateFilter } from 'utils/date.filter';
import Setting from '../../../../model/master.setting.model';

class settingRepositoryClass {

    public async addSetting(requestJSON: any): Promise<any> {

        try {
            const setting = new Setting(requestJSON.setting)
            return await setting.save();

        } catch (e) {
            throw new Error(e);
        }

    }

    public async addSettingMany(requestJSON: any): Promise<any> {

        try {
            Setting.insertMany(requestJSON.setting);
            requestJSON.setting = requestJSON.setting[0];
            return await this.getSettingAll(requestJSON)
        } catch (e) {
            throw new Error(e);
        }
    }

    public async updateSettingById(requestJSON: any): Promise<any> {

        try {

            return await Setting.findByIdAndUpdate(requestJSON.id, requestJSON.setting, { new: true });

        } catch (e) {
            throw new Error(e);
        }

    }

    public async deleteSettingById(requestJSON: any): Promise<any> {

        try {

            return await Setting.findByIdAndRemove(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getSettingAll(requestJSON: any): Promise<any> {

        try {
            const conditions = {
                // origin_id: requestJSON.setting.origin_id,
                // lot_id: requestJSON.setting.lot_id,
                // entry_date: dateFilter.getDateFilter(requestJSON.setting.entry_date),
                // entry_type: requestJSON.setting.entry_type,
                // status: true
            };
            return await Setting.find(conditions);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getSettingById(requestJSON: any): Promise<any> {

        try {

            return await Setting.findById(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getPayrollSettings(): Promise<any> {

        try {
            return await Setting.find({},{_id:0,payroll:1});

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getSettingDb(requestJSON: any): Promise<any> {

        try {


            return Setting.aggregate([
                {
                    $project:
                    {
                        origin_id: 1,
                        lot_id: 1,
                        entry_date: 1
                    }
                },
                {
                    $match: {
                        origin_id: requestJSON.setting.origin_id,
                        lot_id: requestJSON.setting.lot_id,
                        entry_date: dateFilter.getDateFilter(requestJSON.setting.entry_date)
                    },
                }, {
                    $group: {
                        _id: {
                            origin_id: "$origin_id",
                            lot_id: "$lot_id",
                            entry_date: "$entry_date"
                        },
                        count: { $sum: 1 }
                    }
                }
            ]);

        } catch (e) {
            throw new Error(e);
        }


    }
}

export const settingRepository = new settingRepositoryClass();