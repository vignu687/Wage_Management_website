import express = require("express");
import { httpUtility } from "utils/http";
import { settingController } from "./controller/setting.controller";

export class settingRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {

        this.router.post('/', (req, res, next) => { httpUtility.action(req, res, next, settingController.addSetting) });
        this.router.put('/:sid', (req, res, next) => { httpUtility.action(req, res, next, settingController.updateSettingById) });
        this.router.get('/', (req, res, next) => { httpUtility.action(req, res, next, settingController.getSettingAll) });
        this.router.get('/:sid', (req, res, next) => { httpUtility.action(req, res, next, settingController.getSettingById) });
        this.router.get('/section/payroll', (req, res, next) => { httpUtility.action(req, res, next, settingController.getPayrollSettings) });
        this.router.delete('/:sid', (req, res, next) => { httpUtility.action(req, res, next, settingController.deleteSettingById) });

    }
}

export const settingRouter = new settingRouterClass().router;