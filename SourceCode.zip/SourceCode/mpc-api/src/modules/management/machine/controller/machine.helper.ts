class machineHelperClass {
}

export const machineHelper = new machineHelperClass();