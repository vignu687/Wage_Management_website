import { httpUtility } from "utils/http";
import { machineRepository } from "../repository/machine.repository";

class machineControllerClass {

    public async addMachine(httpStack: any, requestJSON: any): Promise<any> {

        requestJSON.machine = JSON.parse(JSON.stringify(httpStack.req.body));
        requestJSON.machine.created_by=requestJSON.configSQL.userid;
        requestJSON.machine.updated_by=requestJSON.configSQL.userid;

        try {
            const machine = await machineRepository.addMachine(requestJSON);

            httpUtility.sendSuccess(httpStack, machine);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getMachineAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.machine = JSON.parse(JSON.stringify(httpStack.req.query));
            const machines = await machineRepository.getMachineAll(requestJSON);

            httpUtility.sendSuccess(httpStack, machines);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getAllMachineByType(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.type = httpStack.req.params.type;
            const machines = await machineRepository.getAllMachineByType(requestJSON);

            httpUtility.sendSuccess(httpStack, machines);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getMachineById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.mid;
            const machines = await machineRepository.getMachineById(requestJSON);

            httpUtility.sendSuccess(httpStack, machines);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async deleteMachineById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.mid;
            const grades = await machineRepository.deleteMachineById(requestJSON);

            httpUtility.sendSuccess(httpStack, grades);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const machineController = new machineControllerClass();