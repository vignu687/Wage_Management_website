import Machine from 'model/machine.model';

class machineRepositoryClass {

    public addMachine(requestJSON: any): any {

        try {
            const machine = new Machine(requestJSON.machine)
            return machine.save()

        } catch (e) {
            throw new Error(e);
        }
    }

    public deleteMachineById(requestJSON: any): any {

        try {
            return Machine.findByIdAndRemove(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public getMachineById(requestJSON): any {
        try {
            return Machine.findById(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }
    }

    public async getMachineAll(requestJSON): Promise<any> {
        try {
            return await Machine.find();

        } catch (e) {
            throw new Error(e);
        }
    }

    public async getAllMachineByType(requestJSON): Promise<any> {
        try {
            const conditions = {
                type: requestJSON.type,
                status: true
            };
            return await Machine.find(conditions);

        } catch (e) {
            throw new Error(e);
        }
    }

}

export const machineRepository = new machineRepositoryClass();