import express = require("express");
import { httpUtility } from "utils/http";
import { machineController } from './controller/machine.controller';

export class machineRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {
        this.router.post('/',(req, res, next) => { httpUtility.action(req, res, next, machineController.addMachine)});
        this.router.get('/',(req, res, next) => { httpUtility.action(req, res, next, machineController.getMachineAll)});
        this.router.get('/:mid',(req, res, next) => { httpUtility.action(req, res, next, machineController.getMachineById)});
        this.router.delete('/:mid', (req, res, next) => { httpUtility.action(req, res, next, machineController.deleteMachineById) });
        this.router.get('/type/:type',(req, res, next) => { httpUtility.action(req, res, next, machineController.getAllMachineByType)});
    }
}

export const machineRouter = new machineRouterClass().router;