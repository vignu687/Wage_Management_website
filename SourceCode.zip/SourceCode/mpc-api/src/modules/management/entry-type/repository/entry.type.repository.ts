import entryTypeSchema from 'model/entry.type.model';

class entryTypeRepositoryClass {

    public addEntryType(requestJSON: any): any {

        try {
            const entryType = new entryTypeSchema(requestJSON.entryType)
            return entryType.save()

        } catch (e) {
            throw new Error(e);
        }
    }

    public deleteEntryTypeById(requestJSON: any): any {

        try {
            return entryTypeSchema.findByIdAndRemove(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public getEntryTypeById(requestJSON): any {
        try {
            return entryTypeSchema.findById(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }
    }

    public async getEntryTypeAll(requestJSON): Promise<any> {
        try {
            return await entryTypeSchema.find();

        } catch (e) {
            throw new Error(e);
        }
    }

}

export const entryTypeRepository = new entryTypeRepositoryClass();