import express = require("express");
import { httpUtility } from "utils/http";
import { entryTypeController } from './controller/entry.type.controller';

export class entryTypeRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {
        this.router.post('/',(req, res, next) => { httpUtility.action(req, res, next, entryTypeController.addEntryType)});
        this.router.get('/',(req, res, next) => { httpUtility.action(req, res, next, entryTypeController.getEntryTypeAll)});
        this.router.get('/:entryType_id',(req, res, next) => { httpUtility.action(req, res, next, entryTypeController.getEntryTypeById)});
        this.router.delete('/:entryType_id', (req, res, next) => { httpUtility.action(req, res, next, entryTypeController.deleteEntryTypeById) });
    }
}

export const entryTypeRouter = new entryTypeRouterClass().router;