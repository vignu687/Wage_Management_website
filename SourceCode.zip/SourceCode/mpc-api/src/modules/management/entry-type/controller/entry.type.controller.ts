import { httpUtility } from "utils/http";
import { entryTypeRepository } from "../repository/entry.type.repository";
import { entryTypeHelper } from './entry.type.helper';

class entryTypeControllerClass {

    public async addEntryType(httpStack: any, requestJSON: any): Promise<any> {

        requestJSON.entryType = JSON.parse(JSON.stringify(httpStack.req.body));
        requestJSON.entryType.created_by=requestJSON.configSQL.userid;
        requestJSON.entryType.updated_by=requestJSON.configSQL.userid;
        requestJSON.entryType = await entryTypeHelper.getEntryTypeWithLabel(requestJSON);

        try {
            const entryType = await entryTypeRepository.addEntryType(requestJSON);

            httpUtility.sendSuccess(httpStack, entryType);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getEntryTypeAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.entryType = JSON.parse(JSON.stringify(httpStack.req.query));
            const entryTypes = await entryTypeRepository.getEntryTypeAll(requestJSON);

            httpUtility.sendSuccess(httpStack, entryTypes);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getEntryTypeById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.entryType_id;
            const entryTypes = await entryTypeRepository.getEntryTypeById(requestJSON);

            httpUtility.sendSuccess(httpStack, entryTypes);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async deleteEntryTypeById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.entryType_id;
            const entryTypes = await entryTypeRepository.deleteEntryTypeById(requestJSON);

            httpUtility.sendSuccess(httpStack, entryTypes);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const entryTypeController = new entryTypeControllerClass();