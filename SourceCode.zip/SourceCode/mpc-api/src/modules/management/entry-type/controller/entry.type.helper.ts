class entryTypeHelperClass {
    public async getEntryTypeWithLabel(requestJSON: any) {
        try {
            requestJSON.entryType.type= requestJSON.entryType.label.toLowerCase().split(' ').join('_');
            return requestJSON.entryType;
        }
         catch (error) {
            throw (error);
        }
    }
}

export const entryTypeHelper = new entryTypeHelperClass();