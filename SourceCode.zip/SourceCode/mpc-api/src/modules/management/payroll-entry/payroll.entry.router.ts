import express = require("express");
import { httpUtility } from "utils/http";
import { payrollEntryController } from "./controller/payroll.entry.controller";

export class payrollEntryRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {
    
        this.router.post('/',(req, res, next) => { httpUtility.action(req, res, next, payrollEntryController.addPayrollEntry)});
        this.router.put('/:pe_id',(req, res, next) => { httpUtility.action(req, res, next, payrollEntryController.updatePayrollEntryById)});
        this.router.get('/', (req, res, next) => { httpUtility.action(req, res, next, payrollEntryController.getPayrollEntryAll) });
        this.router.get('/:pe_id', (req, res, next) => { httpUtility.action(req, res, next, payrollEntryController.getPayrollEntryById) });
        this.router.delete('/:pe_id', (req, res, next) => { httpUtility.action(req, res, next, payrollEntryController.deletePayrollEntryById) });

    }
}

export const payrollEntryRouter = new payrollEntryRouterClass().router;