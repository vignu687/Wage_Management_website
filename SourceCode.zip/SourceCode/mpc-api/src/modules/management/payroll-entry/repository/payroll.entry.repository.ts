import { dateFilter } from 'utils/date.filter';
import PayrollEntry from '../../../../model/payroll.entry.model';


class payrollEntryRepositoryClass {

    public async addPayrollEntry(requestJSON: any): Promise<any> {

        try {
            const payrollEntry = new PayrollEntry(requestJSON.payrollEntry)
            return await payrollEntry.save();

        } catch (e) {
            throw new Error(e);
        }

    }

    public async updatePayrollEntryById(requestJSON: any): Promise<any> {

        try {
            return await PayrollEntry.findByIdAndUpdate(requestJSON.id, requestJSON.payrollEntry, { new: true });

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getPayrollEntryAll(requestJSON: any): Promise<any> {

        try {
            const conditions = {
                entry_date: dateFilter.getDateFilter(requestJSON.payrollEntry.entry_date),
                entry_type: requestJSON.payrollEntry.entry_type,
                entry_category: requestJSON.payrollEntry.entry_category,
                status: true
            };
            return await PayrollEntry.find(conditions);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getPayrollEntryById(requestJSON: any): Promise<any> {

        try {

            return await PayrollEntry.findById(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async deletePayrollEntryById(requestJSON: any): Promise<any> {

        try {

            return await PayrollEntry.findByIdAndRemove(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

}

export const payrollEntryRepository = new payrollEntryRepositoryClass();