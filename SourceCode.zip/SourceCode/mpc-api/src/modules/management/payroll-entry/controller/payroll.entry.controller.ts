import { payrollEntryRepository } from '../repository/payroll.entry.repository';
import { httpUtility } from '../../../../utils/http';

class payrollEntryControllerClass {

    public async addPayrollEntry(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.payrollEntry = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.payrollEntry.created_by = requestJSON.configSQL.userid;
            requestJSON.payrollEntry.updated_by = requestJSON.configSQL.userid;
            const roasting = await payrollEntryRepository.addPayrollEntry(requestJSON);

            httpUtility.sendSuccess(httpStack, roasting);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }

    }


    public async updatePayrollEntryById(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.payrollEntry = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.id = httpStack.req.params.pe_id;
            requestJSON.payrollEntry.updated_by = requestJSON.configSQL.userid;
            const payrollEntry = await payrollEntryRepository.updatePayrollEntryById(requestJSON);

            httpUtility.sendSuccess(httpStack, payrollEntry);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getPayrollEntryAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.payrollEntry = JSON.parse(JSON.stringify(httpStack.req.query));

            const payrollEntries = await payrollEntryRepository.getPayrollEntryAll(requestJSON);

            httpUtility.sendSuccess(httpStack, payrollEntries);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getPayrollEntryById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.pe_id;
            const ovenHeatings = await payrollEntryRepository.getPayrollEntryById(requestJSON);

            httpUtility.sendSuccess(httpStack, ovenHeatings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }


    public async deletePayrollEntryById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.pe_id;
            const ovenHeatings = await payrollEntryRepository.deletePayrollEntryById(requestJSON);

            httpUtility.sendSuccess(httpStack, ovenHeatings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }


}

export const payrollEntryController = new payrollEntryControllerClass();