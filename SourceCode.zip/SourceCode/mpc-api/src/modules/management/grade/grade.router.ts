import express = require("express");
import { httpUtility } from "utils/http";
import { gradeController } from './controller/grade.controller';

export class gradeRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {
        this.router.post('/',(req, res, next) => { httpUtility.action(req, res, next, gradeController.addGrade)});
        this.router.get('/',(req, res, next) => { httpUtility.action(req, res, next, gradeController.getGradeAll)});
        this.router.get('/:grade_id',(req, res, next) => { httpUtility.action(req, res, next, gradeController.getGradeById)});
        this.router.delete('/:grade_id', (req, res, next) => { httpUtility.action(req, res, next, gradeController.deleteGradingById) });
    }
}

export const gradeRouter = new gradeRouterClass().router;