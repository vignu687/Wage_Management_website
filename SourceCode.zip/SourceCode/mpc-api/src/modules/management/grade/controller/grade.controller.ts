import { httpUtility } from "utils/http";
import { gradeRepository } from "../repository/grade.repository";

class gradeControllerClass {

    public async addGrade(httpStack: any, requestJSON: any): Promise<any> {

        requestJSON.grade = JSON.parse(JSON.stringify(httpStack.req.body));
        requestJSON.grade.created_by=requestJSON.configSQL.userid;
        requestJSON.grade.updated_by=requestJSON.configSQL.userid;

        try {
            const grade = await gradeRepository.addGrade(requestJSON);

            httpUtility.sendSuccess(httpStack, grade);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getGradeAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.grade = JSON.parse(JSON.stringify(httpStack.req.query));
            const grades = await gradeRepository.getGradeAll(requestJSON);

            httpUtility.sendSuccess(httpStack, grades);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getGradeById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.grade_id;
            const grades = await gradeRepository.getGradeById(requestJSON);

            httpUtility.sendSuccess(httpStack, grades);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async deleteGradingById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.grade_id;
            const grades = await gradeRepository.deleteGradeById(requestJSON);

            httpUtility.sendSuccess(httpStack, grades);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const gradeController = new gradeControllerClass();