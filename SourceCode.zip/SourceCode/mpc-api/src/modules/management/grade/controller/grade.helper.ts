class gradeHelperClass {
}

export const gradeHelper = new gradeHelperClass();