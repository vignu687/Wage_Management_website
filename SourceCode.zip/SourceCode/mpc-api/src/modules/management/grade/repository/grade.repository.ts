import Grade from 'model/grade.model';

class gradeRepositoryClass {

    public addGrade(requestJSON: any): any {

        try {
            const grade = new Grade(requestJSON.grade)
            return grade.save()

        } catch (e) {
            throw new Error(e);
        }
    }

    public deleteGradeById(requestJSON: any): any {

        try {
            return Grade.findByIdAndRemove(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public getGradeById(requestJSON): any {
        try {
            return Grade.findById(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }
    }

    public async getGradeAll(requestJSON): Promise<any> {
        try {
            return await Grade.find();

        } catch (e) {
            throw new Error(e);
        }
    }

}

export const gradeRepository = new gradeRepositoryClass();