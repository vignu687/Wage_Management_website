import { httpUtility } from "utils/http";
import { lotRepository } from "../repository/lot.repository";
import { lotHelper } from "./lot.helper";
import { dateFilter } from './../../../../utils/date.filter';

class lotControllerClass {

    public async addLot(httpStack: any, requestJSON: any): Promise<any> {

        requestJSON.lot = JSON.parse(JSON.stringify(httpStack.req.body));
        requestJSON.lot.created_by=requestJSON.configSQL.userid;
        requestJSON.lot.updated_by=requestJSON.configSQL.userid;

        try {
            const lot = await lotRepository.addLot(requestJSON);

            httpUtility.sendSuccess(httpStack, lot);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async addLotMany(httpStack: any, requestJSON: any): Promise<any> {

        requestJSON.lot = JSON.parse(JSON.stringify(httpStack.req.body));
        requestJSON.lot.created_by=requestJSON.configSQL.userid;
        requestJSON.lot.updated_by=requestJSON.configSQL.userid;

        try {

            requestJSON.conditions = { created_date: dateFilter.getDateFilter(requestJSON.lot.date) };
            requestJSON.options = { sort: { 'created_date': -1 } };
            const lastLot = await lotRepository.getLotOne(requestJSON);
            requestJSON.lot.lastLot = lastLot ? lastLot.name : null;
            lotHelper.getLotNumbers(requestJSON);

            const lot = await lotRepository.addLotMany(requestJSON);

            httpUtility.sendSuccess(httpStack, lot);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async updateLotById(httpStack: any, requestJSON: any): Promise<any> {

        requestJSON.lot = JSON.parse(JSON.stringify(httpStack.req.body));
        requestJSON.id = httpStack.req.params.id;
        requestJSON.lot.updated_by=requestJSON.configSQL.userid;

        try {
            const lot = await lotRepository.updateLotById(requestJSON);

            httpUtility.sendSuccess(httpStack, lot);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getLotAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.origin_id = httpStack.req.params.origin_id;
            const lots = await lotRepository.getLotAll(requestJSON);

            httpUtility.sendSuccess(httpStack, lots);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getLotById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.lot_id;
            const lots = await lotRepository.getLotById(requestJSON);

            httpUtility.sendSuccess(httpStack, lots);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const lotController = new lotControllerClass();