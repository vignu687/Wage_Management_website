class lotHelperClass {

    getLotNumbers(requestJSON): any {

        let lastIndex: any = 0;
        if (requestJSON.lot.lastLot) {
            lastIndex = requestJSON.lot.lastLot.split('_');
            lastIndex = parseInt(lastIndex[lastIndex.length - 1]);
        }

        const date = requestJSON.lot.date.replace(/-/gi, '_');
        const originName = requestJSON.lot.origin_name.slice(0, 3);

        requestJSON.lot_array = Array(requestJSON.lot.count).fill(0)
            .map((o, i) => {
                const lot = {
                    name: (originName + '_' + date + '_' + 'LOT' + '_' + (lastIndex + i + 1)),
                    origin_id: requestJSON.lot.origin_id
                }
                return lot;
            });

    }
}

export const lotHelper = new lotHelperClass();