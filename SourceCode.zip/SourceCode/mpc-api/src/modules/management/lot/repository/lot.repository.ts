import Lot from '../../../../model/lot.model';
import { dateFilter } from './../../../../utils/date.filter';


class lotRepositoryClass {

    public addLot(requestJSON: any): any {

        try {
            const lot = new Lot(requestJSON.lot)
            return lot.save()

        } catch (e) {
            throw new Error(e);
        }
    }

    public addLotMany(requestJSON: any): any {

        try {
            const lot = new Lot(requestJSON.lot)
            return Lot.insertMany(requestJSON.lot_array);

        } catch (e) {
            throw new Error(e);
        }
    }

    public updateLotById(requestJSON: any): any {

        try {

            return Lot.findByIdAndUpdate(requestJSON.id, requestJSON.lot, { new: true });

        } catch (e) {
            throw new Error(e);
        }

    }

    public deleteLotById(requestJSON: any): any {

        try {

            return Lot.findByIdAndRemove(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public getLotById(requestJSON): any {
        try {
            return Lot.findById(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }
    }

    public getLotAll(requestJSON): any {
        try {
            const toDate = new Date();
            let fromDate = new Date();
            fromDate.setDate(fromDate.getDate() - 30);
            //const conditions = { origin_id: requestJSON.origin_id, updated_date: dateFilter.getDateFilter(fromDate, toDate), status: true };
            const conditions = { origin_id: requestJSON.origin_id };
            return Lot.find(conditions);

        } catch (e) {
            throw new Error(e);
        }
    }

    public getLotOne(requestJSON): any {
        try {

            const conditions = requestJSON.conditions ? requestJSON.conditions : {};
            const options = requestJSON.options ? requestJSON.options : {};
            return Lot.findOne(conditions, {}, options);

        } catch (e) {
            throw new Error(e);
        }
    }


}

export const lotRepository = new lotRepositoryClass();