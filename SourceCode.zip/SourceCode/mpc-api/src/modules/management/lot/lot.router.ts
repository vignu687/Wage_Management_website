import express = require("express");
import { httpUtility } from "utils/http";
import { lotController } from "./controller/lot.controller";

export class lotRouterClass {

    public router: express.Router = express.Router({ mergeParams: true });

    constructor() {
        this.config();
    }

    private config(): void {
        this.router.get('/:lot_id',(req, res, next) => { httpUtility.action(req, res, next, lotController.getLotById)});
        this.router.post('/',(req, res, next) => { httpUtility.action(req, res, next, lotController.addLotMany)});
        this.router.put('/:lot_id',(req, res, next) => { httpUtility.action(req, res, next, lotController.updateLotById)});
        this.router.get('/',(req, res, next) => { httpUtility.action(req, res, next, lotController.getLotAll)});
    }
}

export const lotRouter = new lotRouterClass().router;