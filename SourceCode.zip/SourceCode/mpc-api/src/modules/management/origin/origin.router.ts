import express = require("express");
import { httpUtility } from "utils/http";
import { originController } from './controller/origin.controller';

export class originRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {
        this.router.post('/',(req, res, next) => { httpUtility.action(req, res, next, originController.addOrigin)});
        this.router.put('/:origin_id',(req, res, next) => { httpUtility.action(req, res, next, originController.updateOriginById)});
        this.router.get('/',(req, res, next) => { httpUtility.action(req, res, next, originController.getOriginAll)});
        this.router.get('/:origin_id',(req, res, next) => { httpUtility.action(req, res, next, originController.getOriginById)});
    }
}

export const originRouter = new originRouterClass().router;