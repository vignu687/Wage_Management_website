import Origin from 'model/origin.model';

class originRepositoryClass {

    public addOrigin(requestJSON: any): any {

        try {
            const origin = new Origin(requestJSON.origin)
            return origin.save()

        } catch (e) {
            throw new Error(e);
        }
    }

    public updateOriginById(requestJSON: any): any {

        try {

            return Origin.findByIdAndUpdate(requestJSON.id, requestJSON.origin, {new: true});

        } catch (e) {
            throw new Error(e);
        }

    }

    public deleteOriginById(requestJSON: any): any {

        try {

            return Origin.findByIdAndRemove(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }
    
    public getOriginById(requestJSON):any{
        try {
            return Origin.findById(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }
    }

    public async getOriginAll(requestJSON):Promise<any>{
        try {
            return await Origin.find();

        } catch (e) {
            throw new Error(e);
        }
    }

}

export const originRepository = new originRepositoryClass();