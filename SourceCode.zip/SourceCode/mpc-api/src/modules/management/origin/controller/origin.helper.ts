class originHelperClass {
}

export const originHelper = new originHelperClass();