import { httpUtility } from "utils/http";
import { originRepository } from "../repository/origin.repository";

class originControllerClass {

    public async addOrigin(httpStack: any, requestJSON: any): Promise<any> {

        requestJSON.origin = JSON.parse(JSON.stringify(httpStack.req.body));
        requestJSON.origin.created_by=requestJSON.configSQL.userid;
        requestJSON.origin.updated_by=requestJSON.configSQL.userid;

        try {
            const origin = await originRepository.addOrigin(requestJSON);

            httpUtility.sendSuccess(httpStack, origin);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async updateOriginById(httpStack: any, requestJSON: any): Promise<any> {

        requestJSON.origin = JSON.parse(JSON.stringify(httpStack.req.body));
        requestJSON.id = httpStack.req.params.origin_id;
        requestJSON.origin.updated_by=requestJSON.configSQL.userid;
        
        try {
            const origin = await originRepository.updateOriginById(requestJSON);

            httpUtility.sendSuccess(httpStack, origin);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getOriginAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.origin = JSON.parse(JSON.stringify(httpStack.req.query));
            const origins = await originRepository.getOriginAll(requestJSON);

            httpUtility.sendSuccess(httpStack, origins);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getOriginById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.origin_id;
            const origins = await originRepository.getOriginById(requestJSON);

            httpUtility.sendSuccess(httpStack, origins);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const originController = new originControllerClass();