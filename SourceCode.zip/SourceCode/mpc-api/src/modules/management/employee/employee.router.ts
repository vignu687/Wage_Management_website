import express = require("express");
import { httpUtility } from "utils/http";
import { employeeController } from "./controller/employee.controller";

export class employeeRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {
        
        this.router.post('/',(req, res, next) => { httpUtility.action(req, res, next, employeeController.addEmployee)});
        this.router.put('/:id',(req, res, next) => { httpUtility.action(req, res, next, employeeController.updateEmployeeById)});
        this.router.get('/',(req, res, next) => { httpUtility.action(req, res, next, employeeController.getEmployeeAll)});
        this.router.get('/:eid',(req, res, next) => { httpUtility.action(req, res, next, employeeController.getEmployeeById)});
        this.router.get('/wage-employees/all',(req, res, next) => { httpUtility.action(req, res, next, employeeController.getWageEmployeesAll)});

    }
}

export const employeeRouter = new employeeRouterClass().router;