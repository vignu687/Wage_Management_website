import { employeeRepository } from "../repository/employee.repository";
import { httpUtility } from './../../../../utils/http';
import { employeesHelper } from './employee.helper';

class employeeControllerClass {

    public async addEmployee(httpStack: any, requestJSON: any): Promise<any> {

        requestJSON.employee = JSON.parse(JSON.stringify(httpStack.req.body));
        requestJSON.employee.created_by=requestJSON.configSQL.userid;
        requestJSON.employee.updated_by=requestJSON.configSQL.userid;

        if(requestJSON.employee.password){
            requestJSON.employee = await employeesHelper.getEncryptedPassword(requestJSON);
        }

        try {
            const employee = await employeeRepository.addEmployee(requestJSON);

            httpUtility.sendSuccess(httpStack, employee);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async updateEmployeeById(httpStack: any, requestJSON: any): Promise<any> {

        requestJSON.employee = JSON.parse(JSON.stringify(httpStack.req.body));
        requestJSON.employee.updated_by=requestJSON.configSQL.userid;
        if(requestJSON.employee.password){
        requestJSON.employee = await employeesHelper.getEncryptedPassword(requestJSON);
        }

        requestJSON.id = httpStack.req.params.id;

        try {
            const employee = await employeeRepository.updateEmployeeById(requestJSON);

            httpUtility.sendSuccess(httpStack, employee);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getEmployeeAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            const employees = await employeeRepository.getEmployeeAll(requestJSON);

            httpUtility.sendSuccess(httpStack, employees);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getWageEmployeesAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            const employees = await employeeRepository.getWageEmployeesAll(requestJSON);

            httpUtility.sendSuccess(httpStack, employees);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getEmployeeById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id=httpStack.req.params.eid;
            const employees = await employeeRepository.getEmployeeById(requestJSON);

            httpUtility.sendSuccess(httpStack, employees);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const employeeController = new employeeControllerClass();