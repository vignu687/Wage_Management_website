import bcryptjs from 'bcryptjs';

class employeeHelperClass {
    public async getEncryptedPassword(requestJSON: any) {

        try{

            requestJSON.employee.password= await bcryptjs.hash(requestJSON.employee.password, 10);
            return requestJSON.employee;  

        } catch (error){

            throw error;
            
        }
    }
}

export const employeesHelper = new employeeHelperClass();