import Employee from '../../../../model/employee.model';

class employeeRepositoryClass {

    public addEmployee(requestJSON: any): any {

        try {
            const employee = new Employee(requestJSON.employee)
            return employee.save();

        } catch (e) {
            throw new Error(e);
        }

    }

    public updateEmployeeById(requestJSON: any): any {

        try {

            return Employee.findByIdAndUpdate(requestJSON.id, requestJSON.employee, { new: true });

        } catch (e) {
            throw new Error(e);
        }

    }

    public deleteEmployeeById(requestJSON: any): any {

        try {

            return Employee.findByIdAndRemove(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public getEmployeeAll(requestJSON: any): any {

        try {

            return Employee.find().select('username first_name middle_name last_name gender employee_type loan_balance');

        } catch (e) {
            throw new Error(e);
        }

    }

    public getWageEmployeesAll(requestJSON: any): any {

        try {

            const conditions = {
                $or: [{'employee_type': 'operator'},{'employee_type': 'worker'}]
            };

            return Employee.find(conditions).select('username first_name middle_name last_name');

        } catch (e) {
            throw new Error(e);
        }

    }

    public getEmployeeById(requestJSON: any): any {

        try {

            return Employee.findById(requestJSON.id).select("-password");

        } catch (e) {
            throw new Error(e);
        }

    }

}

export const employeeRepository = new employeeRepositoryClass();