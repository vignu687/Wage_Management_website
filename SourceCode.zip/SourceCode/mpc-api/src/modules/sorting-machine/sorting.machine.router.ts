import express = require("express");
import { httpUtility } from "utils/http";
import { sortingMachineController } from "./controller/sorting.machine.controller";

export class sortingMachineRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {

        this.router.post('/', (req, res, next) => { httpUtility.action(req, res, next, sortingMachineController.addSortingMachine) });
        this.router.put('/:mm_id', (req, res, next) => { httpUtility.action(req, res, next, sortingMachineController.updateSortingMachineById) });
        this.router.get('/', (req, res, next) => { httpUtility.action(req, res, next, sortingMachineController.getSortingMachineAll) });
        this.router.get('/:mm_id', (req, res, next) => { httpUtility.action(req, res, next, sortingMachineController.getSortingMachineById) });
        this.router.delete('/:mm_id', (req, res, next) => { httpUtility.action(req, res, next, sortingMachineController.deleteSortingMachineById) });

    }
}

export const sortingMachineRouter = new sortingMachineRouterClass().router;