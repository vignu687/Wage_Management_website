import { dateFilter } from 'utils/date.filter';
import SortingMachine from '../../../model/sorting.machine.model';

class sortingMachineRepositoryClass {

    public async addSortingMachine(requestJSON: any): Promise<any> {

        try {
            const sortingMachine = new SortingMachine(requestJSON.sortingMachine);
            return await sortingMachine.save();

        } catch (e) {
            throw new Error(e);
        }

    }

    public async addSortingMachineMany(requestJSON: any): Promise<any> {

        try {
            SortingMachine.insertMany(requestJSON.sortingMachine);
            requestJSON.sortingMachine = requestJSON.sortingMachine[0];
            return await this.getSortingMachineAll(requestJSON)
        } catch (e) {
            throw new Error(e);
        }
    }

    public async updateSortingMachineById(requestJSON: any): Promise<any> {

        try {

            return await SortingMachine.findByIdAndUpdate(requestJSON.id, requestJSON.sortingMachine, { new: true });

        } catch (e) {
            throw new Error(e);
        }

    }

    public async deleteSortingMachineById(requestJSON: any): Promise<any> {

        try {

            return await SortingMachine.findByIdAndRemove(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getSortingMachineAll(requestJSON: any): Promise<any> {

        try {
            const conditions = {
                origin_id: requestJSON.sortingMachine.origin_id,
                lot_id: requestJSON.sortingMachine.lot_id,
                entry_date: dateFilter.getDateFilter(requestJSON.sortingMachine.entry_date),
                entry_type: requestJSON.sortingMachine.entry_type,
                machine_name : requestJSON.sortingMachine.machine_name,
                status: true
            };
            return await SortingMachine.find(conditions);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getSortingMachineById(requestJSON: any): Promise<any> {

        try {

            return await SortingMachine.findById(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getSortingMachineByDate(requestJSON: any): Promise<any> {

        try {

            if (requestJSON.report.entry_type=='In'){
                return await SortingMachine.aggregate([
                    {
                        $match: {
                            updated_date: dateFilter.getDateFilter(requestJSON.report.date_start, requestJSON.report.date_end),
                            entry_type : 'In'
                        },
                    }, {
                        $unwind: "$trays"
                    }, {
                        $group: {
                            _id: "$weight_type",
                            total: {
                                $sum: "$trays.tray"
                            },
                            count: { $sum: 1 }
                        }
                    }
                ]);
            } else {
                return await SortingMachine.aggregate([

                    {
                        $match: {
                            updated_date: dateFilter.getDateFilter(requestJSON.report.date_start, requestJSON.report.date_end),
                            entry_type : 'Out'
                        },
                    },
                    {
                        $unwind: "$weight_trays"
                    },
                     {
                        $group: {
                            _id: "$weight_trays.weight_type",
                            total: {
                                $sum: "$weight_trays.weight"
                            },
                            count: { $sum: 1 }
                        }
                    }
                ]);
            }


        } catch (e) {
            throw new Error(e);
        }

    }

}

export const sortingMachineRepository = new sortingMachineRepositoryClass();