
class sortingMachineHelperClass {
}

export const sortingMachineHelper = new sortingMachineHelperClass();