import { httpUtility } from "utils/http";
import { sortingMachineRepository } from "../repository/sorting.machine.repository";


class sortingMachineControllerClass {

    public async addSortingMachine(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.sortingMachine = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.sortingMachine.created_by=requestJSON.configSQL.userid;
            requestJSON.sortingMachine.updated_by=requestJSON.configSQL.userid;
            const sortingMachine = await sortingMachineRepository.addSortingMachine(requestJSON);

            httpUtility.sendSuccess(httpStack, sortingMachine);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async addSortingMachineMany(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.sortingMachine = JSON.parse(JSON.stringify(httpStack.req.body));
            for (let i in requestJSON.sortingMachine){
                requestJSON.sortingMachine[i].created_by=requestJSON.configSQL.userid;
                requestJSON.sortingMachine[i].updated_by=requestJSON.configSQL.userid;
            }
            const sortingMachine = await sortingMachineRepository.addSortingMachineMany(requestJSON);

            httpUtility.sendSuccess(httpStack, sortingMachine);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }



    public async updateSortingMachineById(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.sortingMachine = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.id = httpStack.req.params.mm_id;
            requestJSON.sortingMachine.updated_by=requestJSON.configSQL.userid;
            const sortingMachine = await sortingMachineRepository.updateSortingMachineById(requestJSON);

            httpUtility.sendSuccess(httpStack, sortingMachine);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getSortingMachineAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.sortingMachine = JSON.parse(JSON.stringify(httpStack.req.query));

            const sortingMachines = await sortingMachineRepository.getSortingMachineAll(requestJSON);

            httpUtility.sendSuccess(httpStack, sortingMachines);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getSortingMachineById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.mm_id;
            const sortingMachines = await sortingMachineRepository.getSortingMachineById(requestJSON);

            httpUtility.sendSuccess(httpStack, sortingMachines);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async deleteSortingMachineById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.mm_id;
            const sortingMachines = await sortingMachineRepository.deleteSortingMachineById(requestJSON);

            httpUtility.sendSuccess(httpStack, sortingMachines);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const sortingMachineController = new sortingMachineControllerClass();