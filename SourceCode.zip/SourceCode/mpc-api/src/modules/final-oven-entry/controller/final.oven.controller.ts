import { httpUtility } from "utils/http";
import { finalOvenRepository } from "../repository/final.oven.repository";


class finalOvenControllerClass {

    public async addFinalOven(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.finalOven = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.finalOven.created_by=requestJSON.configSQL.userid;
            requestJSON.finalOven.updated_by=requestJSON.configSQL.userid;
            const finalOven = await finalOvenRepository.addFinalOven(requestJSON);

            httpUtility.sendSuccess(httpStack, finalOven);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async addFinalOvenMany(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.finalOven = JSON.parse(JSON.stringify(httpStack.req.body));
            for (let i in requestJSON.finalOven){
                requestJSON.finalOven[i].created_by=requestJSON.configSQL.userid;
                requestJSON.finalOven[i].updated_by=requestJSON.configSQL.userid;
            }
            const finalOven = await finalOvenRepository.addFinalOvenMany(requestJSON);

            httpUtility.sendSuccess(httpStack, finalOven);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }



    public async updateFinalOvenById(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.finalOven = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.id = httpStack.req.params.fo_id;
            requestJSON.finalOven.updated_by=requestJSON.configSQL.userid;
            const finalOven = await finalOvenRepository.updateFinalOvenById(requestJSON);

            httpUtility.sendSuccess(httpStack, finalOven);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getFinalOvenAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.finalOven = JSON.parse(JSON.stringify(httpStack.req.query));

            const finalOvens = await finalOvenRepository.getFinalOvenAll(requestJSON);

            httpUtility.sendSuccess(httpStack, finalOvens);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getFinalOvenById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.fo_id;
            const finalOvens = await finalOvenRepository.getFinalOvenById(requestJSON);

            httpUtility.sendSuccess(httpStack, finalOvens);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async deleteFinalOvenById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.fo_id;
            const finalOvens = await finalOvenRepository.deleteFinalOvenById(requestJSON);

            httpUtility.sendSuccess(httpStack, finalOvens);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const finalOvenController = new finalOvenControllerClass();