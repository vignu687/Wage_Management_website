
class finalOvenHelperClass {
}

export const finalOvenHelper = new finalOvenHelperClass();