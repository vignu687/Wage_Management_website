import { dateFilter } from 'utils/date.filter';
import FinalOven from '../../../model/final.oven.model';

class finalOvenRepositoryClass {

    public async addFinalOven(requestJSON: any): Promise<any> {

        try {
            const finalOven = new FinalOven(requestJSON.finalOven)
            return await finalOven.save();

        } catch (e) {
            throw new Error(e);
        }

    }

    public async addFinalOvenMany(requestJSON: any): Promise<any> {

        try {
            FinalOven.insertMany(requestJSON.finalOven);
            requestJSON.finalOven = requestJSON.finalOven[0];
            return await this.getFinalOvenAll(requestJSON)
        } catch (e) {
            throw new Error(e);
        }
    }

    public async updateFinalOvenById(requestJSON: any): Promise<any> {

        try {

            return await FinalOven.findByIdAndUpdate(requestJSON.id, requestJSON.finalOven, { new: true });

        } catch (e) {
            throw new Error(e);
        }

    }

    public async deleteFinalOvenById(requestJSON: any): Promise<any> {

        try {

            return await FinalOven.findByIdAndRemove(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getFinalOvenAll(requestJSON: any): Promise<any> {

        try {
            const conditions = {
                origin_id: requestJSON.finalOven.origin_id,
                lot_id: requestJSON.finalOven.lot_id,
                entry_date: dateFilter.getDateFilter(requestJSON.finalOven.entry_date),
                entry_type: requestJSON.finalOven.entry_type,
                status: true
            };
            return await FinalOven.find(conditions);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getFinalOvenById(requestJSON: any): Promise<any> {

        try {

            return await FinalOven.findById(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getFinalOvenDb(requestJSON: any): Promise<any> {

        try {


            return await FinalOven.aggregate([
                {
                    $project:
                    {
                        origin_id: 1,
                        lot_id: 1,
                        entry_date: 1
                    }
                },
                {
                    $match: {
                        origin_id: requestJSON.finalOven.origin_id,
                        lot_id: requestJSON.finalOven.lot_id,
                        entry_date: dateFilter.getDateFilter(requestJSON.finalOven.entry_date)
                    },
                }, {
                    $group: {
                        _id: {
                            origin_id: "$origin_id",
                            lot_id: "$lot_id",
                            entry_date: "$entry_date"
                        },
                        count: { $sum: 1 }
                    }
                }
            ]);

        } catch (e) {
            throw new Error(e);
        }


    }

    public async getFinalOvenByDate(requestJSON: any): Promise<any> {

        try {
                return await FinalOven.aggregate([
                    {
                        $match: {
                            updated_date: dateFilter.getDateFilter(requestJSON.report.date_start, requestJSON.report.date_end),
                        },
                    },
                    {
                        $unwind: "$trays"
                    },
                    {
                        $group: {
                            _id: "$trays.grade",
                            total: {
                                $sum: "$trays.weight"
                            },
                            count: { $sum: 1 }
                        }
                    },
                    {
                        $sort: {
                            _id: 1
                        }
                    }
                ]);

        } catch (e) {
            throw new Error(e);
        }

    }
}

export const finalOvenRepository = new finalOvenRepositoryClass();