import express = require("express");
import { httpUtility } from "utils/http";
import { finalOvenController } from "./controller/final.oven.controller";

export class finalOvenRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {

        this.router.post('/', (req, res, next) => { httpUtility.action(req, res, next, finalOvenController.addFinalOven) });
        this.router.put('/:fo_id', (req, res, next) => { httpUtility.action(req, res, next, finalOvenController.updateFinalOvenById) });
        this.router.get('/', (req, res, next) => { httpUtility.action(req, res, next, finalOvenController.getFinalOvenAll) });
        this.router.get('/:fo_id', (req, res, next) => { httpUtility.action(req, res, next, finalOvenController.getFinalOvenById) });
        this.router.delete('/:fo_id', (req, res, next) => { httpUtility.action(req, res, next, finalOvenController.deleteFinalOvenById) });

    }
}

export const finalOvenRouter = new finalOvenRouterClass().router;