import { dateFilter } from 'utils/date.filter';
import MachineGrading from '../../../model/machine.grading.model';

class machineGradingRepositoryClass {

    public async addMachineGrading(requestJSON: any): Promise<any> {

        try {
            const machineGrading = new MachineGrading(requestJSON.machineGrading)
            return await machineGrading.save();

        } catch (e) {
            throw new Error(e);
        }

    }

    public async addMachineGradingMany(requestJSON: any): Promise<any> {

        try {
            MachineGrading.insertMany(requestJSON.machineGrading);
            requestJSON.machineGrading = requestJSON.machineGrading[0];
            return await this.getMachineGradingAll(requestJSON)
        } catch (e) {
            throw new Error(e);
        }
    }

    public async updateMachineGradingById(requestJSON: any): Promise<any> {

        try {

            return await MachineGrading.findByIdAndUpdate(requestJSON.id, requestJSON.machineGrading, { new: true });

        } catch (e) {
            throw new Error(e);
        }

    }

    public async deleteMachineGradingById(requestJSON: any): Promise<any> {

        try {

            return await MachineGrading.findByIdAndRemove(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getMachineGradingAll(requestJSON: any): Promise<any> {

        try {
            const conditions = {
                origin_id: requestJSON.machineGrading.origin_id,
                lot_id: requestJSON.machineGrading.lot_id,
                entry_date: dateFilter.getDateFilter(requestJSON.machineGrading.entry_date),
                entry_type: requestJSON.machineGrading.entry_type,
                machine_name : requestJSON.machineGrading.machine_name,
                status: true
            };
            return await MachineGrading.find(conditions);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getMachineGradingById(requestJSON: any): Promise<any> {

        try {

            return await MachineGrading.findById(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getMachineGradingDb(requestJSON: any): Promise<any> {

        try {


            return await MachineGrading.aggregate([
                {
                    $project:
                    {
                        origin_id: 1,
                        lot_id: 1,
                        entry_date: 1
                    }
                },
                {
                    $match: {
                        origin_id: requestJSON.machineGrading.origin_id,
                        lot_id: requestJSON.machineGrading.lot_id,
                        entry_date: dateFilter.getDateFilter(requestJSON.machineGrading.entry_date)
                    },
                }, {
                    $group: {
                        _id: {
                            origin_id: "$origin_id",
                            lot_id: "$lot_id",
                            entry_date: "$entry_date"
                        },
                        count: { $sum: 1 }
                    }
                }
            ]);

        } catch (e) {
            throw new Error(e);
        }


    }

    public async getMachineGradingByDate(requestJSON: any): Promise<any> {

        try {
                return await MachineGrading.aggregate([
                    {
                        $match: {
                            updated_date: dateFilter.getDateFilter(requestJSON.report.date_start, requestJSON.report.date_end),
                        },
                    },
                    {
                        $unwind: "$trays"
                    },
                    {
                        $group: {
                            _id: "$trays.grade",
                            total: {
                                $sum: "$trays.weight"
                            },
                            count: { $sum: 1 }
                        }
                    },
                    {
                        $sort: {
                            _id: 1
                        }
                    }
                ]);

        } catch (e) {
            throw new Error(e);
        }

    }
}

export const machineGradingRepository = new machineGradingRepositoryClass();