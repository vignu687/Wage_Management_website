import express = require("express");
import { httpUtility } from "utils/http";
import { machineGradingController } from "./controller/machine.grading.controller";

class machineGradingRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {

        this.router.post('/', (req, res, next) => { httpUtility.action(req, res, next, machineGradingController.addMachineGrading) });
        this.router.put('/:cid', (req, res, next) => { httpUtility.action(req, res, next, machineGradingController.updateMachineGradingById) });
        this.router.get('/', (req, res, next) => { httpUtility.action(req, res, next, machineGradingController.getMachineGradingAll) });
        this.router.get('/:cid', (req, res, next) => { httpUtility.action(req, res, next, machineGradingController.getMachineGradingById) });
        this.router.delete('/:cid', (req, res, next) => { httpUtility.action(req, res, next, machineGradingController.deleteMachineGradingById) });

    }
}

export const machineGradingRouter = new machineGradingRouterClass().router;