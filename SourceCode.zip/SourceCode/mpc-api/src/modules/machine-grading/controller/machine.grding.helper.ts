
class machineGradingHelperClass {
}

export const machineGradingHelper = new machineGradingHelperClass();