import { httpUtility } from "utils/http";
import { machineGradingRepository } from "../repository/machine.grading.repository";


class machineGradingControllerClass {

    public async addMachineGrading(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.machineGrading = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.machineGrading.created_by=requestJSON.configSQL.userid;
            requestJSON.machineGrading.updated_by=requestJSON.configSQL.userid;
            const machineGrading = await machineGradingRepository.addMachineGrading(requestJSON);

            httpUtility.sendSuccess(httpStack, machineGrading);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async addMachineGradingMany(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.machineGrading = JSON.parse(JSON.stringify(httpStack.req.body));
            for (let i in requestJSON.machineGrading){
                requestJSON.machineGrading[i].created_by=requestJSON.configSQL.userid;
                requestJSON.machineGrading[i].updated_by=requestJSON.configSQL.userid;
            }
            const machineGrading = await machineGradingRepository.addMachineGradingMany(requestJSON);

            httpUtility.sendSuccess(httpStack, machineGrading);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }



    public async updateMachineGradingById(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.machineGrading = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.id = httpStack.req.params.cid;
            requestJSON.machineGrading.updated_by=requestJSON.configSQL.userid;
            const machineGrading = await machineGradingRepository.updateMachineGradingById(requestJSON);

            httpUtility.sendSuccess(httpStack, machineGrading);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getMachineGradingAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.machineGrading = JSON.parse(JSON.stringify(httpStack.req.query));

            const machineGradings = await machineGradingRepository.getMachineGradingAll(requestJSON);

            httpUtility.sendSuccess(httpStack, machineGradings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getMachineGradingById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.cid;
            const machineGradings = await machineGradingRepository.getMachineGradingById(requestJSON);

            httpUtility.sendSuccess(httpStack, machineGradings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async deleteMachineGradingById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.cid;
            const machineGradings = await machineGradingRepository.deleteMachineGradingById(requestJSON);

            httpUtility.sendSuccess(httpStack, machineGradings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const machineGradingController = new machineGradingControllerClass();