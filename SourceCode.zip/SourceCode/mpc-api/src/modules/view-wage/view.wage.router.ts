import express = require("express");
import { httpUtility } from "utils/http";
import { viewWageController } from "./controller/view.wage.controller";

class viewWageRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {

        this.router.get('/', (req, res, next) => { httpUtility.action(req, res, next, viewWageController.getViewWageAll) });
    }
}

export const viewWageRouter = new viewWageRouterClass().router;