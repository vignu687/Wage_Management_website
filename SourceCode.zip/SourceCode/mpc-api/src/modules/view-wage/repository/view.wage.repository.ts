import { dateFilter } from 'utils/date.filter';
import HumanCutting from '../../../model/human.cutting.model';
import HumanPeeling from '../../../model/human.peeling.model';
import HumanGrading from '../../../model/human.grading.model';

const mongoose = require("mongoose");

class viewWageRepositoryClass {

    public async getViewWageAll(requestJSON: any): Promise<any> {

        try {

            const conditions = {
                // origin_id: requestJSON.viewWage.origin_id,
                // lot_id: requestJSON.viewWage.lot_id,
                // employee_id: requestJSON.viewWage.employee_id,
                entry_date: dateFilter.getDateFilter(requestJSON.viewWage.entry_date_start, requestJSON.viewWage.entry_date_end),
                status: true
            };

            let viewWage = await HumanCutting.aggregate(
                [
                    {
                        '$match': {
                            'entry_date': conditions.entry_date,
                            'status': conditions.status
                        }
                    }, {
                        '$unionWith': {
                            'coll': 'humangradings',
                            'pipeline': [
                                {
                                    '$match': {
                                        'entry_date': conditions.entry_date,
                                        'status': conditions.status
                                    }
                                }
                            ]
                        }
                    }, {
                        '$unionWith': {
                            'coll': 'humanpeelings',
                            'pipeline': [
                                {
                                    '$match': {
                                        'entry_date': conditions.entry_date,
                                        'status': conditions.status
                                    }
                                }
                            ]
                        }
                    }, {
                        '$group': {
                            '_id': '$employee_id',
                            'total_wage': {
                                '$sum': {
                                    '$toDouble': '$wage.wage'
                                }
                            }
                        }
                    }, {
                        '$lookup': {
                            'from': 'employees',
                            'localField': '_id',
                            'foreignField': '_id',
                            'as': 'employee'
                        }
                    }, {
                        '$unwind': {
                            'path': '$employee'
                        }
                    }, {
                        '$project': {
                            '_id': 1,
                            'total_wage': 1,
                            'employee.first_name': 1,
                            'employee.last_name': 1,
                            'employee.email': 1,
                            'employee.employee_type': 1,
                            'employee.username': 1
                        }
                    },{
                        '$sort': {
                            'employee.username':1
                        }
                    }
                ]
            )

            return viewWage;

        } catch (e) {
            throw new Error(e);
        }

    }


    public async getViewWageByEMployee(requestJSON) {
        try {

            const conditions = {
                // origin_id: requestJSON.viewWage.origin_id,
                // lot_id: requestJSON.viewWage.lot_id,
                employee_id: requestJSON.viewWage.employee_id,
                entry_date: dateFilter.getDateFilter(requestJSON.viewWage.entry_date_start, requestJSON.viewWage.entry_date_end),
                status: true
            };

            let agg = [
                {
                    '$match': {
                        'entry_date': conditions.entry_date,
                        'employee_id': new mongoose.Types.ObjectId(conditions.employee_id.toString()),
                        'status': conditions.status
                    }
                }, {
                    '$group': {
                        '_id': '$entry_date',
                        'total_wage': {
                            '$sum': {
                                '$toDouble': '$wage.wage'
                            }
                        },
                        'employee_id': {
                            '$first': '$employee_id'
                        },
                        'entry_date': {
                            '$first': '$entry_date'
                        }
                    }
                }, {
                    '$sort': {
                        '_id.entry_date': -1
                    }
                }
            ]

            let cuttingWage = await HumanCutting.aggregate(agg);
            let gradingWage = await HumanGrading.aggregate(agg);
            let peelingWage = await HumanPeeling.aggregate(agg);

            let viewwageArray = [];
            this.getWage(cuttingWage, viewwageArray, 'human_cutting');
            this.getWage(gradingWage, viewwageArray, 'human_grading');
            this.getWage(peelingWage, viewwageArray, 'human_peeling');

            return viewwageArray;

        } catch (e) {
            throw new Error(e);
        }

    }


    getWage(array, viewwageArray, key) {

        array.forEach(element => {
            let index = viewwageArray.findIndex(o => new Date(o.entry_date).getTime() == new Date(element.entry_date).getTime());
            let amount = element.total_wage ? parseFloat(element.total_wage) : 0;
            if (index > -1) {
                let wage = viewwageArray[index];
                wage[key] = wage[key] ? (parseFloat(wage[key]) + amount) : amount;
                viewwageArray[index] = wage;
            } else {
                let wage = { entry_date: element.entry_date, [key]: amount };
                viewwageArray.push(wage);
            }
        });
    }

}

export const viewWageRepository = new viewWageRepositoryClass();