
class viewWageHelperClass {
}

export const viewWageHelper = new viewWageHelperClass();