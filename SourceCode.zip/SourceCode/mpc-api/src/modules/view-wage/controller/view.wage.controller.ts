import { httpUtility } from "utils/http";
import { viewWageRepository } from "../repository/view.wage.repository";


class viewWageControllerClass {

    public async getViewWageAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.viewWage = JSON.parse(JSON.stringify(httpStack.req.query));

            let viewWages;
            if (requestJSON.viewWage.employee_id) {
                viewWages = await viewWageRepository.getViewWageByEMployee(requestJSON);
            } else {
                viewWages = await viewWageRepository.getViewWageAll(requestJSON);
            }

            httpUtility.sendSuccess(httpStack, viewWages);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }


}

export const viewWageController = new viewWageControllerClass();