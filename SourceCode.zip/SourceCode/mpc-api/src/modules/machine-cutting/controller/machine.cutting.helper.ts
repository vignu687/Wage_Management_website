
class machineCuttingHelperClass {
}

export const machineCuttingHelper = new machineCuttingHelperClass();