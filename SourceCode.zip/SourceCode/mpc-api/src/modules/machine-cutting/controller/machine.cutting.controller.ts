import { httpUtility } from "utils/http";
import { machineCuttingRepository } from "../repository/machine.cutting.repository";


class machineCuttingControllerClass {

    public async addMachineCutting(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.machineCutting = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.machineCutting.created_by=requestJSON.configSQL.userid;
            requestJSON.machineCutting.updated_by=requestJSON.configSQL.userid;
            const machineCutting = await machineCuttingRepository.addMachineCutting(requestJSON);

            httpUtility.sendSuccess(httpStack, machineCutting);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async addMachineCuttingMany(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.machineCutting = JSON.parse(JSON.stringify(httpStack.req.body));
            for (let i in requestJSON.machineCutting){
                requestJSON.machineCutting[i].created_by=requestJSON.configSQL.userid;
                requestJSON.machineCutting[i].updated_by=requestJSON.configSQL.userid;
            }
            const machineCutting = await machineCuttingRepository.addMachineCuttingMany(requestJSON);

            httpUtility.sendSuccess(httpStack, machineCutting);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }



    public async updateMachineCuttingById(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.machineCutting = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.id = httpStack.req.params.mc_id;
            requestJSON.machineCutting.updated_by=requestJSON.configSQL.userid;
            const machineCutting = await machineCuttingRepository.updateMachineCuttingById(requestJSON);

            httpUtility.sendSuccess(httpStack, machineCutting);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getMachineCuttingAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.machineCutting = JSON.parse(JSON.stringify(httpStack.req.query));

            const machineCuttings = await machineCuttingRepository.getMachineCuttingAll(requestJSON);

            httpUtility.sendSuccess(httpStack, machineCuttings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getMachineCuttingById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.mc_id;
            const machineCuttings = await machineCuttingRepository.getMachineCuttingById(requestJSON);

            httpUtility.sendSuccess(httpStack, machineCuttings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async deleteMachineCuttingById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.mc_id;
            const machineCuttings = await machineCuttingRepository.deleteMachineCuttingById(requestJSON);

            httpUtility.sendSuccess(httpStack, machineCuttings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const machineCuttingController = new machineCuttingControllerClass();