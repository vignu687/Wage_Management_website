import { dateFilter } from 'utils/date.filter';
import MachineCutting from '../../../model/machine.cutting.model';

class machineCuttingRepositoryClass {

    public async addMachineCutting(requestJSON: any): Promise<any> {

        try {
            const machineCutting = new MachineCutting(requestJSON.machineCutting)
            return await machineCutting.save();

        } catch (e) {
            throw new Error(e);
        }

    }

    public async addMachineCuttingMany(requestJSON: any): Promise<any> {

        try {
            MachineCutting.insertMany(requestJSON.machineCutting);
            requestJSON.machineCutting = requestJSON.machineCutting[0];
            return await this.getMachineCuttingAll(requestJSON)
        } catch (e) {
            throw new Error(e);
        }
    }

    public async updateMachineCuttingById(requestJSON: any): Promise<any> {

        try {

            return await MachineCutting.findByIdAndUpdate(requestJSON.id, requestJSON.machineCutting, { new: true });

        } catch (e) {
            throw new Error(e);
        }

    }

    public async deleteMachineCuttingById(requestJSON: any): Promise<any> {

        try {

            return await MachineCutting.findByIdAndRemove(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getMachineCuttingAll(requestJSON: any): Promise<any> {

        try {
            const conditions = {
                origin_id: requestJSON.machineCutting.origin_id,
                lot_id: requestJSON.machineCutting.lot_id,
                entry_date: dateFilter.getDateFilter(requestJSON.machineCutting.entry_date),
                entry_type: requestJSON.machineCutting.entry_type,
                machine_name : requestJSON.machineCutting.machine_name,
                status: true
            };
            return await MachineCutting.find(conditions);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getMachineCuttingById(requestJSON: any): Promise<any> {

        try {

            return await MachineCutting.findById(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getMachineCuttingByDate(requestJSON: any): Promise<any> {

        try {

            return await MachineCutting.aggregate([

                {
                    $match: {
                        updated_date: dateFilter.getDateFilter(requestJSON.report.date_start, requestJSON.report.date_end),
                    },
                },
                {
                    $unwind: "$trays"
                },
                {
                    $group: {
                        _id: "$entry_type",
                        total: {
                            $sum: "$trays.tray"
                        },
                        count: { $sum: 1 }
                    }
                },
                {
                    $sort: {
                        _id: 1
                    }
                }
            ]);

        } catch (e) {
            throw new Error(e);
        }

    }

}

export const machineCuttingRepository = new machineCuttingRepositoryClass();