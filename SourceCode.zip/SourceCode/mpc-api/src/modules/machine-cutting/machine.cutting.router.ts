import express = require("express");
import { httpUtility } from "utils/http";
import { machineCuttingController } from "./controller/machine.cutting.controller";

class machineCuttingRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {

        this.router.post('/', (req, res, next) => { httpUtility.action(req, res, next, machineCuttingController.addMachineCutting) });
        this.router.put('/:mc_id', (req, res, next) => { httpUtility.action(req, res, next, machineCuttingController.updateMachineCuttingById) });
        this.router.get('/', (req, res, next) => { httpUtility.action(req, res, next, machineCuttingController.getMachineCuttingAll) });
        this.router.get('/:mc_id', (req, res, next) => { httpUtility.action(req, res, next, machineCuttingController.getMachineCuttingById) });
        this.router.delete('/:mc_id', (req, res, next) => { httpUtility.action(req, res, next, machineCuttingController.deleteMachineCuttingById) });

    }
}

export const machineCuttingRouter = new machineCuttingRouterClass().router;