import express = require("express");
import { httpUtility } from "utils/http";
import { humanPeelingController } from "./controller/human.peeling.controller";

class humanPeelingRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {

        this.router.post('/', (req, res, next) => { httpUtility.action(req, res, next, humanPeelingController.addHumanPeeling) });
        this.router.put('/:hp_id', (req, res, next) => { httpUtility.action(req, res, next, humanPeelingController.updateHumanPeelingById) });
        this.router.get('/descriptions', (req, res, next) => { httpUtility.action(req, res, next, humanPeelingController.getHumanPeelingDescriptions) });
        this.router.get('/', (req, res, next) => { httpUtility.action(req, res, next, humanPeelingController.getHumanPeelingAll) });
        this.router.get('/:hp_id', (req, res, next) => { httpUtility.action(req, res, next, humanPeelingController.getHumanPeelingById) });
        this.router.delete('/:hp_id', (req, res, next) => { httpUtility.action(req, res, next, humanPeelingController.deleteHumanPeelingById) });
        this.router.get('/descriptions/:key/questions', (req, res, next) => { httpUtility.action(req, res, next, humanPeelingController.getHumanPeelingQuestionsByDescription) });

    }
}

export const humanPeelingRouter = new humanPeelingRouterClass().router;