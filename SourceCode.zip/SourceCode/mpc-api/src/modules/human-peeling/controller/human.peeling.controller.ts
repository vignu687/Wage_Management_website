import { httpUtility } from "utils/http";
import { humanPeelingRepository } from "../repository/human.peeling.repository";
import { humanPeelingDescriptions, humanPeelingQuestions } from "master-data/human.peeling.description";
import { humanPeelingHelper } from "./human.peeling.helper";


class humanPeelingControllerClass {

    public async addHumanPeeling(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.humanPeeling = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.humanPeeling = await humanPeelingHelper.getHumanPeelingWage(requestJSON);
            requestJSON.humanPeeling.created_by=requestJSON.configSQL.userid;
            requestJSON.humanPeeling.updated_by=requestJSON.configSQL.userid;
            const humanPeeling = await humanPeelingRepository.addHumanPeeling(requestJSON);

            httpUtility.sendSuccess(httpStack, humanPeeling);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async addHumanPeelingMany(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.humanPeeling = JSON.parse(JSON.stringify(httpStack.req.body));
            for (let i in requestJSON.humanPeeling){
                requestJSON.humanPeeling[i].created_by=requestJSON.configSQL.userid;
                requestJSON.humanPeeling[i].updated_by=requestJSON.configSQL.userid;
            }
            const humanPeeling = await humanPeelingRepository.addHumanPeelingMany(requestJSON);

            httpUtility.sendSuccess(httpStack, humanPeeling);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async updateHumanPeelingById(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.humanPeeling = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.id = httpStack.req.params.hp_id;
            requestJSON.humanPeeling = await humanPeelingHelper.getHumanPeelingWage(requestJSON);
            requestJSON.humanPeeling.updated_by=requestJSON.configSQL.userid;
            
            const humanPeeling = await humanPeelingRepository.updateHumanPeelingById(requestJSON);
            if (!humanPeeling) {
                httpStack.message = "Failed to Save,Please try again.";
                httpUtility.sendSuccess(httpStack, []);
                return;
            }
            httpUtility.sendSuccess(httpStack, humanPeeling);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getHumanPeelingAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.humanPeeling = JSON.parse(JSON.stringify(httpStack.req.query));

            let humanPeelings = await humanPeelingRepository.getHumanPeelingAll(requestJSON);

            // if (humanPeelings.length == 0) {
            //     let humanPeeling: any = {};
            //     humanPeeling.origin_id = requestJSON.humanPeeling.origin_id;
            //     humanPeeling.lot_id = requestJSON.humanPeeling.lot_id;
            //     humanPeeling.entry_date = requestJSON.humanPeeling.entry_date;
            //     humanPeeling.employee_id = requestJSON.humanPeeling.employee_id;
            //     humanPeeling.job_descrption = requestJSON.humanPeeling.job_descrption;
            //     humanPeeling.value = humanPeelingQuestions[humanPeeling.job_descrption];
            //     humanPeelings.push(humanPeeling);
            // }
            httpUtility.sendSuccess(httpStack, humanPeelings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getHumanPeelingById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.hp_id;
            const humanPeelings = await humanPeelingRepository.getHumanPeelingById(requestJSON);

            httpUtility.sendSuccess(httpStack, humanPeelings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async deleteHumanPeelingById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.hp_id;
            const humanPeelings = await humanPeelingRepository.deleteHumanPeelingById(requestJSON);

            httpUtility.sendSuccess(httpStack, humanPeelings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public getHumanPeelingDescriptions(httpStack: any, requestJSON: any): any {

        try {

            const descriptions = humanPeelingDescriptions;
            httpUtility.sendSuccess(httpStack, descriptions);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public getHumanPeelingQuestionsByDescription(httpStack: any, requestJSON: any): any {

        try {
            requestJSON.key = httpStack.req.params.key;

            const questions = humanPeelingQuestions[requestJSON.key];
            httpUtility.sendSuccess(httpStack, questions);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const humanPeelingController = new humanPeelingControllerClass();