import { settingRepository } from "modules/management/master-setting/repository/setting.repository";
import { employeeRepository } from "modules/management/employee/repository/employee.repository";

class humanPeelingHelperClass {

    public async getHumanPeelingWage(requestJSON: any) {

        try {
            let settings = await settingRepository.getSettingAll(requestJSON);
            settings = settings[0];
            let peeling = JSON.parse(JSON.stringify(requestJSON.humanPeeling));
            let employee = await employeeRepository.getEmployeeById(JSON.parse('{"id":"'+peeling.employee_id+'"}'));
            requestJSON.humanPeeling.wage = {};

            switch (peeling.job_description) {
                case 'fixed_wages':
                    let attendance = peeling.value.find(o => o.key == 'attendance');
                    let wage_type = peeling.value.find(o => o.key == 'wage_type');

                    if(wage_type.value == 'base_wage'){
                        requestJSON.humanPeeling.wage.wage = employee['peeling'] ? parseFloat(employee['peeling']) : 0;
                    } else {
                        requestJSON.humanPeeling.wage.wage = settings.fixed_wages['peeling'] ? parseFloat(settings.fixed_wages['peeling']) : 0;
                    }

                    if (attendance.value == 'half_day') {
                        requestJSON.humanPeeling.wage.wage = (requestJSON.humanPeeling.wage.wage * 0.5);
                    }
                    break;
                case 'hand_peeling':
                case 'kale':
                case 'hp_peeling':
                case 'hp_kale':
                case 'ungraded_kale':
                    let issue = peeling.value.find(o => o.key == 'issue_weight');
                    let peelingWeight = peeling.value.filter(o => o.key != 'issue_weight' && o.key != 'actual_return_weight');

                    let backCut = peeling.value.find(o => o.key == 'back_cut_weight');
                    let wholes = peeling.value.find(o => o.key == 'wholes_weight');
                    let piece = peeling.value.find(o => o.key == 'pieces_weight');

                    let limit = parseFloat(settings[peeling.job_description]['wholes_weight_limit']);
                    requestJSON.humanPeeling.wage.received = parseFloat(peelingWeight.reduce((acc, cur) => acc + parseFloat(cur.value), 0).toFixed(2));
                    requestJSON.humanPeeling.wage.wholes_rate = humanPeelingHelper.getRate(settings, (parseFloat(backCut.value) + parseFloat(wholes.value)), peeling.job_description, 'wholes_weight', limit);

                    let pieceLimit = (parseFloat(wholes.value) * (parseFloat(settings[peeling.job_description]['pieces_weight_limit_percentage']) / 100));
                    requestJSON.humanPeeling.wage.piece_rate = humanPeelingHelper.getRate(settings, parseFloat(piece.value), peeling.job_description, 'pieces_weight', pieceLimit);
                    requestJSON.humanPeeling.wage.wholes_amount = (parseFloat(backCut.value) + parseFloat(wholes.value)) * (requestJSON.humanPeeling.wage.wholes_rate);
                    requestJSON.humanPeeling.wage.piece_amount = parseFloat(piece.value) * (requestJSON.humanPeeling.wage.piece_rate);
                    requestJSON.humanPeeling.wage.return = parseFloat(issue.value) - requestJSON.humanPeeling.wage.received;
                    requestJSON.humanPeeling.wage.wage = (requestJSON.humanPeeling.wage.wholes_amount + requestJSON.humanPeeling.wage.piece_amount).toFixed(2);
                    break;
                case 'gp360':
                case 'hp_360gp':
                case 'gp':
                case 'hp_gp':

                    let issuegp = peeling.value.find(o => o.key == 'issue_weight');
                    let actualRecievedWeight = peeling.value.filter(o => o.key != 'issue_weight');
                    let jh = peeling.value.find(o => o.key == 'jh_weight');
                    let jh1 = peeling.value.find(o => o.key == 'jh1_weight');
                    let jk = peeling.value.find(o => o.key == 'jk_weight');
                    let rem_pieces_weight = peeling.value.find(o => o.key == 'rem_pieces_weight');

                    requestJSON.humanPeeling.wage.received = parseFloat(issuegp.value);
                    requestJSON.humanPeeling.wage.actual_received = parseFloat(actualRecievedWeight.reduce((acc, cur) => acc + parseFloat(cur.value), 0).toFixed(2));
                    requestJSON.humanPeeling.wage.return = parseFloat(issuegp.value) - requestJSON.humanPeeling.wage.actual_received;
                    requestJSON.humanPeeling.wage.jh_rate = (parseFloat(jh.value) * parseFloat(settings[peeling.job_description]['jh_multiplier'])).toFixed(2);
                    requestJSON.humanPeeling.wage.jh1_rate = (parseFloat(jh1.value) * parseFloat(settings[peeling.job_description]['jh1_multiplier'])).toFixed(2);
                    requestJSON.humanPeeling.wage.jk_rate = (parseFloat(jk.value) * parseFloat(settings[peeling.job_description]['jk_multiplier'])).toFixed(2);

                    let remPieceAmount = peeling.value.filter(o => (o.key == "dp_weight")
                        || (o.key == "dp2_weight")
                        || (o.key == "ss_weight") || (o.key == "pkp_weight") || (o.key == "dooser_weight")
                        || (o.key == "wholes_weight")
                        || (o.key == "rem_pieces_weight")).reduce((acc, cur) => acc + parseFloat(cur.value), 0);


                    if (peeling.job_description == 'gp' || peeling.job_description == 'hp_gp') {
                        requestJSON.humanPeeling.wage.remaining_rate = (parseFloat(remPieceAmount) * parseFloat(settings[peeling.job_description]['remaining_multiplier'])).toFixed(2);
                    } else {
                        requestJSON.humanPeeling.wage.remaining_rate = (parseFloat(rem_pieces_weight.value) * parseFloat(settings[peeling.job_description]['remaining_multiplier'])).toFixed(2);
                    }

                    let gpLimit = parseFloat(settings[peeling.job_description]['weight_limit']);
                    requestJSON.humanPeeling.wage.total_received_rate = humanPeelingHelper.getRate360Gp(settings, requestJSON.humanPeeling.wage.actual_received, peeling.job_description, gpLimit);
                    requestJSON.humanPeeling.wage.wage = (parseFloat(requestJSON.humanPeeling.wage.total_received_rate) + parseFloat(requestJSON.humanPeeling.wage.jh_rate) + parseFloat(requestJSON.humanPeeling.wage.jh1_rate) + parseFloat(requestJSON.humanPeeling.wage.jk_rate) + parseFloat(requestJSON.humanPeeling.wage.remaining_rate)).toFixed(2);
                    break;
                case 'pajji_peeling':
                    let issuepp = peeling.value.find(o => o.key == 'issue_weight');
                    let pajjiPeeling = peeling.value.filter(o => o.key != 'issue_weight' && o.key != 'jh_weight' && o.key != 'pajji_weight' && o.key != 'k_rem_pieces_weight' && o.key != 'husk_weight' && o.key != 'rejection_weight' && o.key != 'dooser_weight');
                    requestJSON.humanPeeling.wage.total = pajjiPeeling.reduce((acc, cur) => acc + parseFloat(cur.value), 0);
                    requestJSON.humanPeeling.wage.return = parseFloat(issuepp.value) - parseFloat(requestJSON.humanPeeling.wage.total);
                    requestJSON.humanPeeling.wage.wage = (this.getPajjiPeelingRate(settings, requestJSON.humanPeeling.wage.total, 1)).toFixed(2);
                    break;
            }
            return requestJSON.humanPeeling;
        } catch (error) {
            throw (error);
        }

    }

    getPajjiPeelingRate(settings, total, i) {
        let rate = 0;
        let condition;
        let pajjiSettings = settings['pajji_peeling'];
        let key = "c" + i;
        switch (pajjiSettings[key + '_condition']) {
            case '>=':
                condition = parseFloat(total) >= pajjiSettings[key + '_weight_limit'];
                break;
            case '<=':
                condition = parseFloat(total) <= pajjiSettings[key + '_weight_limit'];
                break;
            case '=':
                condition = parseFloat(total) == pajjiSettings[key + '_weight_limit'];
                break;
            case '>':
                condition = parseFloat(total) > pajjiSettings[key + '_weight_limit'];
                break;
            case '<':
                condition = parseFloat(total) < pajjiSettings[key + '_weight_limit'];
                break;
        }

        let conditionalRate;
        if (key == 'c1') {
            conditionalRate = parseFloat(pajjiSettings['c1_rate_multiplier']) * parseFloat(total);
        } else {
            conditionalRate = parseFloat(pajjiSettings[key + '_rate']);
        }


        if (i < 3) {
            i = i + 1;
            if (condition) {
                rate = conditionalRate;
            } else {
                return this.getPajjiPeelingRate(settings, total, i)
            }
        } else {
            rate = condition ? conditionalRate : 0;
        }
        return rate;
    }

    getRate(settings, weight, desc_type, key, limit) {
        let rate = 0;
        let condition;

        switch (settings[desc_type][key + '_condition']) {
            case '>=':
                condition = parseFloat(weight) >= limit;
                break;
            case '<=':
                condition = parseFloat(weight) <= limit;
                break;
            case '=':
                condition = parseFloat(weight) == limit;
                break;
            case '>':
                condition = parseFloat(weight) > limit;
                break;
            case '<':
                condition = parseFloat(weight) < limit;
                break;
        }
        rate = condition ? settings[desc_type][key + '_limit_true'] : settings[desc_type][key + '_limit_false'];
        return rate;
    }

    getRate360Gp(settings, weight, desc_type, limit) {
        let rate = 0;
        let condition;

        switch (settings[desc_type]['condition']) {
            case '>=':
                condition = parseFloat(weight) >= limit;
                break;
            case '<=':
                condition = parseFloat(weight) <= limit;
                break;
            case '=':
                condition = parseFloat(weight) == limit;
                break;
            case '>':
                condition = parseFloat(weight) > limit;
                break;
            case '<':
                condition = parseFloat(weight) < limit;
                break;
        }
        rate = condition ? settings[desc_type]['true_multiplier'] : settings[desc_type]['false_multiplier'];
        return rate * weight;
    }

    getPeelingPajjiRate(settings, weight, desc_type, limit) {
        let rate = 0;
        let condition;

        switch (settings[desc_type]['condition']) {
            case '>=':
                condition = parseFloat(weight) >= limit;
                break;
            case '<=':
                condition = parseFloat(weight) <= limit;
                break;
            case '=':
                condition = parseFloat(weight) == limit;
                break;
            case '>':
                condition = parseFloat(weight) > limit;
                break;
            case '<':
                condition = parseFloat(weight) < limit;
                break;
        }
        rate = condition ? settings[desc_type]['true_multiplier'] : settings[desc_type]['false_multiplier'];
        return rate * weight;
    }

}

export const humanPeelingHelper = new humanPeelingHelperClass();