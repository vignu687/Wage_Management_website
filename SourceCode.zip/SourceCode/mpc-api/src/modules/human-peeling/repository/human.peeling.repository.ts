import { dateFilter } from 'utils/date.filter';
import HumanPeeling from '../../../model/human.peeling.model';

class humanPeelingRepositoryClass {

    public addHumanPeeling(requestJSON: any): Promise<any> {

        try {
            const humanPeeling = new HumanPeeling(requestJSON.humanPeeling)
            return humanPeeling.save();

        } catch (e) {
            throw new Error(e);
        }

    }

    public addHumanPeelingMany(requestJSON: any): Promise<any> {

        try {
            HumanPeeling.insertMany(requestJSON.humanPeeling);
            requestJSON.humanPeeling = requestJSON.humanPeeling[0];
            return this.getHumanPeelingAll(requestJSON)
        } catch (e) {
            throw new Error(e);
        }
    }

    public async updateHumanPeelingById(requestJSON: any): Promise<any> {

        try {

            return await HumanPeeling.findByIdAndUpdate(requestJSON.id, requestJSON.humanPeeling, { new: true });

        } catch (e) {
            throw new Error(e);
        }

    }

    public async deleteHumanPeelingById(requestJSON: any): Promise<any> {

        try {

            return await HumanPeeling.findByIdAndRemove(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getHumanPeelingAll(requestJSON: any): Promise<any> {

        try {
            const conditions = {
                origin_id: requestJSON.humanPeeling.origin_id,
                lot_id: requestJSON.humanPeeling.lot_id,
                entry_date: dateFilter.getDateFilter(requestJSON.humanPeeling.entry_date),
                employee_id: requestJSON.humanPeeling.employee_id,
                // job_description: requestJSON.humanPeeling.job_description,
                status: true
            };
            return await HumanPeeling.find(conditions);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getHumanPeelingById(requestJSON: any): Promise<any> {

        try {

            return await HumanPeeling.findById(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getHumanPeelingDb(requestJSON: any): Promise<any> {

        try {


            return await HumanPeeling.aggregate([
                {
                    $project:
                    {
                        origin_id: 1,
                        lot_id: 1,
                        entry_date: 1
                    }
                },
                {
                    $match: {
                        origin_id: requestJSON.humanPeeling.origin_id,
                        lot_id: requestJSON.humanPeeling.lot_id,
                        entry_date: dateFilter.getDateFilter(requestJSON.humanPeeling.entry_date)
                    },
                }, {
                    $group: {
                        _id: {
                            origin_id: "$origin_id",
                            lot_id: "$lot_id",
                            entry_date: "$entry_date"
                        },
                        count: { $sum: 1 }
                    }
                }
            ]);

        } catch (e) {
            throw new Error(e);
        }
    }

    public async getHumanPeelingByDate(requestJSON: any): Promise<any> {

        try {
            return await HumanPeeling.aggregate([
                {
                    $match: {
                        updated_date: dateFilter.getDateFilter(requestJSON.report.date_start, requestJSON.report.date_end),
                        job_description: requestJSON.job_description
                    },
                },
                {
                    $sort: {
                        _id: 1
                    }
                }
            ]);

        } catch (e) {
            throw new Error(e);
        }

    }
}

export const humanPeelingRepository = new humanPeelingRepositoryClass();