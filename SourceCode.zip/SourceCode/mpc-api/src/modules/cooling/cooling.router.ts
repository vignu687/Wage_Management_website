import express = require("express");
import { httpUtility } from "utils/http";
import { coolingController } from "./controller/cooling.controller";

export class coolingRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {

        this.router.post('/', (req, res, next) => { httpUtility.action(req, res, next, coolingController.addCooling) });
        this.router.put('/:cid', (req, res, next) => { httpUtility.action(req, res, next, coolingController.updateCoolingById) });
        this.router.get('/', (req, res, next) => { httpUtility.action(req, res, next, coolingController.getCoolingAll) });
        this.router.get('/:cid', (req, res, next) => { httpUtility.action(req, res, next, coolingController.getCoolingById) });
        this.router.delete('/:cid', (req, res, next) => { httpUtility.action(req, res, next, coolingController.deleteCoolingById) });

    }
}

export const coolingRouter = new coolingRouterClass().router;