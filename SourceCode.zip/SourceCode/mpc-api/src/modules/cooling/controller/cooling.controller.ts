import { httpUtility } from "utils/http";
import { coolingRepository } from "../repository/cooling.repository";


class coolingControllerClass {

    public async addCooling(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.cooling = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.cooling.created_by=requestJSON.configSQL.userid;
            requestJSON.cooling.updated_by=requestJSON.configSQL.userid;
            const cooling = await coolingRepository.addCooling(requestJSON);

            httpUtility.sendSuccess(httpStack, cooling);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async addCoolingMany(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.cooling = JSON.parse(JSON.stringify(httpStack.req.body));
            for (let i in requestJSON.cooling){
                requestJSON.cooling[i].created_by=requestJSON.configSQL.userid;
                requestJSON.cooling[i].updated_by=requestJSON.configSQL.userid;
            }
            const cooling = await coolingRepository.addCoolingMany(requestJSON);

            httpUtility.sendSuccess(httpStack, cooling);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }



    public async updateCoolingById(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.cooling = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.id = httpStack.req.params.cid;
            requestJSON.cooling.updated_by=requestJSON.configSQL.userid;
            const cooling = await coolingRepository.updateCoolingById(requestJSON);

            httpUtility.sendSuccess(httpStack, cooling);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getCoolingAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.cooling = JSON.parse(JSON.stringify(httpStack.req.query));

            const coolings = await coolingRepository.getCoolingAll(requestJSON);

            httpUtility.sendSuccess(httpStack, coolings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getCoolingById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.cid;
            const coolings = await coolingRepository.getCoolingById(requestJSON);

            httpUtility.sendSuccess(httpStack, coolings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async deleteCoolingById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.cid;
            const coolings = await coolingRepository.deleteCoolingById(requestJSON);

            httpUtility.sendSuccess(httpStack, coolings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const coolingController = new coolingControllerClass();