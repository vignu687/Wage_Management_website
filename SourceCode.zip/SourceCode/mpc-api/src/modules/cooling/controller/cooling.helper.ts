
class coolingHelperClass {
}

export const coolingHelper = new coolingHelperClass();