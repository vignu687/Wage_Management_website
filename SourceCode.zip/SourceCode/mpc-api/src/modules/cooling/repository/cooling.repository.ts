import { dateFilter } from 'utils/date.filter';
import Cooling from '../../../model/cooling.model';

class coolingRepositoryClass {

    public async addCooling(requestJSON: any): Promise<any> {

        try {
            const cooling = new Cooling(requestJSON.cooling)
            return await cooling.save();

        } catch (e) {
            throw new Error(e);
        }

    }

    public async addCoolingMany(requestJSON: any): Promise<any> {

        try {
            Cooling.insertMany(requestJSON.cooling);
            requestJSON.cooling = requestJSON.cooling[0];
            return await this.getCoolingAll(requestJSON)
        } catch (e) {
            throw new Error(e);
        }
    }

    public async updateCoolingById(requestJSON: any): Promise<any> {

        try {

            return await Cooling.findByIdAndUpdate(requestJSON.id, requestJSON.cooling, { new: true });

        } catch (e) {
            throw new Error(e);
        }

    }

    public async deleteCoolingById(requestJSON: any): Promise<any> {

        try {

            return await Cooling.findByIdAndRemove(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getCoolingAll(requestJSON: any): Promise<any> {

        try {
            const conditions = {
                origin_id: requestJSON.cooling.origin_id,
                lot_id: requestJSON.cooling.lot_id,
                entry_date: dateFilter.getDateFilter(requestJSON.cooling.entry_date),
                entry_type: requestJSON.cooling.entry_type,
                status: true
            };
            return await Cooling.find(conditions);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getCoolingById(requestJSON: any): Promise<any> {

        try {

            return await Cooling.findById(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getCoolingDb(requestJSON: any): Promise<any> {

        try {


            return Cooling.aggregate([
                {
                    $project:
                    {
                        origin_id: 1,
                        lot_id: 1,
                        entry_date: 1
                    }
                },
                {
                    $match: {
                        origin_id: requestJSON.cooling.origin_id,
                        lot_id: requestJSON.cooling.lot_id,
                        entry_date: dateFilter.getDateFilter(requestJSON.cooling.entry_date)
                    },
                }, {
                    $group: {
                        _id: {
                            origin_id: "$origin_id",
                            lot_id: "$lot_id",
                            entry_date: "$entry_date"
                        },
                        count: { $sum: 1 }
                    }
                }
            ]);

        } catch (e) {
            throw new Error(e);
        }


    }

    public async getCoolingByDate(requestJSON: any): Promise<any> {

        try {

            return await Cooling.aggregate([

                {
                    $match: {
                        updated_date: dateFilter.getDateFilter(requestJSON.report.date_start, requestJSON.report.date_end),
                    },
                },
                {
                    $unwind: "$trays"
                },
                {
                    $group: {
                        _id: "$entry_type",
                        total: {
                            $sum: "$trays.tray"
                        },
                        count: { $sum: 1 }
                    }
                },
                {
                    $sort: {
                        _id: 1
                    }
                }
            ]);

        } catch (e) {
            throw new Error(e);
        }

    }
}

export const coolingRepository = new coolingRepositoryClass();