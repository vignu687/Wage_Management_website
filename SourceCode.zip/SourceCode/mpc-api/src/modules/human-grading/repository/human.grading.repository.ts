import { dateFilter } from 'utils/date.filter';
import HumanGrading from '../../../model/human.grading.model';

class HumanGradingRepositoryClass {

    public addHumanGrading(requestJSON: any): Promise<any> {

        try {
            const humanGrading = new HumanGrading(requestJSON.humanGrading)
            return humanGrading.save();

        } catch (e) {
            throw new Error(e);
        }

    }

    public addHumanGradingMany(requestJSON: any): Promise<any> {

        try {
            HumanGrading.insertMany(requestJSON.humanGrading);
            requestJSON.humanGrading = requestJSON.humanGrading[0];
            return this.getHumanGradingAll(requestJSON)
        } catch (e) {
            throw new Error(e);
        }
    }

    public async updateHumanGradingById(requestJSON: any): Promise<any> {

        try {

            return await HumanGrading.findByIdAndUpdate(requestJSON.id, requestJSON.humanGrading, { new: true });

        } catch (e) {
            throw new Error(e);
        }

    }

    public async deleteHumanGradingById(requestJSON: any): Promise<any> {

        try {

            return await HumanGrading.findByIdAndRemove(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getHumanGradingAll(requestJSON: any): Promise<any> {

        try {
            const conditions = {
                origin_id: requestJSON.humanGrading.origin_id,
                lot_id: requestJSON.humanGrading.lot_id,
                entry_date: dateFilter.getDateFilter(requestJSON.humanGrading.entry_date),
                employee_id: requestJSON.humanGrading.employee_id,
               // job_description: requestJSON.humanGrading.job_description,
                status: true
            };
            return await HumanGrading.find(conditions);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getHumanGradingById(requestJSON: any): Promise<any> {

        try {

            return await HumanGrading.findById(requestJSON.id);

        } catch (e) {
            throw new Error(e);
        }

    }

    public async getHumanGradingDb(requestJSON: any): Promise<any> {

        try {


            return await HumanGrading.aggregate([
                {
                    $project:
                    {
                        origin_id: 1,
                        lot_id: 1,
                        entry_date: 1
                    }
                },
                {
                    $match: {
                        origin_id: requestJSON.humanGrading.origin_id,
                        lot_id: requestJSON.humanGrading.lot_id,
                        entry_date: dateFilter.getDateFilter(requestJSON.humanGrading.entry_date)
                    },
                }, {
                    $group: {
                        _id: {
                            origin_id: "$origin_id",
                            lot_id: "$lot_id",
                            entry_date: "$entry_date"
                        },
                        count: { $sum: 1 }
                    }
                }
            ]);

        } catch (e) {
            throw new Error(e);
        }


    }

    public async getHumanGradingByDate(requestJSON: any): Promise<any> {

        try {
            return await HumanGrading.aggregate([
                {
                    $match: {
                        updated_date: dateFilter.getDateFilter(requestJSON.report.date_start, requestJSON.report.date_end),
                        job_description: requestJSON.job_description
                    },
                },
                {
                    $sort: {
                        _id: 1
                    }
                }
            ]);

        } catch (e) {
            throw new Error(e);
        }

    }
}

export const humanGradingRepository = new HumanGradingRepositoryClass();