import express = require("express");
import { httpUtility } from "utils/http";
import { humanGradingController } from "./controller/human.grading.controller";

class HumanGradingRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    private config(): void {

        this.router.post('/', (req, res, next) => { httpUtility.action(req, res, next, humanGradingController.addHumanGrading) });
        this.router.put('/:hg_id', (req, res, next) => { httpUtility.action(req, res, next, humanGradingController.updateHumanGradingById) });
        this.router.get('/descriptions', (req, res, next) => { httpUtility.action(req, res, next, humanGradingController.getHumanGradingDescriptions) });
        this.router.get('/', (req, res, next) => { httpUtility.action(req, res, next, humanGradingController.getHumanGradingAll) });
        this.router.get('/:hg_id', (req, res, next) => { httpUtility.action(req, res, next, humanGradingController.getHumanGradingById) });
        this.router.delete('/:hg_id', (req, res, next) => { httpUtility.action(req, res, next, humanGradingController.deleteHumanGradingById) });
        this.router.get('/descriptions/:key/questions', (req, res, next) => { httpUtility.action(req, res, next, humanGradingController.getHumanGradingQuestionsByDescription) });

    }
}

export const humanGradingRouter = new HumanGradingRouterClass().router;