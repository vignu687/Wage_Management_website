import { httpUtility } from "utils/http";
import { humanGradingRepository } from "../repository/human.grading.repository";
import { humanGradingDescriptions, humanGradingQuestions } from "master-data/human.grading.description";
import { humanGradingHelper } from "./human.grading.helper";


class HumanGradingControllerClass {

    public async addHumanGrading(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.humanGrading = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.humanGrading = await humanGradingHelper.getHumanGradingWage(requestJSON);
            requestJSON.humanGrading.created_by=requestJSON.configSQL.userid;
            requestJSON.humanGrading.updated_by=requestJSON.configSQL.userid;
            const humanGrading = await humanGradingRepository.addHumanGrading(requestJSON);

            httpUtility.sendSuccess(httpStack, humanGrading);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async addHumanGradingMany(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.humanGrading = JSON.parse(JSON.stringify(httpStack.req.body));
            for (let i in requestJSON.humanGrading){
                requestJSON.humanGrading[i].created_by=requestJSON.configSQL.userid;
                requestJSON.humanGrading[i].updated_by=requestJSON.configSQL.userid;
            }
            const humanGrading = await humanGradingRepository.addHumanGradingMany(requestJSON);

            httpUtility.sendSuccess(httpStack, humanGrading);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async updateHumanGradingById(httpStack: any, requestJSON: any): Promise<any> {


        try {
            requestJSON.humanGrading = JSON.parse(JSON.stringify(httpStack.req.body));
            requestJSON.id = httpStack.req.params.hg_id;
            requestJSON.humanGrading = await humanGradingHelper.getHumanGradingWage(requestJSON);
            requestJSON.humanGrading.updated_by=requestJSON.configSQL.userid;
            
            const humanGrading = await humanGradingRepository.updateHumanGradingById(requestJSON);
            if (!humanGrading) {
                httpStack.message="Failed to Save,Please try again.";
                httpUtility.sendSuccess(httpStack, []);
                return;
            }
            httpUtility.sendSuccess(httpStack, humanGrading);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getHumanGradingAll(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.humanGrading = JSON.parse(JSON.stringify(httpStack.req.query));

            let humanGradings = await humanGradingRepository.getHumanGradingAll(requestJSON);

            // if (humanGradings.length == 0) {
            //     let humanGrading: any = {};
            //     humanGrading.origin_id = requestJSON.humanGrading.origin_id;
            //     humanGrading.lot_id = requestJSON.humanGrading.lot_id;
            //     humanGrading.entry_date = requestJSON.humanGrading.entry_date;
            //     humanGrading.employee_id = requestJSON.humanGrading.employee_id;
            //     humanGrading.job_descrption = requestJSON.humanGrading.job_descrption;
            //     humanGrading.value = humanGradingQuestions[humanGrading.job_descrption];
            //     humanGradings.push(humanGrading);
            // }
            httpUtility.sendSuccess(httpStack, humanGradings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async getHumanGradingById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.hg_id;
            const humanGradings = await humanGradingRepository.getHumanGradingById(requestJSON);

            httpUtility.sendSuccess(httpStack, humanGradings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public async deleteHumanGradingById(httpStack: any, requestJSON: any): Promise<any> {

        try {
            requestJSON.id = httpStack.req.params.hg_id;
            const humanGradings = await humanGradingRepository.deleteHumanGradingById(requestJSON);

            httpUtility.sendSuccess(httpStack, humanGradings);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public getHumanGradingDescriptions(httpStack: any, requestJSON: any): any {

        try {

            const descriptions = humanGradingDescriptions;
            httpUtility.sendSuccess(httpStack, descriptions);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

    public getHumanGradingQuestionsByDescription(httpStack: any, requestJSON: any): any {

        try {
            requestJSON.key = httpStack.req.params.key;

            const questions = humanGradingQuestions[requestJSON.key];
            httpUtility.sendSuccess(httpStack, questions);

        } catch (error) {
            httpUtility.sendError(httpStack, error);
        }
    }

}

export const humanGradingController = new HumanGradingControllerClass();