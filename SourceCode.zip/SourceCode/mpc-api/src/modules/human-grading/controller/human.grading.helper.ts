import { settingRepository } from "modules/management/master-setting/repository/setting.repository";
import { employeeRepository } from "modules/management/employee/repository/employee.repository";

class humanGradingHelperClass {

    public async getHumanGradingWage(requestJSON: any) {
        try {        
            let settings = await settingRepository.getSettingAll(requestJSON);
            settings = settings[0];
            let grading = JSON.parse(JSON.stringify(requestJSON.humanGrading));
            let employee = await employeeRepository.getEmployeeById(JSON.parse('{"id":"'+grading.employee_id+'"}'));
            requestJSON.humanGrading.wage = {};

            switch (grading.job_description) {
                case 'fixed_wages':
                    let attendance = grading.value.find(o => o.key == 'attendance');
                    let wage_type = grading.value.find(o => o.key == 'wage_type');

                    if(wage_type.value == 'base_wage'){
                        requestJSON.humanGrading.wage.wage = employee['kernel_grading'] ? parseFloat(employee['kernel_grading']) : 0;
                    } else {
                        requestJSON.humanGrading.wage.wage = settings.fixed_wages['kernel_grading'] ? parseFloat(settings.fixed_wages['kernel_grading']) : 0;
                    }
                    
                    if (attendance.value == 'half_day') {
                        requestJSON.humanGrading.wage.wage = (requestJSON.humanGrading.wage.wage * 0.5);
                    }
                break;
                case 'jh_piece':
                case 'dp_piece':
                    let issueWeight = grading.value.find(o => o.key == 'issue_weight');
                    let totalWeight = grading.value.filter(o => o.key != 'issue_weight');
                    requestJSON.humanGrading.wage.total = totalWeight.reduce((acc, cur) => acc + parseFloat(cur.value), 0);
                    requestJSON.humanGrading.wage.return = parseFloat(issueWeight.value) - parseFloat(requestJSON.humanGrading.wage.total);
                    requestJSON.humanGrading.wage.wage = this.getConditionalRate(settings, requestJSON.humanGrading.wage.total, 1,grading.job_description,3);
                break;
                case 'piece_pajji':
                    let issueWeightPp = grading.value.find(o => o.key == 'issue_weight');
                    let totalWeightPp = grading.value.filter(o => o.key != 'issue_weight' && o.key != 'pajji_weight' && o.key != 'rejection_weight' && o.key != 'dooser_weight');
                    requestJSON.humanGrading.wage.total = totalWeightPp.reduce((acc, cur) => acc + parseFloat(cur.value), 0);
                    requestJSON.humanGrading.wage.return = parseFloat(issueWeightPp.value) - parseFloat(requestJSON.humanGrading.wage.total);
                    requestJSON.humanGrading.wage.wage = this.getConditionalRate(settings, requestJSON.humanGrading.wage.total, 1,grading.job_description,3);
                break;
                case 'wholes_grading':
                    let issueWeightWh = grading.value.find(o => o.key == 'issue_weight');
                    let totalWeightWh = grading.value.filter(o => o.key != 'issue_weight');
                    requestJSON.humanGrading.wage.total = totalWeightWh.reduce((acc, cur) => acc + parseFloat(cur.value), 0);
                    requestJSON.humanGrading.wage.return = parseFloat(issueWeightWh.value) - parseFloat(requestJSON.humanGrading.wage.total);
                    requestJSON.humanGrading.wage.total_recieved = parseFloat(requestJSON.humanGrading.wage.total)-parseFloat(requestJSON.humanGrading.wage.return);
                    requestJSON.humanGrading.wage.wage = this.getConditionalRate(settings, requestJSON.humanGrading.wage.total_recieved, 1,grading.job_description,4);
                break;
            }

            return requestJSON.humanGrading;

        } catch (error) {
            throw (error);
        }
    }

    getConditionalRate(settings, total, i,type,level) {
        let rate = 0;
        let condition;
        let rateMasterSettings = settings[type];
        let key = "c" + i;
        switch (rateMasterSettings[key + '_condition']) {
            case '>=':
                condition = parseFloat(total) >= rateMasterSettings[key + '_weight_limit'];
                break;
            case '<=':
                condition = parseFloat(total) <= rateMasterSettings[key + '_weight_limit'];
                break;
            case '=':
                condition = parseFloat(total) == rateMasterSettings[key + '_weight_limit'];
                break;
            case '>':
                condition = parseFloat(total) > rateMasterSettings[key + '_weight_limit'];
                break;
            case '<':
                condition = parseFloat(total) < rateMasterSettings[key + '_weight_limit'];
                break;
        }

        let conditionalRate;
        if (key == 'c1') {
            conditionalRate = parseFloat(rateMasterSettings['c1_rate_multiplier']) * parseFloat(total);
        } else {
            conditionalRate = parseFloat(rateMasterSettings[key + '_rate']);
        }


        if (i < level) {
            i = i + 1;
            if (condition) {
                rate = conditionalRate;
            } else {
                return this.getConditionalRate(settings, total, i,type,level)
            }
        } else {
            rate = condition ? conditionalRate : 0;
        }
        return rate;
    }

}

export const humanGradingHelper = new humanGradingHelperClass();