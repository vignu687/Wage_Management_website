export const humanPeelingDescriptions = [
    {
        "key": "fixed_wages",
        "label": "Fixed Wages",
    },
    {
        "key": "hand_peeling",
        "label": "Hand Peeling",
    },
    {
        "key": "kale",
        "label": "Kale",
    },
    {
        "key": "ungraded_kale",
        "label": "Ungraded Kale",
    },
    {
        "key": "gp360",
        "label": "360 GP",
    },
    {
        "key": "gp",
        "label": "GP",
    },
    {
        "key": "hp_peeling",
        "label": "HP Peeling",
    },
    {
        "key": "hp_kale",
        "label": "HP Kale",
    },
    {
        "key": "hp_360gp",
        "label": "HP 360 GP",
    },
    {
        "key": "hp_gp",
        "label": "HP GP",
    },
    {
        "key": "pajji_peeling",
        "label": "Pajji Peeling",
    }
];

export const humanPeelingQuestions = {
    "fixed_wages": [
        {
            "key": "attendance",
            "label": "Attendance",
            "options": [{
                "ans_label": "Half Day",
                "ans_value": "half_day"
            }, {
                "ans_label": "Full Day",
                "ans_value": "full_day"
            }],
            "value": ""
        },{
            "key": "wage_type",
            "label": "Wage Type",
            "options": [
                { "ans_label": "Base Wage", "ans_value": "base_wage" },
                { "ans_label": "General Wage", "ans_value": "general_wage" }
            ],
            "value": ""
        }
    ],
    "hand_peeling": [
        {
            "key": "issue_weight",
            "label": "issue Weight",
            "value": ""
        },
        {
            "key": "back_cut_weight",
            "label": "Back Cut Weight",
            "value": ""
        },
        {
            "key": "wholes_weight",
            "label": "wholes weight",
            "value": ""
        },
        {
            "key": "pieces_weight",
            "label": "piece weight",
            "value": ""
        },
        {
            "key": "husk_weight",
            "label": "husk weight",
            "value": ""
        },
        {
            "key": "rejection_weight",
            "label": "rejection weight",
            "value": ""
        },
        {
            "key": "powder_weight",
            "label": "powder weight",
            "value": ""
        },
        {
            "key": "duser_weight",
            "label": "duser weight",
            "value": ""
        },
        {
            "key": "pajji_weight",
            "label": "pajji weight",
            "value": ""
        },
        {
            "key": "actual_return_weight",
            "label": "actual return weight",
            "value": ""
        }
    ],
    "kale": [
        {
            "key": "issue_weight",
            "label": "issue weight",
            "value": ""
        },
        {
            "key": "back_cut_weight",
            "label": "back cut weight",
            "value": ""
        },
        {
            "key": "wholes_weight",
            "label": "wholes weight",
            "value": ""
        },
        {
            "key": "pieces_weight",
            "label": "piece weight",
            "value": ""
        },
        {
            "key": "husk_weight",
            "label": "husk weight",
            "value": ""
        },
        {
            "key": "rejection",
            "label": "rejection weight",
            "value": ""
        },
        {
            "key": "powder_weight",
            "label": "powder weight",
            "value": ""
        },
        {
            "key": "duser_weight",
            "label": "duser weight",
            "value": ""
        },
        {
            "key": "actual_return_weight",
            "label": "actual return weight",
            "value": ""
        }
    ],
    "ungraded_kale": [
        {
            "key": "issue_weight",
            "label": "issue weight",
            "value": ""
        },
        {
            "key": "back_cut_weight",
            "label": "back cut weight",
            "value": ""
        },
        {
            "key": "wholes_weight",
            "label": "wholes weight",
            "value": ""
        },
        {
            "key": "pieces_weight",
            "label": "piece weight",
            "value": ""
        },
        {
            "key": "husk_weight",
            "label": "husk weight",
            "value": ""
        },
        {
            "key": "rejection",
            "label": "rejection weight",
            "value": ""
        },
        {
            "key": "powder_weight",
            "label": "powder weight",
            "value": ""
        },
        {
            "key": "duser_weight",
            "label": "duser weight",
            "value": ""
        },
        {
            "key": "actual_return_weight",
            "label": "actual return weight",
            "value": ""
        }
    ],
    "gp360": [
        {
            "key": "issue_weight",
            "label": "issue weight",
            "value": ""
        },
        {
            "key": "jh_weight",
            "label": "jh weight",
            "value": ""
        },
        {
            "key": "jh1_weight",
            "label": "jh1 weight",
            "value": ""
        },
        {
            "key": "jk_weight",
            "label": "jk weight",
            "value": ""
        },
        {
            "key": "dp_weight",
            "label": "dp weight",
            "value": ""
        },
        {
            "key": "dp2_weight",
            "label": "dp2 weight",
            "value": ""
        },
        {
            "key": "ss_weight",
            "label": "ss weight",
            "value": ""
        },
        {
            "key": "pkp_weight",
            "label": "pkp weight",
            "value": ""
        },
        {
            "key": "dooser_weight",
            "label": "dooser weight",
            "value": ""
        },
        {
            "key": "wholes_weight",
            "label": "wholes weight",
            "value": ""
        },
        {
            "key": "rem_pieces_weight",
            "label": "rem piece weight",
            "value": ""
        }
    ],
    "gp": [
        {
            "key": "issue_weight",
            "label": "issue weight",
            "value": ""
        },
        {
            "key": "jh_weight",
            "label": "jh weight",
            "value": ""
        },
        {
            "key": "jh1_weight",
            "label": "jh1 weight",
            "value": ""
        },
        {
            "key": "jk_weight",
            "label": "jk weight",
            "value": ""
        },
        {
            "key": "dp_weight",
            "label": "dp weight",
            "value": ""
        },
        {
            "key": "dp2_weight",
            "label": "dp2 weight",
            "value": ""
        },
        {
            "key": "ss_weight",
            "label": "ss weight",
            "value": ""
        },
        {
            "key": "pkp_weight",
            "label": "pkp weight",
            "value": ""
        },
        {
            "key": "dooser_weight",
            "label": "dooser weight",
            "value": ""
        },
        {
            "key": "wholes_weight",
            "label": "wholes weight",
            "value": ""
        },
        {
            "key": "rem_pieces_weight",
            "label": "rem piece weight",
            "value": ""
        }
    ],
    "hp_peeling": [
        {
            "key": "issue_weight",
            "label": "issue weight",
            "value": ""
        },
        {
            "key": "back_cut_weight",
            "label": "back cut weight",
            "value": ""
        },
        {
            "key": "wholes_weight",
            "label": "wholes weight",
            "value": ""
        },
        {
            "key": "pieces_weight",
            "label": "piece weight",
            "value": ""
        },
        {
            "key": "husk_weight",
            "label": "husk weight",
            "value": ""
        },
        {
            "key": "rejection_weight",
            "label": "rejection weight",
            "value": ""
        },
        {
            "key": "powder_weight",
            "label": "powder weight",
            "value": ""
        },
        {
            "key": "duser_weight",
            "label": "duser weight",
            "value": ""
        },
        {
            "key": "pajji_weight",
            "label": "pajji weight",
            "value": ""
        },
        {
            "key": "actual_return_weight",
            "label": "actual return weight",
            "value": ""
        }
    ],
    "hp_kale": [
        {
            "key": "issue_weight",
            "label": "issue weight",
            "value": ""
        },
        {
            "key": "back_cut_weight",
            "label": "back cut weight",
            "value": ""
        },
        {
            "key": "wholes_weight",
            "label": "wholes weight",
            "value": ""
        },
        {
            "key": "pieces_weight",
            "label": "piece weight",
            "value": ""
        },
        {
            "key": "husk_weight",
            "label": "husk weight",
            "value": ""
        },
        {
            "key": "rejection_weight",
            "label": "rejection weight",
            "value": ""
        },
        {
            "key": "powder_weight",
            "label": "powder weight",
            "value": ""
        },
        {
            "key": "duser_weight",
            "label": "duser weight",
            "value": ""
        },
        {
            "key": "actual_return_weight",
            "label": "actual return weight",
            "value": ""
        }
    ],
    "hp_360gp": [
        {
            "key": "issue_weight",
            "label": "issue weight",
            "value": ""
        },
        {
            "key": "jh_weight",
            "label": "jh weight",
            "value": ""
        },
        {
            "key": "jh1_weight",
            "label": "jh1 weight",
            "value": ""
        },
        {
            "key": "jk_weight",
            "label": "jk weight",
            "value": ""
        },
        {
            "key": "dp_weight",
            "label": "dp weight",
            "value": ""
        },
        {
            "key": "dp2_weight",
            "label": "dp2 weight",
            "value": ""
        },
        {
            "key": "ss_weight",
            "label": "ss weight",
            "value": ""
        },
        {
            "key": "pkp_weight",
            "label": "pkp weight",
            "value": ""
        },
        {
            "key": "dooser_weight",
            "label": "dooser weight",
            "value": ""
        },
        {
            "key": "wholes_weight",
            "label": "wholes weight",
            "value": ""
        },
        {
            "key": "rem_pieces_weight",
            "label": "rem piece weight",
            "value": ""
        }
    ],
    "hp_gp": [
        {
            "key": "issue_weight",
            "label": "issue weight",
            "value": ""
        },
        {
            "key": "jh_weight",
            "label": "jh weight",
            "value": ""
        },
        {
            "key": "jh1_weight",
            "label": "jh1 weight",
            "value": ""
        },
        {
            "key": "jk_weight",
            "label": "jk weight",
            "value": ""
        },
        {
            "key": "dp_weight",
            "label": "dp weight",
            "value": ""
        },
        {
            "key": "dp2_weight",
            "label": "dp2 weight",
            "value": ""
        },
        {
            "key": "ss_weight",
            "label": "ss weight",
            "value": ""
        },
        {
            "key": "pkp_weight",
            "label": "pkp weight",
            "value": ""
        },
        {
            "key": "dooser_weight",
            "label": "dooser weight",
            "value": ""
        },
        {
            "key": "wholes_weight",
            "label": "wholes weight",
            "value": ""
        },
        {
            "key": "rem_pieces_weight",
            "label": "rem piece weight",
            "value": ""
        }
    ],
    "pajji_peeling": [
        {
            "key": "issue_weight",
            "label": "issue weight",
            "value": ""
        },
        {
            "key": "sp_weight",
            "label": "sp weight",
            "value": ""
        },
        {
            "key": "dp_weight",
            "label": "dp weight",
            "value": ""
        },
        {
            "key": "dp2_weight",
            "label": "dp2 weight",
            "value": ""
        },
        {
            "key": "ss_weight",
            "label": "ss weight",
            "value": ""
        },
        {
            "key": "jh_weight",
            "label": "jh weight",
            "value": ""
        },
        {
            "key": "jh1_weight",
            "label": "jh1 weight",
            "value": ""
        },
        {
            "key": "pajji_weight",
            "label": "pajji weight",
            "value": ""
        },
        {
            "key": "k_rem_pieces_weight",
            "label": "k rem piece weight",
            "value": ""
        },
        {
            "key": "wholes_weight",
            "label": "wholes weight",
            "value": ""
        },
        {
            "key": "pkp_weight",
            "label": "pkp weight",
            "value": ""
        },
        {
            "key": "op_weight",
            "label": "op weight weight",
            "value": ""
        },
        {
            "key": "husk_weight",
            "label": "husk weight",
            "value": ""
        },
        {
            "key": "rejection_weight",
            "label": "rejection weight",
            "value": ""
        },
        {
            "key": "dooser_weight",
            "label": "dooser weight",
            "value": ""
        }
    ]
}