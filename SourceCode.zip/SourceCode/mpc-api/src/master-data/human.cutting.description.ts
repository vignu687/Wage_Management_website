
export const humanCuttingDescriptions =
    [
        {
            "key": "fixed_wages",
            "label": "Fixed Wages",
        },
        {
            "key": "uncut",
            "label": "Uncut",
        },
        {
            "key": "mixed_cut",
            "label": "Mixed Uncut",
        },
    ]

export const humanCuttingQuestions =
{
    "fixed_wages": [
        {
            "key": "attendance",
            "label": "Attendance",
            "options": [{
                "ans_label": "Half Day",
                "ans_value": "half_day"
            }, {
                "ans_label": "Full Day",
                "ans_value": "full_day"
            }],
            "value": ""
        }, {
            "key": "work_type",
            "label": "Work Type",
            "options": [
                { "ans_label": "Seperating", "ans_value": "seperating" },
                { "ans_label": "Scooping", "ans_value": "scooping" },
                { "ans_label": "Piece", "ans_value": "piece" },
                { "ans_label": "Wholes", "ans_value": "wholes" },
                { "ans_label": "Hand Cutting", "ans_value": "hand_cutting" },
                { "ans_label": "Machine Operator", "ans_value": "machine_operator" },
                { "ans_label": "Cleaner", "ans_value": "clearner" },
                { "ans_label": "Full Absent", "ans_value": "full_absent" }
            ],
            "value": ""
        },{
            "key": "wage_type",
            "label": "Wage Type",
            "options": [
                { "ans_label": "Base Wage", "ans_value": "base_wage" },
                { "ans_label": "General Wage", "ans_value": "general_wage" }
            ],
            "value": ""
        }
    ],
    "mixed_cut": [
        {
            "key": "wholes_weight",
            "label": "Wholes Weight",
            "value": ""
        },
        {
            "key": "pieces_weight",
            "label": "Piece Weight",
            "value": ""
        }

    ],
    "uncut": [
        {
            "key": "issue_weight",
            "label": "Issue Weight",
            "value": ""
        },
        {
            "key": "a_plus_wholes_weight",
            "label": "Grade A+ Wholes Weight",
            "value": "0"
        },
        {
            "key": "a_plus_pieces_weight",
            "label": "Grade A+ Piece Weight",
            "value": "0"
        },
        {
            "key": "a_wholes_weight",
            "label": "Grade A Wholes Weight",
            "value": "0"
        },
        {
            "key": "a_pieces_weight",
            "label": "Grade A Piece Weight",
            "value": "0"
        },
        {
            "key": "b_wholes_weight",
            "label": "Grade B Wholes Weight",
            "value": "0"
        },
        {
            "key": "b_pieces_weight",
            "label": "Grade B Piece Weight",
            "value": "0"
        },
        {
            "key": "c_wholes_weight",
            "label": "Grade C Wholes Weight",
            "value": "0"
        },
        {
            "key": "c_pieces_weight",
            "label": "Grade C Piece Weight",
            "value": "0"
        },
        {
            "key": "d_wholes_weight",
            "label": "Grade D Wholes Weight",
            "value": "0"
        },
        {
            "key": "d_pieces_weight",
            "label": "Grade D Piece Weight",
            "value": "0"
        }
    ]
}