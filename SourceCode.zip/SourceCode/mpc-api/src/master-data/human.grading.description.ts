export const humanGradingDescriptions =
    [
        {
          "key": "fixed_wages",
          "label": "Fixed Wages"
        },
        {
          "key": "jh_piece",
          "label": "JH Piece"
        },
        {
          "key": "dp_piece",
          "label": "DP Piece"
        },
        {
          "key": "piece_pajji",
          "label": "Piece Pajji"
        },
        {
          "key": "wholes_grading",
          "label": "Wholes Grading"
        }
];

export const humanGradingQuestions = {
    "fixed_wages": [
        {
            "key": "attendance",
            "label": "Attendance",
            "options": [{
                "ans_label": "Half Day",
                "ans_value": "half_day"
            }, {
                "ans_label": "Full Day",
                "ans_value": "full_day"
            }],
            "value": ""
        },{
          "key": "wage_type",
          "label": "Wage Type",
          "options": [
              { "ans_label": "Base Wage", "ans_value": "base_wage" },
              { "ans_label": "General Wage", "ans_value": "general_wage" }
          ],
          "value": ""
      }
    ],
    "jh_piece": [
        {
          "key": "issue_weight",
          "label": "issue weight",
          "value": ""
        },
        {
          "key": "jh_weight",
          "label": "jh weight",
          "value": ""
        },
        {
          "key": "jh1_weight",
          "label": "jh1 weight",
          "value": ""
        },
        {
          "key": "k_weight",
          "label": "k weight",
          "value": ""
        },
        {
          "key": "pajji_weight",
          "label": "pajji weight",
          "value": ""
        },
        {
          "key": "ss_weight",
          "label": "ss weight",
          "value": ""
        },
        {
          "key": "sp_weight",
          "label": "sp weight",
          "value": ""
        },
        {
          "key": "wholes_weight",
          "label": "wholes weight",
          "value": ""
        },
        {
          "key": "dp_weight",
          "label": "dp weight",
          "value": ""
        },
        {
          "key": "dp2_weight",
          "label": "dp2 weight",
          "value": ""
        },
        {
          "key": "pkp_weight",
          "label": "pkp weight",
          "value": ""
        },
        {
          "key": "op_pp_weight",
          "label": "op/pp weight",
          "value": ""
        }
      ], "dp_piece": [
        {
          "key": "issue_weight",
          "label": "issue weight",
          "value": ""
        },
        {
          "key": "jh_weight",
          "label": "jh weight",
          "value": ""
        },
        {
          "key": "jh1_weight",
          "label": "jh1 weight",
          "value": ""
        },
        {
          "key": "k_weight",
          "label": "k weight",
          "value": ""
        },
        {
          "key": "pajji_weight",
          "label": "pajji weight",
          "value": ""
        },
        {
          "key": "ss_weight",
          "label": "ss weight",
          "value": ""
        },
        {
          "key": "sp_weight",
          "label": "sp weight",
          "value": ""
        },
        {
          "key": "wholes_weight",
          "label": "wholes weight",
          "value": ""
        },
        {
          "key": "dp_weight",
          "label": "dp weight",
          "value": ""
        },
        {
          "key": "dp2_weight",
          "label": "dp2 weight",
          "value": ""
        },
        {
          "key": "pkp_weight",
          "label": "pkp weight",
          "value": ""
        },
        {
          "key": "op_pp_weight",
          "label": "op/pp weight",
          "value": ""
        }
      ], "piece_pajji": [
        {
          "key": "issue_weight",
          "label": "issue weight",
          "value": ""
        },
        {
          "key": "sp_weight",
          "label": "sp weight",
          "value": ""
        },
        {
          "key": "dp_weight",
          "label": "dp weight",
          "value": ""
        },
        {
          "key": "dp2_weight",
          "label": "dp2 weight",
          "value": ""
        },
        {
          "key": "ss_weight",
          "label": "ss weight",
          "value": ""
        },
        {
          "key": "jh1_weight",
          "label": "jh1 weight",
          "value": ""
        },
        {
          "key": "pajji_weight",
          "label": "pajji weight",
          "value": ""
        },
        {
          "key": "wholes_weight",
          "label": "wholes weight",
          "value": ""
        },
        {
          "key": "pkp_weight",
          "label": "pkp weight",
          "value": ""
        },
        {
          "key": "op_weight",
          "label": "op weight",
          "value": ""
        },
        {
          "key": "rejection_weight",
          "label": "rejection weight",
          "value": ""
        },
        {
          "key": "dooser_weight",
          "label": "dooser weight",
          "value": ""
        }
      ], "wholes_grading" : [
        {
          "key": "issue_weight",
          "label": "issue weight",
          "value": ""
        },
        {
          "key": "w180_weight",
          "label": "w180 weight",
          "value": ""
        },
        {
          "key": "w210_weight",
          "label": "w210 weight",
          "value": ""
        },
        {
          "key": "w240_weight",
          "label": "w240 weight",
          "value": ""
        },
        {
          "key": "w320_weight",
          "label": "w320 weight",
          "value": ""
        },
        {
          "key": "w400_weight",
          "label": "w400 weight",
          "value": ""
        },
        {
          "key": "180_weight",
          "label": "180 weight",
          "value": ""
        },
        {
          "key": "210_weight",
          "label": "210 weight",
          "value": ""
        },
        {
          "key": "240_weight",
          "label": "240 weight",
          "value": ""
        },
        {
          "key": "320_weight",
          "label": "320 weight",
          "value": ""
        },
        {
          "key": "360_weight",
          "label": "360 weight",
          "value": ""
        },
        {
          "key": "kale_weight",
          "label": "kale weight",
          "value": ""
        },
        {
          "key": "pajji_weight",
          "label": "pajji weight",
          "value": ""
        },
        {
          "key": "dw_weight",
          "label": "dw weight",
          "value": ""
        },
        {
          "key": "sw320_weight",
          "label": "sw320 weight",
          "value": ""
        },
        {
          "key": "sw240_weight",
          "label": "sw240 weight",
          "value": ""
        },
        {
          "key": "gp_weight",
          "label": "gp weight",
          "value": ""
        },
        {
          "key": "ow_pw_weight",
          "label": "ow/pw weight",
          "value": ""
        },
        {
          "key": "rw_weight",
          "label": "rw weight",
          "value": ""
        },
        {
          "key": "cut_weight",
          "label": "cut weight",
          "value": ""
        },
        {
          "key": "buds_weight",
          "label": "buds weight",
          "value": ""
        },
        {
          "key": "ssw2_weight",
          "label": "ssw 2 weight",
          "value": ""
        }
      ]
}