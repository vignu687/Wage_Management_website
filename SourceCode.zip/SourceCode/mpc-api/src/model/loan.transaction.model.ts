import mongoose, { Schema } from 'mongoose';
import { options } from './_model.config';
import { ObjectId } from 'mongodb';

const LoanTransaction = new Schema({
    employee_id: { type: ObjectId, ref: 'Employee', required: true },
    event_type : { type: String, enum:['Loan Amount Issued','Loan Amount Collected'] ,required: true },
    amount : { type: Number, required: true},
    comment : {type: String, trim: true},
    created_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID },
    updated_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID }
},
    options()
)

export default mongoose.model('LoanTransactions', LoanTransaction);