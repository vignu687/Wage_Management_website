import mongoose, { Schema } from 'mongoose';
import { options } from './_model.config';
import { ObjectId } from 'mongodb';


const machinePeelingSchema = new Schema({
    origin_id: { type: ObjectId, ref: 'Origin' },
    lot_id: { type: ObjectId, ref: 'Lot' },
    entry_date: { type: Date, required: true },
    entry_type: { type: String, enum: ['In', 'Out'], required: true },
    machine_name : { type: String, required: true },
    trays: {
        type: [{ tray: Number }],
        validate: {
            validator: v => Array.isArray(v) && v.length > 0,
            message: `trays is required!`
        },
        require: function () { return this.entry_type === 'In'; }
    },
    wholes_weight: { type: Number, required: function () { return this.entry_type === 'Out'; } },
    pieces_weight: { type: Number, required: function () { return this.entry_type === 'Out'; } },
    husk_weight: { type: Number, required: function () { return this.entry_type === 'Out'; } },
    status: { type: Boolean, required: true, default: true },
    created_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID },
    updated_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID }
},
    options()
)

machinePeelingSchema.virtual('total_tray_weight').get(function () {
    return this.trays.reduce((a, b) => a + b.tray, 0);
});

export default mongoose.model('MachinePeeling', machinePeelingSchema);