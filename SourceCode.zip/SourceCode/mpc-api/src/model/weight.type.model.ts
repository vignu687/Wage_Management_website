import mongoose, { Schema } from 'mongoose';
import { options } from './_model.config';
import { ObjectId } from 'mongodb';

const weightTypeSchema = new Schema({
    type: { type: String, trim: true,required: true},
    label: { type: String, trim: true,required: true },
    department : { type: String, trim: true,required: true },
    entry_type : { type: String, trim: true,required: true },
    created_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID },
    updated_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID }
},
    options()
)

weightTypeSchema.index({ type: 1, department: 1, entry_type:1 }, { unique: true });

export default mongoose.model('WeightType', weightTypeSchema);