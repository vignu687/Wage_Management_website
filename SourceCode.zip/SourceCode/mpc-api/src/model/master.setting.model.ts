import mongoose, { Schema } from 'mongoose';
import { options } from './_model.config';
import { ObjectId } from 'mongodb';

const masterSettingSchema = new Schema({
    gp360: { type: {} },
    gp: { type: {} },
    dp_piece: { type: {} },
    fixed_wages: { type: {} },
    hp_360gp: { type: {} },
    hp_gp: { type: {} },
    jh_piece: { type: {} },
    pajji_peeling: { type: {} },
    piece_pajji: { type: {} },
    wholes_grading: { type: {} },
    hand_peeling: { type: {} },
    hp_kale: { type: {} },
    hp_peeling: { type: {} },
    kale: { type: {} },
    mixed_uncut_wage: { type: {} },
    uncut_wage: { type: {} },
    ungraded_kale: { type: {} },
    payroll : {type : {}},
    status: { type: Boolean, required: true, default: true },
    created_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID },
    updated_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID }
},
    options()
)

export default mongoose.model('MasterSetting', masterSettingSchema);
