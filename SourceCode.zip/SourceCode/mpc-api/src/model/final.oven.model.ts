import mongoose, { Schema } from 'mongoose';
import { options } from './_model.config';
import { ObjectId } from 'mongodb';


const finalOvenSchema = new Schema({
    origin_id: { type: ObjectId, ref: 'Origin' },
    lot_id: { type: ObjectId, ref: 'Lot' },
    entry_date: { type: Date, required: true },
    entry_type: { type: String, required: true },
    trays: {
        type:
            [{
                grade: { type: String, required: true },
                weight: { type: Number, required: true }
            }],
        validate: {
            validator: v => Array.isArray(v) && v.length > 0,
            message: `Grade or Weight is required!`
        }
    },
    status: { type: Boolean, required: true, default: true },
    created_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID },
    updated_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID }
},
    options()
)

finalOvenSchema.virtual('total_weight').get(function () {
    return this.trays.reduce((a, b) => a + b.weight, 0);
});

export default mongoose.model('FinalOven', finalOvenSchema);
