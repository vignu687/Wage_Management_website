import { humanCuttingDescriptions } from 'master-data/human.cutting.description';
import mongoose, { Schema } from 'mongoose';
import { options, schemaPlugin } from './_model.config';
import { ObjectId } from 'mongodb';


const humanCuttingSchema = new Schema({
    origin_id: { type: ObjectId, ref: 'Origin' },
    lot_id: { type: ObjectId, ref: 'Lot' },
    entry_date: { type: Date, required: true },
    employee_id: { type: ObjectId, ref: 'Employee' },
    job_description: { type: String, enum: humanCuttingDescriptions.map(o => o.key), required: true },
    value: {},
    wage: {},
    status: { type: Boolean, required: true, default: true },
    created_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID },
    updated_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID }
},
    options()
)

humanCuttingSchema.plugin(schemaPlugin);

humanCuttingSchema.virtual('total_weight').get(function () {
    return this.value.reduce((a, b) => parseFloat(a) + parseFloat(b.value), 0).toFixed(2);
});

export default mongoose.model('HumanCutting', humanCuttingSchema);
