import mongoose, { Schema } from 'mongoose';
import { options } from './_model.config';
import { ObjectId } from 'mongodb';

const employeeSchema = new Schema({
    employee_type: { type: String, enum: ['admin', 'worker', 'operator'], trim: true, required: true },
    username : { type: String, trim: true, required:  function () { return this.employee_type === 'admin'; }},
    password : { type: String, trim: true, required: true },
    email : { type: String, trim: true, required: function () { return this.employee_type === 'admin'; } },
    first_name: { type: String, trim: true, required: true },
    middle_name: { type: String, trim: true },
    last_name: { type: String, trim: true },
    gender: { type: String, trim: true, required: true },
    dob: { type: Date, required: true },
    blood_group: { type: String, trim: true},
    address: { type: String, trim: true },
    city: { type: String, trim: true },
    pincode: { type: String, trim: true },
    phone: { type: String, trim: true, required: function () { return this.employee_type === 'worker' || this.employee_type === 'operator'  ; } },
    alternate_phone: { type: String, trim: true },
    bank_opt :{ type: Boolean, trim: true, required: function () { return this.employee_type === 'worker' || this.employee_type === 'operator'  ; } },
    pf_opt :{ type: Boolean, trim: true, required: function () { return this.employee_type === 'worker' || this.employee_type === 'operator'  ; }},
    esi_opt :{ type: Boolean, trim: true, required: function () { return this.employee_type === 'worker' || this.employee_type === 'operator'  ; }},
    aadhar_no: { type: String, trim: true, required: function () { return this.employee_type === 'worker' || this.employee_type === 'operator'  ; }},
    pan_no: { type: String, trim: true},
    bankaccount_no :  { type: String, trim: true},
    ifsc :  { type: String, trim: true},
    uan_no:  { type: String, trim: true},
    esi_no:  { type: String, trim: true},
    kernel_grading:  { type: Number},
    peeling:  { type: Number},
    seperating:  { type: Number},
    piece:  { type: Number},
    scooping:  { type: Number},
    wholes:  { type: Number},
    cleaners:  { type: Number},
    machine_operator:  { type: Number},
    hand_cutting:  { type: Number},
    full_absent:  { type: Number},
    loan_balance: {type: Number, default:0, min: [0, 'Loan Balance cannot be Negative']},
    pages: {
        type: [String],
        required: function () { return this.employee_type ==='operator'},
        default: void 0
    },
    created_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID },
    updated_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID }
},
    options()
)

employeeSchema.index({username:1},{unique:true})

export default mongoose.model('Employee', employeeSchema);
