import mongoose, { Schema } from 'mongoose';
import { options } from './_model.config';
import { ObjectId } from 'mongodb';


const sortingMachineSchema = new Schema({
    origin_id: { type: ObjectId, ref: 'Origin' },
    lot_id: { type: ObjectId, ref: 'Lot' },
    entry_date: { type: Date, required: true },
    entry_type: { type: String, enum: ['In', 'Out'], required: true },
    weight_type : { type: String,  require: function () { return this.entry_type === 'In'; } },
    machine_name : { type: String, required: true },
    trays: {
        type: [{ tray: Number }],
        validate: {
            validator: v => Array.isArray(v) && v.length > 0,
            message: `trays is required!`
        },
        require: function () { return this.entry_type === 'In'; }
    },
    weight_trays: {
        type:
            [{
                weight_type: { type: String },
                weight: { type: Number }
            }],
        validate: {
            validator: v => Array.isArray(v) && v.length > 0,
            message: `weight_type and weight is required!`
        },
        require: function () { return this.entry_type === 'Out'; }
    },
    status: { type: Boolean, required: true, default: true },
    created_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID },
    updated_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID }
},
    options()
)

sortingMachineSchema.virtual('total_in_weight').get(function () {
    return this.trays.reduce((a, b) => a + b.tray, 0);
});

sortingMachineSchema.virtual('total_out_weight').get(function () {
    return this.weight_trays.reduce((a, b) => a + b.weight, 0);
});

export default mongoose.model('SortingMachine', sortingMachineSchema);
