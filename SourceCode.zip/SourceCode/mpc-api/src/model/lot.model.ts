import mongoose, { Schema } from 'mongoose';
import { options } from './_model.config';
import { ObjectId } from 'mongodb';

const lotSchema = new Schema({
    name: { type: String, trim: true, required: true, unique: true, uppercase: true },
    origin_id: { type: ObjectId, ref: 'Origin' },
    status: { type: Boolean, default: true },
    created_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID },
    updated_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID }
},
    options()
)

export default mongoose.model('Lot', lotSchema);