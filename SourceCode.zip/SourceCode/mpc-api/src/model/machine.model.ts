import mongoose, { Schema } from 'mongoose';
import { options } from './_model.config';
import { ObjectId } from 'mongodb';

const machineSchema = new Schema({
    name: { type: String, trim: true, required: true },
    type: { type: String, enum: ['cutting', 'peeling','sorting','grading'], required: true },
    purchase_date : { type: Date},
    status: { type: Boolean, default: true },
    created_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID },
    updated_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID }
},
    options()
)

machineSchema.index({name: 1, type: 1}, {unique: true});

export default mongoose.model('Machine', machineSchema);