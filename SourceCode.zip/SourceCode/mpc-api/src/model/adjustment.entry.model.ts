import mongoose, { Schema } from 'mongoose';
import { options } from './_model.config';
import { ObjectId } from 'mongodb';

const adjustmentEntrySchema = new Schema({
    employee_id: { type: ObjectId, ref: 'Employee' },
    entry_date: { type: Date, required: true },
    entry_type: { type: String, required: true },
    entry_category: { type: String, required: true },
    amount: { type: Number, required: true },
    status: { type: Boolean, default: true },
    created_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID },
    updated_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID }
},
    options()
)

adjustmentEntrySchema.index({ entry_date: 1, employee_id: 1 }, { unique: true});

export default mongoose.model('AdjustmentEntry', adjustmentEntrySchema);