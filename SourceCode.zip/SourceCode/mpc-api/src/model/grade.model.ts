import mongoose, { Schema } from 'mongoose';
import { options } from './_model.config';
import { ObjectId } from 'mongodb';

const gradeSchema = new Schema({
    name: { type: String, trim: true, required: true, unique: true },
    status: { type: Boolean, default: true },
    created_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID },
    updated_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID }
},
    options()
)

export default mongoose.model('Grade', gradeSchema);