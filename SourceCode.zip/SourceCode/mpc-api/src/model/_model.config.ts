var omitPrivate = (doc, obj) => {
    delete obj.__v;
    delete obj.status;
    delete obj.created_date;
    delete obj.created_by;
    delete obj._id;
    return obj;
}

// schema options
export const options = (hide = true) => {
    let options: any = {
        versionKey: false,
        timestamps: { createdAt: 'created_date', updatedAt: 'updated_date' },
        toJSON: { virtuals: true },
        toObject: { virtuals: true }
    }
    if (hide) {
        options.toJSON = {
            transform: omitPrivate,
            virtuals: true
        }
    }
    return options;
};


export const schemaPlugin = (schema, options) => {
    var modifiedBy = function (next, options) {
        var self = this;
        self.updated_by = options.userid;
        if (!self.created_by) {
            self.created_by = options.userid;
        }
        next()
    };
    // update date for bellow 4 methods
    schema.pre('save', modifiedBy)
        .pre('update', modifiedBy)
        .pre('findOneAndUpdate', modifiedBy)
        .pre('findByIdAndUpdate', modifiedBy);

}

