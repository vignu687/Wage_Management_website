import mongoose, { Schema } from 'mongoose';
import { options } from './_model.config';
import { ObjectId } from 'mongodb';

const payrollEntrySchema = new Schema({
    employees: { type: [{}], required: true },
    entry_date: { type: Date, required: true },
    entry_type: { type: String, required: true },
    entry_category: { type: String, required: true },
    amount: { type: Number, required: true },
    status: { type: Boolean, default: true },
    created_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID },
    updated_by: { type: ObjectId, required: true, default: process.env.DEFAULT_USER_ID }
},
    options()
)

payrollEntrySchema.index({ entry_date: 1, entry_type: 1, entry_category: 1 }, { unique: true});

export default mongoose.model('PayrollEntry', payrollEntrySchema);