import * as express from 'express';
import { coolingRouter } from 'modules/cooling/cooling.router';
import { finalOvenRouter } from 'modules/final-oven-entry/final.oven.router';
import { humanCuttingRouter } from 'modules/human-cutting/human.cutting.router';
import { humanGradingRouter } from 'modules/human-grading/human.grading.router';
import { humanPeelingRouter } from 'modules/human-peeling/human.peeling.router';
import { machineCuttingRouter } from 'modules/machine-cutting/machine.cutting.router';
import { machineGradingRouter } from 'modules/machine-grading/machine.grading.router';
import { machinePeelingRouter } from 'modules/machine-peeling/machine.peeling.router';
import { employeeRouter } from 'modules/management/employee/employee.router';
import { lotRouter } from 'modules/management/lot/lot.router';
import { settingRouter } from 'modules/management/master-setting/setting.router';
import { originRouter } from 'modules/management/origin/origin.router';
import { sortingMachineRouter } from 'modules/sorting-machine/sorting.machine.router';
import { ovenHeatingRouter } from 'modules/oven-heating/oven.heating.router';
import { roastingRouter } from 'modules/roasting/roasting.router';
import { gradeRouter } from 'modules/management/grade/grade.router';
import { machineRouter } from 'modules/management/machine/machine.router';
import { weightTypeRouter } from 'modules/management/weight-type/weight.type.router';
import { entryTypeRouter } from 'modules/management/entry-type/entry.type.router';
import { viewWageRouter } from 'modules/view-wage/view.wage.router';
import { userRouter } from 'modules/management/user/user.router';
import { reportRouter } from 'modules/report/report.router';
import { employeeLoanRouter } from 'modules/management/employee-loan/employee.loan.router';
import { payrollEntryRouter } from 'modules/management/payroll-entry/payroll.entry.router';

export class baseRouterClass {

    public router: express.Router = express.Router();

    constructor() {
        this.config();
    }

    public config(): void {

        this.router.use("/employees", employeeRouter);
        this.router.use("/origins", originRouter);
        this.router.use("/origins/:origin_id/lots", lotRouter);
        this.router.use("/coolings", coolingRouter);
        this.router.use("/roastings", roastingRouter);
        this.router.use("/machine-cuttings", machineCuttingRouter);
        this.router.use("/oven-heatings", ovenHeatingRouter);
        this.router.use("/final-ovens", finalOvenRouter);
        this.router.use("/sorting-machines", sortingMachineRouter);
        this.router.use("/machine-gradings", machineGradingRouter);
        this.router.use("/machine-peelings", machinePeelingRouter);
        this.router.use("/human-peelings", humanPeelingRouter);
        this.router.use("/human-cuttings", humanCuttingRouter);
        this.router.use("/human-gradings", humanGradingRouter);
        this.router.use("/master-settings", settingRouter);
        this.router.use("/grades", gradeRouter);
        this.router.use("/machines", machineRouter);
        this.router.use("/weight-types", weightTypeRouter);
        this.router.use("/entry-types", entryTypeRouter);
        this.router.use("/view-wages", viewWageRouter);
        this.router.use("/users", userRouter);
        this.router.use("/reports", reportRouter);
        this.router.use("/employee-loans", employeeLoanRouter)
        this.router.use("/payroll-entry",payrollEntryRouter )

    }
}

export const baseRouter = new baseRouterClass().router;