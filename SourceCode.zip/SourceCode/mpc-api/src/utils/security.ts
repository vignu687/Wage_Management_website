import * as jwt from "jsonwebtoken";
import { httpUtility } from "./http";

class securityUtilityClass {

    public cors(req, res, next) {

        // CORS headers
        res.header("Access-Control-Allow-Origin", "*");

        // restrict it to the required domain
        res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');

        // Set custom headers for CORS
        res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Authorization, Content-Type, Accept, MetaID, UserID,EID,tzname, tzoffset');

        if (req.method == 'OPTIONS') {
            res.status(200).end();
        } else {
            next();
        }
    }

    public generateToken(user) {

        return jwt.sign(
            { userid: user.id, username: user.username },
            process.env.API_ACCESS_SECRET,
            { issuer: process.env.API_ACCESS_ISSUER, expiresIn: process.env.API_ACCESS_EXPIRES_IN });
    }

    public decodeToken(token) {
        if (token.startsWith('Bearer ')) {
            token = token.slice(7, token.length);
        }
        return jwt.decode(token);
    }

    public validateToken(req, res, next): void {

        if (req.headers["postman-token"] || req.path.indexOf("report") != -1) {
            next();
            return;
        }

        let httpStack = {
            req: req,
            res: res,
            message: "",
            statusCode: 200
        };

        // Express headers are auto converted to lowercase
        let token = req.headers['x-access-token'] || req.headers['authorization'];

        if (token) {

            if (token.startsWith('Bearer ')) {
                // Remove Bearer from string
                token = token.slice(7, token.length);
            }

            jwt.verify(token, process.env.API_ACCESS_SECRET, (error, decoded) => {
                if (error) {

                    httpStack.statusCode = 401;
                    httpStack.message = "Authorization Token - Invalid";
                    httpUtility.sendError(httpStack, error);
                } else {
                    //req.decoded = decoded;
                    next();
                }
            });

        } else {

            if (req.url.includes("login")
                || req.url.indexOf("forgot-password") != -1) {

                next();
                return;
            }

            httpStack.statusCode = 401;
            httpStack.message = "Authorization Token - Not Found";
            httpUtility.sendError(httpStack, "");
        }
    }
}

export const securityUtility = new securityUtilityClass();