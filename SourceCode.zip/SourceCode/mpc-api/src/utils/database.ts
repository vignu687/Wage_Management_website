import * as dotenv from "dotenv";

dotenv.config({ path: "./env/" + process.env.NODE_ENV + ".env" });

const MONGO_OPTIONS = {
    useUnifiedTopology: true,
    useNewUrlParser: true,
    useCreateIndex: true,
    socketTimeoutMS: 30000,
    keepAlive: true,
    poolSize: 50,
    retryWrites: false,
    useFindAndModify: false
};

const MONGO_USERNAME = process.env.API_DB_USER || 'superuser';
const MONGO_PASSWORD = process.env.API_DB_PASSWORD || 'supersecretpassword1';
const MONGO_DB = process.env.API_DB_URL || `localhost:27017`;
//const MONGO_HOST = MONGO_DB + '/' + process.env.API_DB_NAME;
const MONGO_HOST = MONGO_DB;

const MONGO = {
    host: MONGO_HOST,
    password: MONGO_PASSWORD,
    username: MONGO_USERNAME,
    options: MONGO_OPTIONS,
    //url: `mongodb://${MONGO_USERNAME}:${MONGO_PASSWORD}@${MONGO_HOST}`
    url: MONGO_HOST
};

const SERVER_HOSTNAME = process.env.API_DB_URL || 'localhost';
const SERVER_PORT = process.env.API_PORT || 27017;

const SERVER = {
    hostname: SERVER_HOSTNAME,
    port: SERVER_PORT
};

const databaseConfig = {
    mongo: MONGO,
    server: SERVER
};

export default databaseConfig;