import moment from "moment";

class dateFilterClass {

    getDateFilter(startDate, endDate = null) {
        const start = moment(startDate).startOf('day').toDate();
        if (!endDate) {
            endDate = startDate;
        }
        const end = moment(endDate).endOf('day').toDate();
        return { '$gte': start, '$lte': end };
    }
}

export const dateFilter = new dateFilterClass();