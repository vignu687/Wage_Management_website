//import { emailUtility } from "utils/email";

import { securityUtility } from "./security";

class httpUtilityClass {

    public sendSuccess(httpStack, data): void {

        data = JSON.stringify(data).replace(/( )(null)( ?)/g, "\"\"");

        data = JSON.parse(data);

        httpStack.statusCode = httpStack.statusCode == undefined ? 200 : httpStack.statusCode;

        httpStack.res.status(httpStack.statusCode).send({
            message: httpStack.message == undefined ? "" : httpStack.message,
            status: true,
            data: data,
            trace: ""
        });
    }

    public sendError(httpStack, error): void {

        //   httpUtility.emailUser(httpStack, error);

        httpStack.statusCode = httpStack.statusCode == undefined ? 500 : httpStack.statusCode;

        httpStack.res.status(httpStack.statusCode).send({
            message: httpStack.message == undefined ? (error.message == undefined ? "SERVER ERROR" : error.message) : httpStack.message,
            status: false,
            data: [],
            trace: error.message == undefined ? error : error.message
        });

    }

    public action(req, res, next, action) {

        let httpStack = {
            req: req, res: res, next: next, message: "", statusCode: 200, schema: "", hospital_name: '', app_name: 'CCC'
        };

        try {

            let requestJSON: any = { configSQL: {} };
            requestJSON.configSQL.schema = "";
            requestJSON.configSQL.userid = process.env.DEFAULT_USER_ID;
            requestJSON.configSQL.token = req.headers['x-access-token'] || req.headers['authorization'];

            if (requestJSON.configSQL.token) {
                let decodedToken = securityUtility.decodeToken(requestJSON.configSQL.token);
                if (decodedToken['userid']) {
                    requestJSON.configSQL.userid = decodedToken['userid'];
                }
            }

            action(httpStack, requestJSON);

        } catch (error) {

            httpUtility.sendError(httpStack, error);
        }
    }


}

export const httpUtility = new httpUtilityClass();